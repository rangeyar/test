#!/usr/bin/env python3
"""
SmartUpgrade License Checker
Automated license analysis tool similar to Maven's license-maven-plugin
"""

import json
import subprocess
import sys
from datetime import datetime
from pathlib import Path

def install_pip_licenses():
    """Install pip-licenses if not available"""
    try:
        import pip_licenses
    except ImportError:
        print("Installing pip-licenses...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pip-licenses"])

def generate_license_report():
    """Generate comprehensive license reports"""
    print("🔍 Analyzing SmartUpgrade dependencies...")
    
    # Generate JSON report
    print("📊 Generating JSON license data...")
    result = subprocess.run([
        sys.executable, "-m", "pip_licenses", 
        "--format=json", 
        "--output-file=licenses.json"
    ], capture_output=True, text=True)
    
    if result.returncode != 0:
        print(f"❌ Error generating JSON report: {result.stderr}")
        return False
    
    # Generate markdown report
    print("📝 Generating markdown license report...")
    subprocess.run([
        sys.executable, "-m", "pip_licenses",
        "--format=markdown",
        "--output-file=DEPENDENCY_LICENSES_DETAILED.md"
    ])
    
    # Generate CSV for spreadsheet analysis
    print("📈 Generating CSV license report...")
    subprocess.run([
        sys.executable, "-m", "pip_licenses",
        "--format=csv",
        "--output-file=licenses.csv"
    ])
    
    return True

def analyze_license_compatibility():
    """Analyze license compatibility and risks"""
    print("⚖️ Analyzing license compatibility...")
    
    # Load license data
    with open('licenses.json', 'r') as f:
        licenses = json.load(f)
    
    # License categories
    compatible_licenses = {
        'MIT': 'Very Permissive - Commercial Friendly',
        'Apache Software License': 'Commercial Friendly',
        'Apache License': 'Commercial Friendly', 
        'Apache 2.0': 'Commercial Friendly',
        'BSD License': 'Commercial Friendly',
        'BSD': 'Commercial Friendly',
        'ISC License': 'Commercial Friendly'
    }
    
    restrictive_licenses = {
        'GNU Lesser General Public License': 'LGPL - Requires Compliance',
        'LGPL': 'LGPL - Requires Compliance',
        'GNU General Public License': 'GPL - Copyleft Risk',
        'GPL': 'GPL - Copyleft Risk'
    }
    
    unknown_licenses = []
    risky_licenses = []
    safe_licenses = []
    
    print(f"\n📦 Analyzing {len(licenses)} dependencies...")
    
    for pkg in licenses:
        name = pkg.get('Name', 'Unknown')
        license_name = pkg.get('License', 'Unknown')
        version = pkg.get('Version', 'Unknown')
        
        # Check license compatibility
        is_compatible = False
        is_risky = False
        
        for safe_license in compatible_licenses:
            if safe_license.lower() in license_name.lower():
                safe_licenses.append((name, version, license_name))
                is_compatible = True
                break
        
        if not is_compatible:
            for risky_license in restrictive_licenses:
                if risky_license.lower() in license_name.lower():
                    risky_licenses.append((name, version, license_name))
                    is_risky = True
                    break
        
        if not is_compatible and not is_risky:
            unknown_licenses.append((name, version, license_name))
    
    # Generate compatibility report
    report = f"""
# SmartUpgrade License Compatibility Report
Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Summary
- **Total Dependencies**: {len(licenses)}
- **✅ Compatible**: {len(safe_licenses)} ({len(safe_licenses)/len(licenses)*100:.1f}%)
- **⚠️ Requires Review**: {len(risky_licenses)} ({len(risky_licenses)/len(licenses)*100:.1f}%)
- **❓ Unknown**: {len(unknown_licenses)} ({len(unknown_licenses)/len(licenses)*100:.1f}%)

## ✅ Compatible Dependencies ({len(safe_licenses)})
"""
    
    for name, version, license_name in safe_licenses:
        report += f"- **{name}** v{version} - {license_name}\n"
    
    if risky_licenses:
        report += f"\n## ⚠️ Dependencies Requiring Review ({len(risky_licenses)})\n"
        for name, version, license_name in risky_licenses:
            report += f"- **{name}** v{version} - {license_name} ❗\n"
    
    if unknown_licenses:
        report += f"\n## ❓ Unknown Licenses ({len(unknown_licenses)})\n"
        for name, version, license_name in unknown_licenses:
            report += f"- **{name}** v{version} - {license_name} ❓\n"
    
    report += f"""
## Risk Assessment
- **Overall Risk Level**: {"🟢 LOW" if len(risky_licenses) == 0 else "🟡 MEDIUM" if len(risky_licenses) <= 2 else "🔴 HIGH"}
- **Commercial Use**: {"✅ APPROVED" if len(risky_licenses) <= 1 else "⚠️ REVIEW REQUIRED"}

## Recommendations
1. Review any LGPL dependencies for compliance requirements
2. Ensure proper attribution for all dependencies
3. Include license texts in distribution
4. Regular license audits on dependency updates
"""
    
    with open('LICENSE_COMPATIBILITY_REPORT.md', 'w') as f:
        f.write(report)
    
    print("✅ License compatibility analysis complete!")
    print(f"📊 {len(safe_licenses)} compatible, {len(risky_licenses)} require review, {len(unknown_licenses)} unknown")
    
    return len(risky_licenses) == 0

def create_attribution_file():
    """Create third-party attribution file"""
    print("📋 Creating attribution file...")
    
    with open('licenses.json', 'r') as f:
        licenses = json.load(f)
    
    attribution = f"""# Third-Party Software Licenses

SmartUpgrade incorporates the following third-party software components:

Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

---

"""
    
    for pkg in sorted(licenses, key=lambda x: x.get('Name', '').lower()):
        name = pkg.get('Name', 'Unknown')
        version = pkg.get('Version', 'Unknown')
        license_name = pkg.get('License', 'Unknown')
        license_file = pkg.get('LicenseFile', 'Not Available')
        
        attribution += f"## {name} v{version}\n"
        attribution += f"- **License**: {license_name}\n"
        attribution += f"- **License File**: {license_file}\n"
        attribution += f"- **Purpose**: Dependency of SmartUpgrade\n\n"
    
    attribution += """---

For complete license texts, see individual license files or visit the respective project repositories.

SmartUpgrade complies with all applicable license terms and acknowledges the contributions of the open source community.
"""
    
    with open('THIRD_PARTY_ATTRIBUTIONS.md', 'w') as f:
        f.write(attribution)
    
    print("✅ Attribution file created!")

def main():
    """Main license checking workflow"""
    print("🚀 SmartUpgrade License Checker")
    print("=" * 50)
    
    try:
        # Install dependencies
        install_pip_licenses()
        
        # Generate reports
        if not generate_license_report():
            return 1
        
        # Analyze compatibility
        is_compatible = analyze_license_compatibility()
        
        # Create attribution
        create_attribution_file()
        
        print("\n📁 Generated Files:")
        print("- licenses.json (machine-readable)")
        print("- licenses.csv (spreadsheet format)")
        print("- DEPENDENCY_LICENSES_DETAILED.md (detailed report)")
        print("- LICENSE_COMPATIBILITY_REPORT.md (compatibility analysis)")
        print("- THIRD_PARTY_ATTRIBUTIONS.md (attribution file)")
        
        if is_compatible:
            print("\n✅ All licenses are compatible for commercial use!")
            return 0
        else:
            print("\n⚠️ Some licenses require review - check compatibility report")
            return 1
            
    except Exception as e:
        print(f"❌ Error: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())