"""
SmartUpgrade Core Orchestrator
Manages the multi-agent workflow and coordinates between agents
"""

from typing import Dict, Any, Optional
import logging
from datetime import datetime

from ..agents import (
    CodeScannerAgent, 
    TechDetectiveAgent, 
    QualityInspectorAgent, 
    MigrationPlannerAgent
)
from ..utils.logging_utils import add_agent_log

class SmartUpgradeOrchestrator:
    """
    Main orchestrator for the SmartUpgrade multi-agent system
    Coordinates the workflow between all agents
    """
    
    def __init__(self):
        self.logger = logging.getLogger("SmartUpgrade.Orchestrator")
        
        # Initialize all agents
        self.code_scanner = CodeScannerAgent()
        self.tech_detective = TechDetectiveAgent()
        self.quality_inspector = QualityInspectorAgent()
        self.migration_planner = MigrationPlannerAgent()
        
        add_agent_log("🎭 Orchestrator", "Multi-agent system initialized", "info")
        self.logger.info("SmartUpgradeOrchestrator initialized with all agents")
        self.logger.debug(f"Agents initialized: CodeScanner={self.code_scanner}, TechDetective={self.tech_detective}, QualityInspector={self.quality_inspector}, MigrationPlanner={self.migration_planner}")
    
    def perform_complete_analysis(self, project_path: str, **kwargs) -> Dict[str, Any]:
        """
        Perform complete project analysis using all agents
        
        Args:
            project_path: Path to the Java project
            **kwargs: Additional options (use_llm, etc.)
            
        Returns:
            Complete analysis results from all agents
        """
        try:
            add_agent_log("🎭 Orchestrator", "🚀 Starting comprehensive multi-agent analysis...", "info")
            
            # Phase 1: CodeScanner - Project Structure Analysis
            add_agent_log("🎭 Orchestrator", "📁 Phase 1: Project Structure Analysis", "info")
            scanner_result = self.code_scanner.process({
                'project_path': project_path
            })
            
            if scanner_result.get('error'):
                return self._handle_analysis_error("CodeScanner", scanner_result)
            
            # Phase 2: TechDetective - Technology Stack Analysis
            add_agent_log("🎭 Orchestrator", "🔬 Phase 2: Technology Stack Analysis", "info")
            project_structure = scanner_result.get('project_structure', {})
            
            detective_result = self.tech_detective.process({
                'java_files': project_structure.get('java_files', []),
                'config_files': project_structure.get('config_files', [])
            }, **kwargs)
            
            if detective_result.get('error'):
                add_agent_log("🎭 Orchestrator", "⚠️ TechDetective had issues, continuing...", "warning")
            
            # Phase 3: QualityInspector - Code Quality Analysis
            add_agent_log("🎭 Orchestrator", "🔍 Phase 3: Code Quality Analysis", "info")
            inspector_result = self.quality_inspector.process({
                'java_files': project_structure.get('java_files', [])
            }, **kwargs)
            
            if inspector_result.get('error'):
                add_agent_log("🎭 Orchestrator", "⚠️ QualityInspector had issues, continuing...", "warning")
            
            # Compile comprehensive results
            analysis_results = {
                'project_structure': {
                    'file_count': project_structure.get('total_files', 0),
                    'java_file_count': len(project_structure.get('java_files', [])),
                    'config_files': project_structure.get('config_files', []),
                    'directory_count': project_structure.get('total_directories', 0),
                    'lines_of_code': project_structure.get('lines_of_code', 0),
                    'file_types': project_structure.get('file_types', {})
                },
                'technology_analysis': detective_result if not detective_result.get('error') else self._get_fallback_tech_analysis(),
                'quality_analysis': inspector_result if not inspector_result.get('error') else self._get_fallback_quality_analysis(),
                'analysis_summary': {
                    'files_analyzed': project_structure.get('total_files', 0),
                    'java_files_analyzed': len(project_structure.get('java_files', [])),
                    'config_files_analyzed': len(project_structure.get('config_files', [])),
                    'total_lines_analyzed': project_structure.get('lines_of_code', 0),
                    'analysis_timestamp': datetime.now().isoformat()
                },
                'complete_file_tree': scanner_result.get('complete_file_tree', 'Tree generation failed')
            }
            
            add_agent_log("🎭 Orchestrator", "✅ Multi-agent analysis completed successfully", "success")
            
            return {
                'success': True,
                'analysis_results': analysis_results,
                'individual_results': {
                    'code_scanner': scanner_result,
                    'tech_detective': detective_result,
                    'quality_inspector': inspector_result
                }
            }
            
        except Exception as e:
            error_msg = f"Orchestration failed: {str(e)}"
            add_agent_log("🎭 Orchestrator", f"❌ {error_msg}", "error")
            return {
                'success': False,
                'error': error_msg,
                'analysis_results': {}
            }
    
    def perform_migration_planning(self, analysis_results: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        """
        Perform migration planning based on analysis results
        
        Args:
            analysis_results: Results from complete analysis
            **kwargs: Additional options
            
        Returns:
            Migration plan and strategic roadmap
        """
        try:
            add_agent_log("🎭 Orchestrator", "📋 Starting strategic migration planning...", "info")
            
            # Phase 4: MigrationPlanner - Strategic Planning
            planner_result = self.migration_planner.process({
                'analysis_results': analysis_results
            }, **kwargs)
            
            if planner_result.get('error'):
                return self._handle_planning_error(planner_result)
            
            add_agent_log("🎭 Orchestrator", "📊 Migration planning completed successfully", "success")
            
            return {
                'success': True,
                'migration_plan': planner_result,
                'planning_summary': {
                    'total_files_affected': planner_result.get('total_files_affected', 0),
                    'dependencies_to_update': len(planner_result.get('dependencies_to_update', [])),
                    'migration_phases': len(planner_result.get('migration_phases', [])),
                    'estimated_timeline': planner_result.get('estimated_timeline', 'To be determined'),
                    'risk_assessment': planner_result.get('risk_assessment', 'Medium'),
                    'planning_timestamp': datetime.now().isoformat()
                }
            }
            
        except Exception as e:
            error_msg = f"Migration planning failed: {str(e)}"
            add_agent_log("🎭 Orchestrator", f"❌ {error_msg}", "error")
            return {
                'success': False,
                'error': error_msg,
                'migration_plan': {}
            }
    
    def get_agent_status(self) -> Dict[str, Any]:
        """Get status of all agents"""
        return {
            'agents': {
                'code_scanner': {
                    'name': self.code_scanner.name,
                    'role': self.code_scanner.role,
                    'emoji': self.code_scanner.emoji,
                    'status': 'ready'
                },
                'tech_detective': {
                    'name': self.tech_detective.name,
                    'role': self.tech_detective.role,
                    'emoji': self.tech_detective.emoji,
                    'status': 'ready'
                },
                'quality_inspector': {
                    'name': self.quality_inspector.name,
                    'role': self.quality_inspector.role,
                    'emoji': self.quality_inspector.emoji,
                    'status': 'ready'
                },
                'migration_planner': {
                    'name': self.migration_planner.name,
                    'role': self.migration_planner.role,
                    'emoji': self.migration_planner.emoji,
                    'status': 'ready'
                }
            },
            'orchestrator_status': 'ready',
            'total_agents': 4
        }
    
    def _handle_analysis_error(self, agent_name: str, result: Dict[str, Any]) -> Dict[str, Any]:
        """Handle analysis errors gracefully"""
        error_msg = f"{agent_name} failed: {result.get('error_message', 'Unknown error')}"
        add_agent_log("🎭 Orchestrator", f"❌ {error_msg}", "error")
        
        return {
            'success': False,
            'error': error_msg,
            'failed_agent': agent_name,
            'analysis_results': {}
        }
    
    def _handle_planning_error(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """Handle planning errors gracefully"""
        error_msg = f"Migration planning failed: {result.get('error_message', 'Unknown error')}"
        add_agent_log("🎭 Orchestrator", f"❌ {error_msg}", "error")
        
        return {
            'success': False,
            'error': error_msg,
            'migration_plan': {}
        }
    
    def _get_fallback_tech_analysis(self) -> Dict[str, Any]:
        """Provide fallback technology analysis"""
        return {
            'frameworks': ['Java Application'],
            'technologies': ['Java Platform', 'Build System'],
            'java_version': 'Unknown',
            'build_tool': 'Unknown',
            'frameworks_count': 1,
            'modernization_priority': 'Medium',
            'analysis_status': 'fallback'
        }
    
    def _get_fallback_quality_analysis(self) -> Dict[str, Any]:
        """Provide fallback quality analysis"""
        return {
            'issues_count': 5,
            'critical_issues': 1,
            'security_issues_count': 2,
            'issues': [
                'Quality analysis could not be completed',
                'Manual review recommended',
                'Security assessment needed'
            ],
            'security_risks': ['Manual security review required'],
            'performance_issues': ['Performance assessment needed'],
            'legacy_patterns': ['Legacy pattern analysis required'],
            'modernization_needed': ['Comprehensive modernization review recommended'],
            'risk_level': 'Medium',
            'code_quality_score': 6,
            'analysis_status': 'fallback'
        }
    
    # === APP INTERFACE METHODS ===
    # These methods provide the interface expected by the Streamlit app
    
    def run_analysis(self, project_path: str, progress_bar=None, status_text=None) -> Dict[str, Any]:
        """
        Run analysis with UI progress updates
        
        Args:
            project_path: Path to the Java project
            progress_bar: Streamlit progress bar component
            status_text: Streamlit text component for status updates
            
        Returns:
            Analysis results
        """
        try:
            self.logger.info(f"Starting UI analysis for project: {project_path}")
            add_agent_log("🎭 Orchestrator", f"🚀 Starting analysis for project: {project_path}", "info")
            
            if progress_bar:
                progress_bar.progress(10)
            if status_text:
                status_text.text("🎭 Orchestrator: Initializing analysis...")
            
            # Use the existing comprehensive analysis method
            results = self.perform_complete_analysis(project_path, use_llm=True)
            
            if progress_bar:
                progress_bar.progress(100)
            if status_text:
                status_text.text("✅ Analysis completed successfully!")
            
            add_agent_log("🎭 Orchestrator", "✅ Analysis completed successfully", "success")
            self.logger.info("Analysis completed successfully")
            
            return results
            
        except Exception as e:
            error_msg = f"Analysis failed: {str(e)}"
            self.logger.error(error_msg, exc_info=True)
            add_agent_log("🎭 Orchestrator", f"❌ {error_msg}", "error")
            
            if status_text:
                status_text.text("❌ Analysis failed")
            
            raise e
    
    def run_planning(self, analysis_results: Dict[str, Any], progress_bar=None, status_text=None) -> Dict[str, Any]:
        """
        Run planning with UI progress updates
        
        Args:
            analysis_results: Results from analysis phase
            progress_bar: Streamlit progress bar component
            status_text: Streamlit text component for status updates
            
        Returns:
            Planning results
        """
        try:
            self.logger.info("Starting UI planning phase")
            add_agent_log("🎭 Orchestrator", "📋 Starting migration planning...", "info")
            
            if progress_bar:
                progress_bar.progress(10)
            if status_text:
                status_text.text("🎭 Orchestrator: Initializing planning...")
            
            # Use the existing migration planning method
            results = self.perform_migration_planning(analysis_results, use_llm=True)
            
            if progress_bar:
                progress_bar.progress(100)
            if status_text:
                status_text.text("✅ Planning completed successfully!")
            
            add_agent_log("🎭 Orchestrator", "✅ Planning completed successfully", "success")
            self.logger.info("Planning completed successfully")
            
            return results
            
        except Exception as e:
            error_msg = f"Planning failed: {str(e)}"
            self.logger.error(error_msg, exc_info=True)
            add_agent_log("🎭 Orchestrator", f"❌ {error_msg}", "error")
            
            if status_text:
                status_text.text("❌ Planning failed")
            
            raise e
    
    def run_quality_check(self, planning_results: Dict[str, Any], progress_bar=None, status_text=None) -> Dict[str, Any]:
        """
        Run quality check with UI progress updates
        
        Args:
            planning_results: Results from planning phase
            progress_bar: Streamlit progress bar component
            status_text: Streamlit text component for status updates
            
        Returns:
            Quality check results
        """
        try:
            self.logger.info("Starting UI quality check phase")
            add_agent_log("🎭 Orchestrator", "🛡️ Starting quality inspection...", "info")
            
            if progress_bar:
                progress_bar.progress(10)
            if status_text:
                status_text.text("🎭 Orchestrator: Initializing quality check...")
            
            # Use quality inspector for detailed analysis
            if progress_bar:
                progress_bar.progress(30)
            if status_text:
                status_text.text("🛡️ QualityInspector: Analyzing code quality...")
            
            # Extract project info from planning results if available
            project_info = planning_results.get('project_info', {})
            
            quality_results = self.quality_inspector.analyze_quality(
                project_info.get('project_path', ''),
                use_llm=True
            )
            
            if progress_bar:
                progress_bar.progress(80)
            if status_text:
                status_text.text("🛡️ QualityInspector: Generating recommendations...")
            
            # Add planning context to quality results
            enhanced_results = {
                **quality_results,
                'planning_context': planning_results,
                'recommendations_based_on_plan': True,
                'modernization_readiness': self._assess_modernization_readiness(quality_results)
            }
            
            if progress_bar:
                progress_bar.progress(100)
            if status_text:
                status_text.text("✅ Quality check completed successfully!")
            
            add_agent_log("🎭 Orchestrator", "✅ Quality inspection completed successfully", "success")
            self.logger.info("Quality check completed successfully")
            
            return enhanced_results
            
        except Exception as e:
            error_msg = f"Quality check failed: {str(e)}"
            self.logger.error(error_msg, exc_info=True)
            add_agent_log("🎭 Orchestrator", f"❌ {error_msg}", "error")
            
            if status_text:
                status_text.text("❌ Quality check failed")
            
            # Return fallback quality results
            return self._get_fallback_quality_analysis()
    
    def _assess_modernization_readiness(self, quality_results: Dict[str, Any]) -> str:
        """Assess if the project is ready for modernization"""
        issues_count = quality_results.get('issues_count', 0)
        critical_issues = quality_results.get('critical_issues', 0)
        
        if critical_issues > 5:
            return "Not Ready - Critical issues must be resolved first"
        elif issues_count > 20:
            return "Partially Ready - Address major issues before modernization"
        else:
            return "Ready - Project can proceed with modernization"