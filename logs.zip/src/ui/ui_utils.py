"""
UI utility functions for SmartUpgrade Streamlit interface
Handles common UI components and display functions
"""

import streamlit as st
import json
import os
from typing import Dict, Any, List, Optional
from datetime import datetime

def display_logo_and_title():
    """Display the SmartUpgrade logo and main title"""
    
    col1, col2 = st.columns([1, 3])
    
    with col1:
        logo_path = "static/logo.png"
        if os.path.exists(logo_path):
            st.image(logo_path, width=120)
        else:
            st.markdown("🚀")  # Fallback emoji
    
    with col2:
        st.markdown("""
        # SmartUpgrade
        ### AI-Powered Java Application Modernization Platform
        """)
    
    st.markdown("---")


def show_project_selection_ui() -> Optional[str]:
    """Show project selection interface and return selected path"""
    
    st.header("📁 Select Your Java Project")
    
    # Method selection
    selection_method = st.radio(
        "Choose project selection method:",
        ["📝 Enter path manually", "📂 Browse for project"]
    )
    
    project_path = None
    
    if selection_method == "📝 Enter path manually":
        project_path = st.text_input(
            "Enter the full path to your Java project:",
            placeholder="C:\\path\\to\\your\\java\\project",
            help="Enter the complete path to your Java project directory"
        )
        
        if project_path and st.button("Validate Path"):
            if validate_project_path(project_path):
                st.success(f"✅ Valid Java project found at: {project_path}")
                return project_path
            else:
                st.error("❌ Invalid project path or no Java files found")
                return None
    
    else:  # Browse method
        st.info("📂 Use the file browser above to navigate to your Java project directory")
        # In a real implementation, this would integrate with Streamlit's file uploader
        # or a custom file browser component
        
    return project_path


def validate_project_path(project_path: str) -> bool:
    """Validate if the given path contains a Java project"""
    
    if not project_path or not os.path.exists(project_path):
        return False
    
    # Check for Java files
    java_files = []
    for root, dirs, files in os.walk(project_path):
        for file in files:
            if file.endswith('.java'):
                java_files.append(file)
        if len(java_files) > 0:  # Found at least one Java file
            break
    
    return len(java_files) > 0


def show_analysis_progress(stage: str = "Initializing..."):
    """Show analysis progress with animated elements"""
    
    progress_placeholder = st.empty()
    status_placeholder = st.empty()
    
    with progress_placeholder.container():
        st.markdown("### 🔍 Project Analysis in Progress")
        progress_bar = st.progress(0)
        status_text = st.empty()
        status_text.text(stage)
    
    return progress_bar, status_text


def display_analysis_results(analysis_results: Dict[str, Any]):
    """Display comprehensive analysis results"""
    
    st.header("📊 Analysis Results")
    
    if analysis_results.get('error'):
        st.error(f"❌ Analysis failed: {analysis_results['error']}")
        return
    
    # Project overview
    with st.expander("📋 Project Overview", expanded=True):
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric(
                "Java Files",
                analysis_results.get('file_stats', {}).get('java_files', 0)
            )
        
        with col2:
            st.metric(
                "Total Lines of Code",
                analysis_results.get('file_stats', {}).get('total_lines', 0)
            )
        
        with col3:
            st.metric(
                "Packages",
                len(analysis_results.get('package_structure', []))
            )
    
    # Technology analysis
    tech_analysis = analysis_results.get('technology_analysis', {})
    if tech_analysis:
        with st.expander("🔧 Technology Stack"):
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("Detected Technologies")
                frameworks = tech_analysis.get('frameworks', [])
                if frameworks:
                    for framework in frameworks:
                        st.write(f"• {framework}")
                else:
                    st.write("No specific frameworks detected")
            
            with col2:
                st.subheader("Java Version")
                java_version = tech_analysis.get('java_version', 'Unknown')
                st.write(f"🔍 Detected: {java_version}")
    
    # Project structure
    if analysis_results.get('project_structure'):
        with st.expander("📂 Project Structure"):
            display_project_structure(analysis_results['project_structure'])


def display_project_structure(structure: Dict[str, Any], level: int = 0):
    """Display project structure in a tree-like format"""
    
    indent = "  " * level
    
    if isinstance(structure, dict):
        for key, value in structure.items():
            if isinstance(value, dict):
                st.write(f"{indent}📁 {key}/")
                display_project_structure(value, level + 1)
            elif isinstance(value, list):
                st.write(f"{indent}📁 {key}/")
                for item in value:
                    st.write(f"{indent}  📄 {item}")
            else:
                st.write(f"{indent}📄 {key}")


def display_planning_results(planning_results: Dict[str, Any]):
    """Display migration planning results"""
    
    st.header("📋 Migration Plan")
    
    if planning_results.get('error'):
        st.error(f"❌ Planning failed: {planning_results['error']}")
        return
    
    # Strategy overview
    strategy = planning_results.get('strategy', {})
    if strategy:
        with st.expander("🎯 Migration Strategy", expanded=True):
            
            # Target versions
            target_versions = strategy.get('target_versions', {})
            if target_versions:
                st.subheader("🎯 Target Versions")
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Java", target_versions.get('java', 'TBD'))
                
                with col2:
                    st.metric("Spring Boot", target_versions.get('spring_boot', 'TBD'))
                
                with col3:
                    st.metric("Spring Framework", target_versions.get('spring_framework', 'TBD'))
            
            # Migration phases
            phases = strategy.get('modernization_phases', [])
            if phases:
                st.subheader("📅 Migration Phases")
                for i, phase in enumerate(phases, 1):
                    st.write(f"**Phase {i}: {phase.get('phase', f'Phase {i}')}**")
                    st.write(f"Duration: {phase.get('duration', 'TBD')}")
                    tasks = phase.get('tasks', [])
                    if tasks:
                        for task in tasks:
                            st.write(f"  • {task}")
                    st.write("")
    
    # Task breakdown
    task_breakdown = planning_results.get('task_breakdown', {})
    if task_breakdown:
        with st.expander("📊 Task Breakdown"):
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.metric("Total Estimated Hours", task_breakdown.get('total_estimated_hours', 'TBD'))
            
            with col2:
                st.metric("Estimated Timeline", task_breakdown.get('timeline', 'TBD'))
            
            # Task categories
            task_categories = task_breakdown.get('task_categories', {})
            if task_categories:
                st.subheader("Task Categories")
                
                for category, details in task_categories.items():
                    st.write(f"**{category.title()}** ({details.get('hours', 0)} hours)")
                    tasks = details.get('tasks', [])
                    for task in tasks:
                        st.write(f"  • {task}")
    
    # Risk assessment
    risk_assessment = planning_results.get('risk_assessment', {})
    if risk_assessment:
        with st.expander("🛡️ Risk Assessment"):
            
            overall_risk = risk_assessment.get('overall_risk_level', 'medium')
            risk_color = {'low': '🟢', 'medium': '🟡', 'high': '🔴'}.get(overall_risk, '🟡')
            st.write(f"**Overall Risk Level:** {risk_color} {overall_risk.title()}")
            
            risk_categories = risk_assessment.get('risk_categories', {})
            for category, details in risk_categories.items():
                st.write(f"**{category.title()} Risks:**")
                risks = details.get('risks', [])
                mitigations = details.get('mitigation', [])
                
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write("Risks:")
                    for risk in risks:
                        st.write(f"  ⚠️ {risk}")
                
                with col2:
                    st.write("Mitigation:")
                    for mitigation in mitigations:
                        st.write(f"  ✅ {mitigation}")


def display_upgrade_results(upgrade_results: Dict[str, Any]):
    """Display upgrade execution results"""
    
    st.header("🚀 Upgrade Results")
    
    if upgrade_results.get('error'):
        st.error(f"❌ Upgrade failed: {upgrade_results['error']}")
        return
    
    # Summary metrics
    with st.expander("📊 Upgrade Summary", expanded=True):
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric(
                "Files Modified",
                upgrade_results.get('total_files_modified', 0)
            )
        
        with col2:
            status = upgrade_results.get('upgrade_status', 'unknown')
            status_icon = '✅' if status == 'completed' else '❌'
            st.metric("Status", f"{status_icon} {status.title()}")
        
        with col3:
            # Calculate success rate
            java_results = upgrade_results.get('java_upgrades', {})
            processed = java_results.get('files_processed', 0)
            modified = java_results.get('files_modified', 0)
            success_rate = (modified / processed * 100) if processed > 0 else 0
            st.metric("Success Rate", f"{success_rate:.1f}%")
    
    # Detailed results
    with st.expander("📝 Detailed Results"):
        
        # Java upgrades
        java_upgrades = upgrade_results.get('java_upgrades', {})
        if java_upgrades:
            st.subheader("☕ Java Version Upgrades")
            st.write(f"Files processed: {java_upgrades.get('files_processed', 0)}")
            st.write(f"Files modified: {java_upgrades.get('files_modified', 0)}")
            
            upgrades_applied = java_upgrades.get('upgrades_applied', [])
            if upgrades_applied:
                st.write("**Files upgraded:**")
                for upgrade in upgrades_applied:
                    st.write(f"  • {upgrade.get('file', 'Unknown file')}")
        
        # Spring upgrades
        spring_upgrades = upgrade_results.get('spring_upgrades', {})
        if spring_upgrades:
            st.subheader("🌱 Spring Boot Upgrades")
            st.write(f"Config files updated: {spring_upgrades.get('config_files_updated', 0)}")
            st.write(f"Java files updated: {spring_upgrades.get('java_files_updated', 0)}")
        
        # Dependency upgrades
        dependency_upgrades = upgrade_results.get('dependency_upgrades', {})
        if dependency_upgrades:
            st.subheader("📦 Dependency Upgrades")
            dependencies_updated = dependency_upgrades.get('dependencies_updated', [])
            if dependencies_updated:
                st.write("**Dependencies updated:**")
                for dep in dependencies_updated:
                    st.write(f"  • {dep}")
        
        # Code transformations
        transformations = upgrade_results.get('transformations', {})
        if transformations:
            st.subheader("🔧 Code Transformations")
            st.write(f"Files transformed: {transformations.get('files_modified', 0)}")


def show_agent_activity():
    """Display real-time agent activity"""
    
    st.header("🤖 Agent Activity")
    
    # This would show real-time logs from the agents
    if 'agent_logs' in st.session_state:
        logs = st.session_state.agent_logs
        
        # Create container for scrollable logs
        log_container = st.container()
        
        with log_container:
            for log in logs[-20:]:  # Show last 20 logs
                timestamp = log.get('timestamp', datetime.now().strftime('%H:%M:%S'))
                agent = log.get('agent', 'Unknown')
                message = log.get('message', '')
                level = log.get('level', 'info')
                
                # Color code by level
                color = {
                    'info': '🔵',
                    'success': '🟢', 
                    'warning': '🟡',
                    'error': '🔴'
                }.get(level, '⚪')
                
                st.write(f"{color} **{timestamp}** [{agent}] {message}")
    else:
        st.info("No agent activity to display yet")


def display_json_data(data: Dict[str, Any], title: str = "Data"):
    """Display JSON data in an expandable, formatted way"""
    
    with st.expander(f"📄 {title} (JSON)"):
        st.json(data)


def show_error_message(error: str, details: Optional[str] = None):
    """Display error message with optional details"""
    
    st.error(f"❌ {error}")
    
    if details:
        with st.expander("🔍 Error Details"):
            st.code(details, language="text")


def show_success_message(message: str, details: Optional[Dict[str, Any]] = None):
    """Display success message with optional details"""
    
    st.success(f"✅ {message}")
    
    if details:
        with st.expander("📊 Details"):
            st.json(details)


def create_download_button(data: str, filename: str, mime_type: str = "text/plain"):
    """Create a download button for generated content"""
    
    st.download_button(
        label=f"📥 Download {filename}",
        data=data,
        file_name=filename,
        mime=mime_type
    )


def show_processing_spinner(message: str = "Processing..."):
    """Show a processing spinner with message"""
    
    with st.spinner(message):
        st.empty()  # Placeholder for actual processing


def format_file_size(size_bytes: int) -> str:
    """Format file size in human readable format"""
    
    if size_bytes == 0:
        return "0 B"
    
    size_names = ["B", "KB", "MB", "GB"]
    size_index = 0
    
    while size_bytes >= 1024 and size_index < len(size_names) - 1:
        size_bytes /= 1024.0
        size_index += 1
    
    return f"{size_bytes:.1f} {size_names[size_index]}"


def create_tabs(tab_names: List[str]):
    """Create tabs for organizing content"""
    
    return st.tabs(tab_names)


def show_sidebar_info():
    """Display information in the sidebar"""
    
    with st.sidebar:
        st.header("ℹ️ About SmartUpgrade")
        st.write("""
        SmartUpgrade is an AI-powered platform for modernizing Java applications.
        
        **Features:**
        - 🔍 Comprehensive code analysis
        - 📋 Intelligent migration planning  
        - 🚀 Automated code upgrades
        - 🛡️ Risk assessment
        - 📊 Detailed reporting
        """)
        
        st.markdown("---")
        
        st.header("🚀 Quick Start")
        st.write("""
        1. Select your Java project
        2. Run comprehensive analysis
        3. Review migration plan
        4. Execute upgrades
        5. Validate results
        """)