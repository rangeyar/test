"""
Security utilities for SmartUpgrade
Provides input validation, sanitization, and security-related functions
"""

import os
import re
from pathlib import Path
from typing import List, Optional, Dict, Any
import html


class SecurityValidator:
    """Provides security validation and sanitization functions"""
    
    # File extension whitelist
    ALLOWED_EXTENSIONS = {'.java', '.xml', '.properties', '.txt', '.yaml', '.yml', '.json', '.gradle', '.pom'}
    
    # Maximum file size (100MB)
    MAX_FILE_SIZE = 100 * 1024 * 1024
    
    # Maximum path length
    MAX_PATH_LENGTH = 1000
    
    # Dangerous path patterns
    DANGEROUS_PATTERNS = [
        r'\.\./',  # Parent directory traversal
        r'\\\.\\',  # Windows parent directory
        r'/etc/',   # System directories
        r'/root/',
        r'/home/',
        r'C:\\Windows',
        r'C:\\Program Files',
        r'~/\.',   # Hidden files
        r'\$\{',   # Variable substitution
        r'%[A-Z_]+%',  # Environment variables
    ]
    
    @classmethod
    def sanitize_filename(cls, filename: str) -> str:
        """
        Sanitize filename to prevent path traversal and injection attacks
        
        Args:
            filename: Original filename
            
        Returns:
            Sanitized filename safe for file operations
        """
        if not filename or not isinstance(filename, str):
            return "unknown_file"
        
        # Remove path components
        safe_name = os.path.basename(filename)
        
        # Remove dangerous characters, keep alphanumeric, dots, dashes, underscores
        safe_name = re.sub(r'[^a-zA-Z0-9\.\-_]', '_', safe_name)
        
        # Limit length
        if len(safe_name) > 255:
            name_part = safe_name[:200]
            ext_part = safe_name[-50:] if '.' in safe_name[-50:] else ""
            safe_name = name_part + ext_part
        
        # Ensure it's not empty
        if not safe_name or safe_name in ['.', '..']:
            safe_name = "sanitized_file"
        
        return safe_name
    
    @classmethod
    def validate_file_path(cls, file_path: str) -> bool:
        """
        Validate file path for security issues
        
        Args:
            file_path: Path to validate
            
        Returns:
            True if path is safe, False otherwise
        """
        if not file_path or not isinstance(file_path, str):
            return False
        
        # Check length
        if len(file_path) > cls.MAX_PATH_LENGTH:
            return False
        
        # Check for dangerous patterns
        for pattern in cls.DANGEROUS_PATTERNS:
            if re.search(pattern, file_path, re.IGNORECASE):
                return False
        
        # Additional path validation
        try:
            normalized = os.path.normpath(file_path)
            
            # Check for absolute paths to sensitive locations
            sensitive_paths = ['/etc', '/root', '/home', 'C:\\Windows', 'C:\\Program Files']
            for sensitive in sensitive_paths:
                if normalized.lower().startswith(sensitive.lower()):
                    return False
            
            return True
            
        except (ValueError, OSError):
            return False
    
    @classmethod
    def validate_file_extension(cls, filename: str) -> bool:
        """
        Validate file extension against whitelist
        
        Args:
            filename: Filename to check
            
        Returns:
            True if extension is allowed, False otherwise
        """
        if not filename or not isinstance(filename, str):
            return False
        
        ext = os.path.splitext(filename.lower())[1]
        return ext in cls.ALLOWED_EXTENSIONS
    
    @classmethod
    def validate_file_size(cls, file_path: str) -> bool:
        """
        Validate file size is within limits
        
        Args:
            file_path: Path to file to check
            
        Returns:
            True if file size is acceptable, False otherwise
        """
        try:
            if not os.path.isfile(file_path):
                return False
            
            size = os.path.getsize(file_path)
            return size <= cls.MAX_FILE_SIZE
            
        except (OSError, IOError):
            return False
    
    @classmethod
    def sanitize_input_string(cls, input_str: str, max_length: int = 1000) -> str:
        """
        Sanitize user input string
        
        Args:
            input_str: String to sanitize
            max_length: Maximum allowed length
            
        Returns:
            Sanitized string
        """
        if not isinstance(input_str, str):
            return ""
        
        # HTML escape
        sanitized = html.escape(input_str)
        
        # Remove control characters
        sanitized = re.sub(r'[\x00-\x1f\x7f-\x9f]', '', sanitized)
        
        # Limit length
        if len(sanitized) > max_length:
            sanitized = sanitized[:max_length]
        
        return sanitized.strip()
    
    @classmethod
    def validate_project_structure(cls, project_path: str) -> Dict[str, Any]:
        """
        Validate project structure for security issues
        
        Args:
            project_path: Path to project directory
            
        Returns:
            Dict with validation results
        """
        results = {
            'is_valid': False,
            'errors': [],
            'warnings': [],
            'file_count': 0,
            'total_size': 0
        }
        
        try:
            if not os.path.isdir(project_path):
                results['errors'].append("Project path is not a directory")
                return results
            
            # Check if path is safe
            if not cls.validate_file_path(project_path):
                results['errors'].append("Project path contains unsafe patterns")
                return results
            
            file_count = 0
            total_size = 0
            
            # Walk through directory
            for root, dirs, files in os.walk(project_path):
                # Limit directory depth
                depth = root[len(project_path):].count(os.sep)
                if depth > 10:  # Reasonable depth limit
                    results['warnings'].append("Project structure very deep - some files may be skipped")
                    continue
                
                for file in files:
                    file_path = os.path.join(root, file)
                    
                    # Validate file
                    if not cls.validate_file_path(file_path):
                        results['warnings'].append(f"Unsafe file path skipped: {file}")
                        continue
                    
                    if not cls.validate_file_extension(file):
                        results['warnings'].append(f"Unsupported file type: {file}")
                        continue
                    
                    try:
                        size = os.path.getsize(file_path)
                        total_size += size
                        file_count += 1
                        
                        # Check individual file size
                        if size > cls.MAX_FILE_SIZE:
                            results['warnings'].append(f"Large file: {file} ({size:,} bytes)")
                    
                    except (OSError, IOError):
                        results['warnings'].append(f"Cannot access file: {file}")
            
            results['file_count'] = file_count
            results['total_size'] = total_size
            
            # Validate totals
            if file_count == 0:
                results['errors'].append("No valid files found in project")
            elif file_count > 10000:  # Reasonable file limit
                results['warnings'].append(f"Large number of files: {file_count}")
            
            if total_size > cls.MAX_FILE_SIZE * 50:  # 5GB project limit
                results['warnings'].append(f"Very large project: {total_size:,} bytes")
            
            results['is_valid'] = len(results['errors']) == 0
            
        except Exception as e:
            results['errors'].append("Failed to validate project structure")
        
        return results


class SecureFileHandler:
    """Secure file handling utilities"""
    
    @staticmethod
    def safe_read_file(file_path: str, max_size: int = SecurityValidator.MAX_FILE_SIZE) -> Optional[str]:
        """
        Safely read a file with validation
        
        Args:
            file_path: Path to file
            max_size: Maximum file size to read
            
        Returns:
            File contents or None if error
        """
        # Validate path
        if not SecurityValidator.validate_file_path(file_path):
            return None
        
        # Validate file exists and size
        if not SecurityValidator.validate_file_size(file_path):
            return None
        
        try:
            # Normalize and resolve path
            normalized_path = os.path.normpath(file_path)
            
            # Read with size limit
            with open(normalized_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read(max_size)
                return content
                
        except (OSError, IOError, UnicodeError):
            return None
    
    @staticmethod
    def safe_write_file(file_path: str, content: str, create_dirs: bool = False) -> bool:
        """
        Safely write a file with validation
        
        Args:
            file_path: Path to write
            content: Content to write
            create_dirs: Whether to create parent directories
            
        Returns:
            True if successful, False otherwise
        """
        # Validate inputs
        if not SecurityValidator.validate_file_path(file_path):
            return False
        
        if not isinstance(content, str):
            return False
        
        try:
            normalized_path = os.path.normpath(file_path)
            
            # Create parent directories if requested
            if create_dirs:
                parent_dir = os.path.dirname(normalized_path)
                if parent_dir:
                    os.makedirs(parent_dir, exist_ok=True)
            
            # Write file
            with open(normalized_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            return True
            
        except (OSError, IOError):
            return False
