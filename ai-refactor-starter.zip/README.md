# AI Refactor Starter (Spring Boot POM Upgrader)

A minimal end-to-end starter that lets you:
1) Upload a Java project (zip).
2) Agent A: Upgrade Spring Boot version(s) in `pom.xml`.
3) Agent B: Build the project with Maven or Maven Wrapper (if present).
4) Agent C: Run a simple static "code review" and generate suggestions.
5) Download the updated project as a zip.

## Quick Start

### 1) Python environment
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r backend/requirements.txt
```

### 2) Run the server
```bash
uvicorn backend.app:app --reload --port 8008
```

### 3) Open the UI
Open `frontend/index.html` in your browser (or serve it from any static server).
By default it points to `http://localhost:8008` for API calls.

> Tip: If the browser blocks local-file AJAX, run a simple static server:
> ```bash
> python -m http.server 5500 -d frontend
> ```
> Then visit http://localhost:5500

## Notes

- **Version detection**: You can pass `targetVersion` (e.g., `3.5.0`) in the UI. If left blank,
  the backend tries to discover the latest Spring Boot release online. If your machine has no internet,
  please specify the target.
- **Build**: The builder prefers `./mvnw`. If not found, it tries `mvn` on PATH. Build runs with `-DskipTests`.
- **Security**: This is a local dev tool. Do not expose publicly without authentication/sandboxing.
- **Extensibility**: Each agent is a Python module. Add new agents in `backend/agents` and wire them in `backend/app.py`.

