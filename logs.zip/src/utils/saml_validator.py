"""
SAML Token Validation Module
Provides secure SAML token validation with digital signature verification.
"""

import base64
import os
import re
import streamlit as st
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import padding


def validate_token_and_get_role(token):
    """
    Validates an authentication token and determines the user's role.
    
    This function decodes and parses an authentication token, extracts the role value 
    from the SAML attributes present in the token, validates the token's digital signature 
    to ensure that it has not been tampered with, and returns the verification status 
    along with the user role.
    
    Parameters:
        token : str
            The authentication token in base64 encoding.
    
    Returns:
        dict
            A dictionary containing:
            - role: str or None
                The extracted role of the user, or None if unavailable.
            - isValid: bool
                Indicates whether the token passed cryptographic validation.
            - isTampered: bool
                Indicates whether the token has been tampered with. It will be True 
                if the token failed validation or tampering is detected.
    """
    try:
        # Decode and parse the authentication token
        decoded_xml = base64.b64decode(token).decode('utf-8')
        
        # Extract the digitally signed assertion component
        assertion_match = re.search(
            r'<saml:Assertion[^>]*>.*?</saml:Assertion>', 
            decoded_xml, 
            re.DOTALL
        )
        
        if not assertion_match:
            return {"role": None, "isValid": False, "isTampered": True}
        
        current_assertion = assertion_match.group(0)
        
        # Parse user role from SAML attributes
        role_match = re.search(
            r'<saml:Attribute Name="role">\s*<saml:AttributeValue>(.*?)</saml:AttributeValue>',
            decoded_xml
        )
        role = role_match.group(1).strip() if role_match else None
        
        # Extract digital signature for verification
        signature_match = re.search(
            r'<ds:SignatureValue>(.*?)</ds:SignatureValue>', 
            decoded_xml
        )
        
        if not signature_match:
            return {"role": role, "isValid": False, "isTampered": True}
        
        signature = signature_match.group(1)
        
        # Perform cryptographic signature verification
        public_key_path = os.path.join(os.path.dirname(__file__), '..', '..', 'public-key.pem')
        
        # Validate public key availability
        if not os.path.exists(public_key_path):
            st.error(f"Public key certificate not found at: {public_key_path}")
            return {"role": role, "isValid": False, "isTampered": True}
        
        with open(public_key_path, 'rb') as key_file:
            public_key = serialization.load_pem_public_key(key_file.read())
        
        # Execute RSA signature verification
        try:
            signature_bytes = base64.b64decode(signature)
            public_key.verify(
                signature_bytes,
                current_assertion.encode('utf-8'),
                padding.PKCS1v15(),
                hashes.SHA256()
            )
            is_valid = True  # Cryptographic verification successful
        except InvalidSignature:
            is_valid = False  # Signature validation failed
        except Exception:
            is_valid = False  # Cryptographic operation error
        
        return {
            "role": role,
            "isValid": is_valid,
            "isTampered": not is_valid
        }
        
    except Exception as e:
        st.error(f"Token validation error: {str(e)}")
        return {"role": None, "isValid": False, "isTampered": True}
