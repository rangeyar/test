#//TODORAGJSP STARTS
"""
JSP Migration Agent
Modernizes JSP files from legacy Struts tags to modern JSTL/Spring MVC tags
"""

import os
import re
import streamlit as st
from typing import Dict, Any, List, Tuple
from ...utils.logging_utils import add_agent_log
from ...api_providers.provider_factory import provider_manager


def modernize_jsp_files(project_path: str, config: Dict[str, Any], analysis_results: Dict[str, Any]) -> Dict[str, str]:
    """
    Modernize JSP files for Spring MVC with JSTL 3.0 and Spring tags
    
    Args:
        project_path: Path to the project root
        config: Configuration including target_framework, packaging_type, etc.
        analysis_results: Analysis results containing JSP file information
        
    Returns:
        Dictionary of {jsp_file_path: modernized_content}
    """
    modernized_jsp_files = {}
    
    # Check if JSP migration is enabled
    if not config.get('jsp_migration_enabled', False):
        add_agent_log("JSPMigration", "JSP migration not enabled, skipping", "info")
        st.warning("⚠️ JSP migration is not enabled in the configuration. Enable it to modernize JSP files.")
        return modernized_jsp_files
    
    # Only process for Spring MVC
    if config.get('target_framework') != 'Spring MVC':
        add_agent_log("JSPMigration", f"Target framework is {config.get('target_framework')}, JSP migration only for Spring MVC", "info")
        st.warning(f"⚠️ Target framework is {config.get('target_framework')}. JSP migration is only applicable for Spring MVC projects.")
        return modernized_jsp_files
    
    add_agent_log("JSPMigration", "🚀 Starting JSP file modernization for Spring MVC", "info")
    st.info("🚀 Starting JSP file modernization for Spring MVC")
    # Get JSP files from analysis results
    jsp_files = analysis_results.get('file_categories', {}).get('jsp_files', [])
    
    if not jsp_files:
        add_agent_log("JSPMigration", "No JSP files found in analysis results", "warning")
        st.warning("⚠️ No JSP files found in the analysis results to modernize.")
        return modernized_jsp_files
    
    add_agent_log("JSPMigration", f"📄 Found {len(jsp_files)} JSP files to modernize", "info")
    st.info(f"📄 Found {len(jsp_files)} JSP files to modernize")
    for jsp_file_info in jsp_files:
        try:
            jsp_path = jsp_file_info.get('full_path') if isinstance(jsp_file_info, dict) else jsp_file_info
            
            if not os.path.exists(jsp_path):
                add_agent_log("JSPMigration", f"⚠️ JSP file not found: {jsp_path}", "warning")
                st.warning(f"⚠️ JSP file not found: {jsp_path}")
                continue
            
            # Read JSP file content
            with open(jsp_path, 'r', encoding='utf-8') as f:
                original_content = f.read()
            
            add_agent_log("JSPMigration", f"📝 Modernizing: {os.path.basename(jsp_path)}", "info")
            
            # Try AI-powered modernization first
            modernized_content = modernize_jsp_with_llm(original_content, jsp_path, config)
            
            if not modernized_content or modernized_content == original_content:
                # Fallback to rule-based modernization
                add_agent_log("JSPMigration", f"Using rule-based fallback for {os.path.basename(jsp_path)}", "info")
                modernized_content = modernize_jsp_rule_based(original_content, config)
            
            # Store relative path for ZIP creation
            relative_path = os.path.relpath(jsp_path, project_path)
            # Convert to webapp path if not already
            if not relative_path.startswith('src/main/webapp'):
                # Move JSP files to proper Spring MVC location
                jsp_filename = os.path.basename(jsp_path)
                relative_path = f"src/main/webapp/WEB-INF/views/{jsp_filename}"
            
            modernized_jsp_files[relative_path] = modernized_content
            add_agent_log("JSPMigration", f"✅ Modernized: {os.path.basename(jsp_path)}", "success")
            
        except Exception as e:
            add_agent_log("JSPMigration", f"❌ Error modernizing {jsp_path}: {str(e)}", "error")
    
    add_agent_log("JSPMigration", f"🎉 JSP modernization complete: {len(modernized_jsp_files)} files processed", "success")
    return modernized_jsp_files


def modernize_jsp_with_llm(jsp_content: str, jsp_path: str, config: Dict[str, Any]) -> str:
    """
    Use LLM to modernize JSP file from Struts to Spring MVC with JSTL
    """
    try:
        prompt = f"""Modernize this JSP file from Struts to Spring MVC with JSTL 3.0.

REQUIREMENTS:
1. Replace Struts taglib with Spring MVC and JSTL taglibs:
   - Remove: <%@ taglib uri="/struts-tags" prefix="s" %>
   - Add: <%@ taglib uri="jakarta.tags.core" prefix="c" %>
   - Add: <%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
   - Add: <%@ taglib uri="http://www.springframework.org/tags" prefix="spring" %>
   - Add: <%@ taglib uri="http://www.springframework.org/tags/form" prefix="form" %>

2. Convert Struts tags to Spring MVC/JSTL equivalents:
   - <s:property value="..."/> → ${{...}} (EL expression)
   - <s:form action="..."> → <form:form modelAttribute="..." action="...">
   - <s:textfield name="..."/> → <form:input path="..."/>
   - <s:password name="..."/> → <form:password path="..."/>
   - <s:textarea name="..."/> → <form:textarea path="..."/>
   - <s:select name="..."> → <form:select path="...">
   - <s:submit value="..."/> → <button type="submit">...</button>
   - <s:iterator value="..."> → <c:forEach items="${{...}}" var="...">
   - <s:if test="..."> → <c:if test="${{...}}">
   - <s:else> → </c:if><c:if test="${{!...}}">

3. Update action URLs to Spring MVC controller mappings:
   - Action paths should use Spring MVC @RequestMapping paths
   - Use ${{pageContext.request.contextPath}}/path format

4. Modernize page structure:
   - Use Jakarta EE 10 JSP 3.1 syntax
   - Add proper DOCTYPE and HTML5 structure if missing
   - Keep all styling and JavaScript intact

5. Preserve:
   - All HTML structure and content
   - CSS classes and IDs
   - JavaScript code
   - Comments

ORIGINAL JSP ({os.path.basename(jsp_path)}):
```jsp
{jsp_content}
```

Return ONLY the modernized JSP content without explanations or markdown code blocks."""

        provider = provider_manager.get_provider()
        st.info(f"Using {provider.__class__.__name__} for JSP modernization of {os.path.basename(jsp_path)}")
        add_agent_log("JSPMigration", f"🤖 Calling LLM for {os.path.basename(jsp_path)}...", "info")
        
        # Debug: Check prompt and messages
        #st.info(f"📝 Prompt length: {len(prompt)} chars")
        ##add_agent_log("JSPMigration", f"📝 Prompt length: {len(prompt)} chars", "info")
        
        messages = [{"role": "user", "content": prompt}]
        #st.info(f"📧 Messages array: {len(messages)} messages, first message has {len(messages[0]['content'])} chars")
        #add_agent_log("JSPMigration", f"📧 Messages array: {len(messages)} messages, first message has {len(messages[0]['content'])} chars", "info")
        
        if provider:
            try:
                # Use provider_manager.generate_completion with proper message format
               # st.info(f"📤 Sending to LLM...")
                #add_agent_log("JSPMigration", f"📤 Sending to LLM...", "info")
                
                ai_response = provider_manager.generate_completion(messages)
                response = ai_response.content if hasattr(ai_response, 'content') else str(ai_response)
                
               # st.info(f"📥 LLM response received: {len(response) if response else 0} chars")
                #add_agent_log("JSPMigration", f"📥 LLM response received: {len(response) if response else 0} chars", "info")
               # st.info(f"LLM modernization response received for {os.path.basename(jsp_path)}: {len(response) if response else 0} chars")
                
                if response and len(response) > 100:
                    # Clean up response
                    modernized = response.strip()
                    # Remove markdown code blocks if present
                    if modernized.startswith('```'):
                        lines = modernized.split('\n')
                        modernized = '\n'.join(lines[1:-1] if lines[-1].strip() == '```' else lines[1:])
                    add_agent_log("JSPMigration", f"✅ LLM successfully converted {os.path.basename(jsp_path)}", "success")
                    return modernized
                else:
                    add_agent_log("JSPMigration", f"⚠️ LLM response too short or empty for {os.path.basename(jsp_path)}", "warning")
            except Exception as llm_error:
                add_agent_log("JSPMigration", f"❌ LLM call failed: {str(llm_error)}", "error")
                st.error(f"LLM error: {str(llm_error)}")
        else:
            add_agent_log("JSPMigration", "❌ No LLM provider available", "error")
        
        return ""
        
    except Exception as e:
        add_agent_log("JSPMigration", f"LLM modernization failed: {str(e)}", "error")
        return ""


def modernize_jsp_rule_based(jsp_content: str, config: Dict[str, Any]) -> str:
    """
    Rule-based JSP modernization fallback
    Applies regex-based transformations for common Struts → Spring MVC/JSTL patterns
    """
    modernized = jsp_content
    
    # 1. Update taglib declarations
    # Remove Struts taglib
    modernized = re.sub(r'<%@\s*taglib\s+uri\s*=\s*["\'][^"\']*struts[^"\']*["\']\s+prefix\s*=\s*["\']\w+["\']\s*%>', '', modernized)
    
    # Add Jakarta JSTL and Spring taglibs if not present
    if 'jakarta.tags.core' not in modernized and 'java.sun.com/jsp/jstl/core' not in modernized:
        taglibs = """<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%@ taglib uri="jakarta.tags.fmt" prefix="fmt" %>
<%@ taglib uri="http://www.springframework.org/tags" prefix="spring" %>
<%@ taglib uri="http://www.springframework.org/tags/form" prefix="form" %>
"""
        # Insert after page directive or at the beginning
        if '<%@ page' in modernized:
            modernized = re.sub(r'(<%@\s*page[^%]*%>)', r'\1\n' + taglibs, modernized, count=1)
        else:
            modernized = taglibs + '\n' + modernized
    
    # 2. Convert Struts property tags to EL expressions
    modernized = re.sub(r'<s:property\s+value\s*=\s*["\']([^"\']+)["\']\s*/>', r'${\1}', modernized)
    
    # 3. Convert Struts form tags to Spring form tags
    modernized = re.sub(r'<s:form\s+action\s*=\s*["\']([^"\']+)["\']\s*>', r'<form:form action="${pageContext.request.contextPath}/\1" method="post">', modernized)
    modernized = re.sub(r'</s:form>', r'</form:form>', modernized)
    
    # 4. Convert Struts form inputs to Spring form tags
    modernized = re.sub(r'<s:textfield\s+name\s*=\s*["\']([^"\']+)["\']\s*/>', r'<form:input path="\1" cssClass="form-control"/>', modernized)
    modernized = re.sub(r'<s:password\s+name\s*=\s*["\']([^"\']+)["\']\s*/>', r'<form:password path="\1" cssClass="form-control"/>', modernized)
    modernized = re.sub(r'<s:textarea\s+name\s*=\s*["\']([^"\']+)["\']\s*/>', r'<form:textarea path="\1" cssClass="form-control"/>', modernized)
    modernized = re.sub(r'<s:hidden\s+name\s*=\s*["\']([^"\']+)["\']\s*/>', r'<form:hidden path="\1"/>', modernized)
    
    # 5. Convert Struts submit button to standard HTML button
    modernized = re.sub(r'<s:submit\s+value\s*=\s*["\']([^"\']+)["\']\s*/>', r'<button type="submit" class="btn btn-primary">\1</button>', modernized)
    
    # 6. Convert Struts iterator to JSTL forEach
    modernized = re.sub(r'<s:iterator\s+value\s*=\s*["\']([^"\']+)["\']\s*>', r'<c:forEach items="${\1}" var="item">', modernized)
    modernized = re.sub(r'</s:iterator>', r'</c:forEach>', modernized)
    
    # 7. Convert Struts conditionals to JSTL
    modernized = re.sub(r'<s:if\s+test\s*=\s*["\']([^"\']+)["\']\s*>', r'<c:if test="${\1}">', modernized)
    modernized = re.sub(r'</s:if>', r'</c:if>', modernized)
    modernized = re.sub(r'<s:else\s*/>', r'</c:if><c:if test="${!(\1)}">', modernized)
    modernized = re.sub(r'<s:else>', r'</c:if><c:otherwise>', modernized)
    modernized = re.sub(r'</s:else>', r'</c:otherwise>', modernized)
    
    # 8. Convert Struts URL tags to Spring URL tags
    modernized = re.sub(r'<s:url\s+action\s*=\s*["\']([^"\']+)["\']\s*>', r'<spring:url value="/\1" var="url">', modernized)
    modernized = re.sub(r'</s:url>', r'</spring:url>', modernized)
    
    # 9. Update JSP page directive for Jakarta EE
    if '<%@ page' in modernized and 'jakarta' not in modernized:
        modernized = re.sub(
            r'<%@\s*page([^%]*)%>',
            r'<%@ page\1 isELIgnored="false" %>',
            modernized,
            count=1
        )
    
    return modernized


def create_spring_mvc_configuration_files(config: Dict[str, Any]) -> Dict[str, str]:
    """
    Generate Spring MVC configuration files for JSP support
    Returns dict of {filename: content} for WAR structure files
    """
    config_files = {}
    
    java_version = config.get('java_version', 'Java 21 LTS').split(' ')[1]
    spring_version = config.get('spring_version', 'Spring Boot 3.3.x').split(' ')[2] if 'Spring Boot' in config.get('spring_version', '') else '3.3.0'
    
    # 1. web.xml for WAR deployment
    web_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<web-app xmlns="https://jakarta.ee/xml/ns/jakartaee"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="https://jakarta.ee/xml/ns/jakartaee 
         https://jakarta.ee/xml/ns/jakartaee/web-app_6_0.xsd"
         version="6.0">

    <display-name>Spring MVC Application</display-name>
    
    <!-- Spring MVC Dispatcher Servlet -->
    <servlet>
        <servlet-name>dispatcher</servlet-name>
        <servlet-class>org.springframework.web.servlet.DispatcherServlet</servlet-class>
        <init-param>
            <param-name>contextConfigLocation</param-name>
            <param-value>/WEB-INF/spring/dispatcher-config.xml</param-value>
        </init-param>
        <load-on-startup>1</load-on-startup>
    </servlet>
    
    <servlet-mapping>
        <servlet-name>dispatcher</servlet-name>
        <url-pattern>/</url-pattern>
    </servlet-mapping>
    
    <!-- Character Encoding Filter -->
    <filter>
        <filter-name>encodingFilter</filter-name>
        <filter-class>org.springframework.web.filter.CharacterEncodingFilter</filter-class>
        <init-param>
            <param-name>encoding</param-name>
            <param-value>UTF-8</param-value>
        </init-param>
        <init-param>
            <param-name>forceEncoding</param-name>
            <param-value>true</param-value>
        </init-param>
    </filter>
    
    <filter-mapping>
        <filter-name>encodingFilter</filter-name>
        <url-pattern>/*</url-pattern>
    </filter-mapping>
    
    <!-- Session Configuration -->
    <session-config>
        <session-timeout>30</session-timeout>
    </session-config>
    
    <!-- Welcome File List -->
    <welcome-file-list>
        <welcome-file>index.jsp</welcome-file>
        <welcome-file>index.html</welcome-file>
    </welcome-file-list>
    
</web-app>"""
    
    config_files['src/main/webapp/WEB-INF/web.xml'] = web_xml
    
    # 2. Spring MVC dispatcher configuration
    dispatcher_config = f"""<?xml version="1.0" encoding="UTF-8"?>
<beans xmlns="http://www.springframework.org/schema/beans"
       xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
       xmlns:context="http://www.springframework.org/schema/context"
       xmlns:mvc="http://www.springframework.org/schema/mvc"
       xsi:schemaLocation="
           http://www.springframework.org/schema/beans
           http://www.springframework.org/schema/beans/spring-beans.xsd
           http://www.springframework.org/schema/context
           http://www.springframework.org/schema/context/spring-context.xsd
           http://www.springframework.org/schema/mvc
           http://www.springframework.org/schema/mvc/spring-mvc.xsd">

    <!-- Enable component scanning -->
    <context:component-scan base-package="com.example" />
    
    <!-- Enable Spring MVC annotations -->
    <mvc:annotation-driven />
    
    <!-- Serve static resources -->
    <mvc:resources mapping="/resources/**" location="/resources/" />
    <mvc:resources mapping="/css/**" location="/css/" />
    <mvc:resources mapping="/js/**" location="/js/" />
    <mvc:resources mapping="/images/**" location="/images/" />
    
    <!-- JSP View Resolver -->
    <bean class="org.springframework.web.servlet.view.InternalResourceViewResolver">
        <property name="prefix" value="/WEB-INF/views/" />
        <property name="suffix" value=".jsp" />
        <property name="viewClass" value="org.springframework.web.servlet.view.JstlView" />
    </bean>
    
    <!-- Message Source for i18n -->
    <bean id="messageSource" class="org.springframework.context.support.ReloadableResourceBundleMessageSource">
        <property name="basename" value="/WEB-INF/messages" />
        <property name="defaultEncoding" value="UTF-8" />
    </bean>
    
</beans>"""
    
    config_files['src/main/webapp/WEB-INF/spring/dispatcher-config.xml'] = dispatcher_config
    
    return config_files


#//TODORAGJSP ENDS
