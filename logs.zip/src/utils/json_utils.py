"""
JSON parsing utilities for SmartUpgrade
Robust JSON parsing for LLM responses
"""

import json
import re
from typing import Dict, Any
from .logging_utils import add_agent_log

def robust_json_parse(response: str, agent_name: str = "LLM") -> Dict[str, Any]:
    """Robust JSON parsing that handles common LLM response issues"""
    original_response = response
    
    try:
        # First, try direct parsing
        result = json.loads(response)
        add_agent_log(agent_name, "✅ Direct JSON parsing succeeded", "info")
        return result
    except json.JSONDecodeError as direct_error:
        add_agent_log(agent_name, f"⚠️ Direct JSON parsing failed: {str(direct_error)}", "warning")
        
        # Method 1: Extract JSON from markdown code blocks
        json_pattern = r'```(?:json)?\s*(\{.*?\})\s*```'
        match = re.search(json_pattern, response, re.DOTALL | re.IGNORECASE)
        if match:
            try:
                result = json.loads(match.group(1))
                add_agent_log(agent_name, "✅ Successfully extracted JSON from code block", "info")
                return result
            except json.JSONDecodeError:
                add_agent_log(agent_name, "❌ Code block JSON also invalid", "warning")
        
        # Method 2: Find JSON objects starting with { and ending with }
        start_idx = response.find('{')
        if start_idx != -1:
            # Find the matching closing brace
            brace_count = 0
            end_idx = -1
            for i in range(start_idx, len(response)):
                if response[i] == '{':
                    brace_count += 1
                elif response[i] == '}':
                    brace_count -= 1
                    if brace_count == 0:
                        end_idx = i + 1
                        break
            
            if end_idx != -1:
                potential_json = response[start_idx:end_idx]
                try:
                    result = json.loads(potential_json)
                    add_agent_log(agent_name, "✅ Successfully parsed JSON from braces match", "info")
                    return result
                except json.JSONDecodeError:
                    add_agent_log(agent_name, "❌ Braces-matched JSON also invalid", "warning")
        
        # Method 3: Fix common JSON issues
        cleaned_response = response
        # Remove comments and extra text before/after JSON
        if '{' in cleaned_response and '}' in cleaned_response:
            start = cleaned_response.find('{')
            end = cleaned_response.rfind('}') + 1
            cleaned_response = cleaned_response[start:end]
        
        # Fix common issues
        cleaned_response = re.sub(r',\s*([}\]])', r'\1', cleaned_response)  # Remove trailing commas
        cleaned_response = re.sub(r'([a-zA-Z_]\w*)\s*:', r'"\1":', cleaned_response)  # Fix unquoted keys
        cleaned_response = cleaned_response.replace("'", '"')  # Fix single quotes
        cleaned_response = re.sub(r'\\"', '"', cleaned_response)  # Fix escaped quotes
        cleaned_response = re.sub(r'""', '"', cleaned_response)  # Fix double quotes
        
        try:
            result = json.loads(cleaned_response)
            add_agent_log(agent_name, "✅ JSON parsing succeeded after cleanup", "info")
            return result
        except json.JSONDecodeError as cleanup_error:
            add_agent_log(agent_name, f"❌ All JSON parsing methods failed. Cleanup error: {str(cleanup_error)}", "error")
        
        # Method 4: Create a structured fallback
        add_agent_log(agent_name, "🔧 Creating structured fallback from response content", "warning")
        
        fallback_data = create_fallback_structure(original_response, agent_name)
        if fallback_data and not fallback_data.get('error'):
            return fallback_data
        
        # Last resort: Return error structure
        add_agent_log(agent_name, f"🚨 CRITICAL: Returning error structure - LLM response unparseable", "error")
        return {
            "error": f"JSON parsing failed: {str(direct_error)}",
            "raw_response": original_response[:1000],
            "fallback": True,
            "agent": agent_name
        }

def create_fallback_structure(response_text: str, agent_name: str) -> Dict[str, Any]:
    """
    Create a basic structure from malformed LLM response by extracting key information
    """
    try:
        add_agent_log(agent_name, "🔧 Attempting to create fallback structure from response text", "info")
        
        # Extract key information using regex patterns
        frameworks = []
        technologies = []
        
        # Look for common framework mentions
        framework_patterns = [
            r'spring\s*boot\s*[\d.]*', r'spring\s*framework',
            r'hibernate', r'maven', r'gradle', r'junit'
        ]
        
        for pattern in framework_patterns:
            matches = re.findall(pattern, response_text, re.IGNORECASE)
            if matches:
                frameworks.extend([match.title() for match in matches])
        
        # Basic fallback structure
        fallback = {
            "frameworks": frameworks[:5] if frameworks else ["Java Application"],
            "technologies": technologies[:5] if technologies else ["Java Platform"],
            "java_version": "Unknown",
            "build_tool": "Maven" if "maven" in response_text.lower() else "Unknown",
            "modernization_priority": "Medium",
            "confidence_score": 30,
            "fallback": True
        }
        
        add_agent_log(agent_name, f"✅ Created fallback structure", "info")
        return fallback
        
    except Exception as e:
        add_agent_log(agent_name, f"❌ Failed to create fallback structure: {str(e)}", "error")
        return {
            "error": f"Fallback creation failed: {str(e)}",
            "fallback": True
        }