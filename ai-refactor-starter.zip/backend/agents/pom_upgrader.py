import os, re, requests
from lxml import etree

SPRING_BOOT_GROUP = "org.springframework.boot"
PARENT_ARTIFACT = "spring-boot-starter-parent"
BOM_ARTIFACT = "spring-boot-dependencies"

def _discover_latest_spring_boot():
    try:
        # Maven Central metadata for spring-boot parent is under spring-boot-starter-parent
        urls = [
            "https://repo1.maven.org/maven2/org/springframework/boot/spring-boot-starter-parent/maven-metadata.xml",
            "https://repo1.maven.org/maven2/org/springframework/boot/spring-boot-dependencies/maven-metadata.xml",
        ]
        versions = []
        for u in urls:
            r = requests.get(u, timeout=10)
            if r.ok:
                xml = etree.fromstring(r.content)
                latest = xml.xpath("string(//versioning/release)")
                if latest:
                    versions.append(latest.strip())
        if versions:
            # pick the highest version lexicographically (works for standard semver here)
            return sorted(versions)[-1]
    except Exception:
        pass
    return None

def _find_poms(root_dir):
    for dirpath, _, filenames in os.walk(root_dir):
        for fn in filenames:
            if fn == "pom.xml":
                yield os.path.join(dirpath, fn)

def _set_text(elem, new_text):
    if elem is not None:
        elem.text = new_text

def _upgrade_single_pom(pom_path, target_version):
    parser = etree.XMLParser(remove_blank_text=False)
    tree = etree.parse(pom_path, parser)
    root = tree.getroot()

    nsmap = root.nsmap.copy()
    ns = nsmap.get(None, "")
    N = "{%s}" % ns if ns else ""

    changed = False

    # 1) spring-boot-starter-parent <version>
    parent = root.find(f"{N}parent")
    if parent is not None:
        gid = parent.find(f"{N}groupId")
        aid = parent.find(f"{N}artifactId")
        ver = parent.find(f"{N}version")
        if gid is not None and aid is not None and ver is not None:
            if gid.text == SPRING_BOOT_GROUP and aid.text == PARENT_ARTIFACT and ver.text != target_version:
                _set_text(ver, target_version)
                changed = True

    # 2) dependencyManagement -> spring-boot-dependencies BOM
    dep_mgmt = root.find(f"{N}dependencyManagement")
    if dep_mgmt is not None:
        deps = dep_mgmt.find(f"{N}dependencies")
        if deps is not None:
            for d in deps.findall(f"{N}dependency"):
                gid = d.find(f"{N}groupId")
                aid = d.find(f"{N}artifactId")
                ver = d.find(f"{N}version")
                scope = d.find(f"{N}scope")
                if gid is not None and aid is not None and ver is not None:
                    if gid.text == SPRING_BOOT_GROUP and aid.text == BOM_ARTIFACT and ver.text != target_version:
                        _set_text(ver, target_version)
                        changed = True

    if changed:
        tree.write(pom_path, encoding="utf-8", xml_declaration=True, pretty_print=True)

    return changed

def upgrade_project_poms(project_root, target_version=None, autodiscover=True):
    """Upgrade Spring Boot versions across all pom.xml files.

    Returns a simple summary dict.
    """
    if not target_version and autodiscover:
        target_version = _discover_latest_spring_boot()
    if not target_version:
        # fallback sensible default
        target_version = "3.5.0"

    changed_files = []
    scanned = 0
    for pom in _find_poms(project_root):
        scanned += 1
        try:
            if _upgrade_single_pom(pom, target_version):
                changed_files.append(os.path.relpath(pom, project_root))
        except Exception as e:
            changed_files.append(f"{os.path.relpath(pom, project_root)} (ERROR: {e})")

    return {
        "targetVersion": target_version,
        "scannedPoms": scanned,
        "updatedFiles": changed_files,
    }
