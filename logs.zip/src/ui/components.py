"""
SmartUpgrade UI Components - ORIGINAL DESIGN MATCH
Streamlit interface components matching original app.py exactly
"""

import streamlit as st
import zipfile
import io
import tempfile
import os
from typing import Dict, Any, List, Optional
from datetime import datetime
from ..utils.security import SecurityValidator, SecureFileHandler

def initialize_streamlit():
    """Initialize Streamlit configuration with modern styling - EXACT ORIGINAL"""
    st.set_page_config(
        page_title="SmartUpgrade - Java Modernization Platform",
        page_icon="🚀",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Modern and colorful CSS styling - EXACT ORIGINAL
    st.markdown("""
    <style>
    /* Import Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    
    /* Global Styles */
    .main {
        font-family: 'Inter', sans-serif;
    }
    
    /* Header Styling */
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
        padding: 2rem;
        border-radius: 20px;
        margin-bottom: 2rem;
        box-shadow: 0 10px 30px rgba(102, 126, 234, 0.3);
        text-align: center;
    }
    
    .main-header h1 {
        color: white;
        margin: 0;
        font-size: 3rem;
        font-weight: 700;
        text-shadow: 0 2px 10px rgba(0,0,0,0.3);
    }
    
    .main-header p {
        color: rgba(255,255,255,0.9);
        margin: 0.5rem 0 0 0;
        font-size: 1.2rem;
        font-weight: 400;
    }
    
    /* Status Cards */
    .status-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        padding: 1.5rem;
        border-radius: 15px;
        margin: 1rem 0;
        box-shadow: 0 8px 25px rgba(102, 126, 234, 0.3);
        border: 1px solid rgba(255,255,255,0.2);
    }
    
    /* Agent Message Styling */
    .agent-message {
        padding: 1rem;
        margin: 0.5rem 0;
        border-radius: 15px;
        border-left: 5px solid #667eea;
        background: linear-gradient(135deg, #f8f9ff 0%, #e8f2ff 100%);
        box-shadow: 0 4px 15px rgba(102, 126, 234, 0.1);
        font-weight: 500;
    }
    
    .agent-message.info {
        border-left-color: #17a2b8;
        background: linear-gradient(135deg, #e8f8fc 0%, #d1f2f9 100%);
    }
    
    .agent-message.success {
        border-left-color: #28a745;
        background: linear-gradient(135deg, #e8f5e8 0%, #d4edda 100%);
    }
    
    .agent-message.warning {
        border-left-color: #ffc107;
        background: linear-gradient(135deg, #fff8e1 0%, #fff3cd 100%);
    }
    
    .agent-message.error {
        border-left-color: #dc3545;
        background: linear-gradient(135deg, #ffeaea 0%, #f8d7da 100%);
    }
    
    /* Metric Cards */
    .metric-card {
        background: linear-gradient(135deg, #ffffff 0%, #f8f9ff 100%);
        padding: 1.5rem;
        border-radius: 15px;
        box-shadow: 0 6px 20px rgba(0,0,0,0.08);
        margin: 1rem 0;
        border: 1px solid #e3e8f0;
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    
    .metric-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 12px 35px rgba(0,0,0,0.15);
    }
    
    /* Button Styling */
    .stButton > button {
        background: black;
        color: white;
        border: none;
        padding: 0.75rem 2rem;
        border-radius: 25px;
        font-weight: 600;
        box-shadow: 0 6px 20px rgba(102, 126, 234, 0.3);
        transition: all 0.3s ease;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 12px 30px rgba(102, 126, 234, 0.4);
    }
    
    /* Progress Bar Styling */
    .stProgress .st-bo {
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        height: 20px;
        border-radius: 10px;
    }
    </style>
    """, unsafe_allow_html=True)

def render_header():
    """Render the main application header - EXACT ORIGINAL"""
    st.markdown("""
    <div class="main-header">
        <h1>🚀 SmartUpgrade</h1>
        <p>Intelligent Java Application Modernization Platform</p>
        <p><em>AI-Powered Multi-Agent System for Comprehensive Java Modernization</em></p>
    </div>
    """, unsafe_allow_html=True)

def render_sidebar():
    """Render the sidebar with navigation and controls - ORIGINAL STYLE"""
    with st.sidebar:
        st.markdown("### 🎛️ Control Panel")
        
        # Provider selection
        from ..api_providers.provider_factory import provider_manager
        
        if hasattr(provider_manager, 'get_available_providers'):
            available_providers = provider_manager.get_available_providers()
            if available_providers:
                selected_provider = st.selectbox(
                    "🤖 AI Provider",
                    available_providers,
                    index=0 if available_providers else None
                )
                
                if st.button("Switch Provider"):
                    provider_manager.set_provider(selected_provider)
                    st.success(f"✅ Switched to {selected_provider}")
        
        st.divider()
        
        # Project status - ORIGINAL FORMAT
        st.markdown("### 📊 Project Status")
        
        if 'project_path' in st.session_state:
            st.success(f"✅ Project: {st.session_state.get('project_name', 'Unknown')}")
            
            if 'analysis_results' in st.session_state:
                st.success("🔍 Analysis Complete")
            
            if 'planning_results' in st.session_state:
                st.success("📋 Planning Complete")
        else:
            st.info("ℹ️ No project selected")

def add_agent_log(agent_name: str, message: str, message_type: str = "info"):
    """Add a log message for an agent - ORIGINAL FUNCTIONALITY"""
    if 'agent_logs' not in st.session_state:
        st.session_state.agent_logs = []
    
    timestamp = datetime.now().strftime("%H:%M:%S")
    log_entry = {
        'timestamp': timestamp,
        'agent': agent_name,
        'message': message,
        'type': message_type
    }
    
    st.session_state.agent_logs.append(log_entry)
    
    # Display the latest message immediately
    if message_type == "success":
        st.success(f"**{agent_name}** ({timestamp}): {message}")
    elif message_type == "error":
        st.error(f"**{agent_name}** ({timestamp}): {message}")
    elif message_type == "warning":
        st.warning(f"**{agent_name}** ({timestamp}): {message}")
    else:
        st.info(f"**{agent_name}** ({timestamp}): {message}")

def handle_file_upload():
    """Handle file upload with proper validation - SECURE VERSION"""
    uploaded_files = st.file_uploader(
        "📁 Upload Java project files (ZIP or individual files)",
        type=['zip', 'java', 'xml', 'properties', 'txt'],
        accept_multiple_files=True,
        help="Upload your Java project as a ZIP file or individual Java files"
    )
    
    if uploaded_files:
        # Input validation
        MAX_FILE_SIZE = 100 * 1024 * 1024  # 100MB limit
        MAX_FILES = 50  # Maximum number of files
        ALLOWED_EXTENSIONS = {'.zip', '.java', '.xml', '.properties', '.txt'}
        
        if len(uploaded_files) > MAX_FILES:
            st.error(f"❌ Too many files uploaded. Maximum allowed: {MAX_FILES}")
            return False
        
        # Create temporary directory
        temp_dir = tempfile.mkdtemp()
        st.session_state.temp_dir = temp_dir
        
        for uploaded_file in uploaded_files:
            # Validate file name and extension
            if not uploaded_file.name or len(uploaded_file.name) > 255:
                st.error(f"❌ Invalid filename: {uploaded_file.name}")
                continue
                
            file_ext = os.path.splitext(uploaded_file.name)[1].lower()
            if file_ext not in ALLOWED_EXTENSIONS:
                st.error(f"❌ File type not allowed: {file_ext}")
                continue
                
            # Validate file size
            file_size = len(uploaded_file.getvalue())
            if file_size > MAX_FILE_SIZE:
                st.error(f"❌ File too large: {uploaded_file.name} ({file_size:,} bytes)")
                continue
            
            # Sanitize filename to prevent path traversal
            safe_filename = os.path.basename(uploaded_file.name)
            safe_filename = "".join(c for c in safe_filename if c.isalnum() or c in ".-_")
            
            if uploaded_file.name.endswith('.zip'):
                try:
                    # Secure ZIP extraction with validation
                    with zipfile.ZipFile(uploaded_file, 'r') as zip_ref:
                        # Check for zip bomb and path traversal
                        total_size = 0
                        for info in zip_ref.infolist():
                            # Prevent path traversal attacks
                            if os.path.isabs(info.filename) or ".." in info.filename:
                                st.error(f"❌ Unsafe path in ZIP: {info.filename}")
                                continue
                            # Prevent zip bombs
                            total_size += info.file_size
                            if total_size > MAX_FILE_SIZE * 5:  # 5x compression ratio limit
                                st.error("❌ ZIP file appears to be compressed bomb")
                                break
                        else:
                            zip_ref.extractall(temp_dir)
                            st.success(f"✅ Extracted ZIP: {safe_filename}")
                except (zipfile.BadZipFile, zipfile.LargeZipFile) as e:
                    st.error(f"❌ Invalid ZIP file: {safe_filename}")
                    continue
            else:
                # Save individual file with validation
                try:
                    file_path = os.path.join(temp_dir, safe_filename)
                    # Ensure path is within temp directory
                    if not os.path.commonpath([temp_dir, file_path]) == temp_dir:
                        st.error(f"❌ Invalid file path: {safe_filename}")
                        continue
                        
                    with open(file_path, 'wb') as f:
                        f.write(uploaded_file.getbuffer())
                    st.success(f"✅ Uploaded: {safe_filename}")
                except (IOError, OSError) as e:
                    st.error(f"❌ Failed to save file: {safe_filename}")
                    continue
        
        # Set project path with validation
        project_name = "Uploaded Files"
        if len(uploaded_files) == 1 and uploaded_files[0].name.endswith('.zip'):
            # Sanitize project name
            raw_name = uploaded_files[0].name.replace('.zip', '')
            project_name = "".join(c for c in raw_name if c.isalnum() or c in " -_")[:100]
        
        st.session_state.project_path = temp_dir
        st.session_state.project_name = project_name
        
        return True
    return False

def render_project_actions():
    """Render project action buttons - ORIGINAL LAYOUT"""
    if 'project_path' not in st.session_state:
        st.info("📁 Please upload your Java project files first")
        return False
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        analyze_clicked = st.button(
            "🔍 Start Analysis", 
            use_container_width=True,
            help="Analyze the Java project structure and dependencies"
        )
    
    with col2:
        plan_clicked = st.button(
            "📋 Create Migration Plan", 
            use_container_width=True,
            disabled='analysis_results' not in st.session_state,
            help="Create a detailed migration plan (requires analysis first)"
        )
    
    with col3:
        quality_clicked = st.button(
            "🛡️ Quality Check", 
            use_container_width=True,
            disabled='planning_results' not in st.session_state,
            help="Perform quality inspection (requires migration plan)"
        )
    
    return analyze_clicked, plan_clicked, quality_clicked

def render_analysis_results(results: Dict[str, Any]):
    """Render analysis results - ORIGINAL FORMAT"""
    if not results:
        return
    
    st.markdown("### 🔍 Analysis Results")
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Java Files", results.get('java_files_count', 0))
    with col2:
        st.metric("Dependencies", len(results.get('dependencies', [])))
    with col3:
        st.metric("Issues Found", results.get('issues_count', 0))
    with col4:
        st.metric("Complexity Score", f"{results.get('complexity_score', 0)}/10")
    
    # Detailed results in tabs
    tab1, tab2, tab3 = st.tabs(["📊 Overview", "🔗 Dependencies", "⚠️ Issues"])
    
    with tab1:
        if 'project_structure' in results:
            st.markdown("#### Project Structure")
            st.json(results['project_structure'])
    
    with tab2:
        if 'dependencies' in results:
            st.markdown("#### Dependencies")
            for dep in results['dependencies'][:10]:  # Show first 10
                st.markdown(f"- `{dep}`")
    
    with tab3:
        if 'issues' in results:
            st.markdown("#### Issues Found")
            for issue in results['issues'][:10]:  # Show first 10
                issue_type = issue.get('type', 'info')
                if issue_type == 'error':
                    st.error(f"❌ {issue.get('message', '')}")
                elif issue_type == 'warning':
                    st.warning(f"⚠️ {issue.get('message', '')}")
                else:
                    st.info(f"ℹ️ {issue.get('message', '')}")

def render_planning_results(results: Dict[str, Any]):
    """Render planning results - ORIGINAL FORMAT"""
    if not results:
        return
    
    st.markdown("### 📋 Migration Plan")
    
    # Plan overview
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.metric("Total Tasks", len(results.get('tasks', [])))
    with col2:
        st.metric("Estimated Time", f"{results.get('estimated_hours', 0)}h")
    with col3:
        st.metric("Complexity", results.get('complexity_level', 'Medium'))
    
    # Plan details
    if 'tasks' in results:
        st.markdown("#### Migration Tasks")
        for i, task in enumerate(results['tasks'][:10], 1):  # Show first 10
            with st.expander(f"{i}. {task.get('title', 'Task')}"):
                st.markdown(f"**Priority:** {task.get('priority', 'Medium')}")
                st.markdown(f"**Estimated Time:** {task.get('estimated_time', 'TBD')}")
                st.markdown(f"**Description:** {task.get('description', 'No description available')}")
    
    # Migration strategy
    if 'strategy' in results:
        st.markdown("#### Migration Strategy")
        st.markdown(results['strategy'])

def render_quality_results(results: Dict[str, Any]):
    """Render quality inspection results - ORIGINAL FORMAT"""
    if not results:
        return
    
    st.markdown("### 🛡️ Quality Inspection Results")
    
    # Quality metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        quality_score = results.get('quality_score', 0)
        st.metric("Quality Score", f"{quality_score}/10")
    with col2:
        st.metric("Code Coverage", f"{results.get('coverage', 0)}%")
    with col3:
        st.metric("Security Issues", results.get('security_issues', 0))
    with col4:
        st.metric("Performance Issues", results.get('performance_issues', 0))
    
    # Quality details
    if 'recommendations' in results:
        st.markdown("#### Recommendations")
        for rec in results['recommendations'][:10]:  # Show first 10
            rec_type = rec.get('type', 'info')
            if rec_type == 'critical':
                st.error(f"🚨 {rec.get('message', '')}")
            elif rec_type == 'warning':
                st.warning(f"⚠️ {rec.get('message', '')}")
            else:
                st.info(f"💡 {rec.get('message', '')}")

def display_agent_logs():
    """Display agent logs in the main area - ORIGINAL BEHAVIOR"""
    # Initialize logs if not present
    if 'agent_logs' not in st.session_state:
        st.session_state.agent_logs = []
        # Add initial welcome logs
        add_agent_log("SmartUpgrade", "Platform initialized successfully", "success")
        add_agent_log("System", "Ready for Java modernization", "info")
    
    if not st.session_state.agent_logs:
        st.info("No agent activity yet. Start by uploading a project and running analysis.")
        return
    
    st.markdown("### 🤖 Agent Activity Log")
    
    # Show recent logs (last 20)
    recent_logs = st.session_state.agent_logs[-20:]
    
    for log in reversed(recent_logs):  # Show newest first
        # Safely get all log properties
        timestamp = log.get('timestamp', datetime.now().strftime("%H:%M:%S"))
        agent = log.get('agent', 'System')
        message = log.get('message', 'No message')
        # Handle both 'level' and 'type' keys for backward compatibility
        log_type = log.get('level', log.get('type', 'info'))
        
        # Display log with appropriate styling
        try:
            if log_type == "success":
                st.success(f"**{agent}** ({timestamp}): {message}")
            elif log_type == "error":
                st.error(f"**{agent}** ({timestamp}): {message}")
            elif log_type == "warning":
                st.warning(f"**{agent}** ({timestamp}): {message}")
            else:
                st.info(f"**{agent}** ({timestamp}): {message}")
        except Exception as e:
            # Fallback if there's any issue with log display
            st.text(f"[{timestamp}] {agent}: {message}")

def show_progress(message: str, progress: float):
    """Show progress bar with message - ORIGINAL STYLE"""
    st.markdown(f"**{message}**")
    progress_bar = st.progress(progress)
    return progress_bar

def clear_session_state():
    """Clear session state for new project - ORIGINAL FUNCTIONALITY"""
    keys_to_clear = [
        'project_path', 'project_name', 'analysis_results', 
        'planning_results', 'quality_results', 'agent_logs',
        'temp_dir'
    ]
    
    for key in keys_to_clear:
        if key in st.session_state:
            del st.session_state[key]