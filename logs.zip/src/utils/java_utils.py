"""
Java code analysis utilities
Functions for extracting information from Java source files
"""

import re
from typing import List, Dict, Any


def extract_package_name(java_content: str) -> str:
    """Extract package name from Java file content"""
    match = re.search(r'package\s+([\w\.]+);', java_content)
    return match.group(1) if match else 'default'


def extract_imports(java_content: str) -> List[str]:
    """Extract import statements from Java file content"""
    imports = re.findall(r'import\s+([\w\.\*]+);', java_content)
    return imports


def extract_class_names(java_content: str) -> List[str]:
    """Extract class names from Java file content"""
    classes = re.findall(r'(?:public\s+)?class\s+(\w+)', java_content)
    return classes


def extract_annotations(content: str) -> List[str]:
    """Extract Java annotations from code"""
    annotations = re.findall(r'@([A-Za-z_][A-Za-z0-9_]*)', content)
    return list(set(annotations))


def extract_method_signatures(content: str) -> List[str]:
    """Extract method signatures from Java code"""
    method_pattern = r'(?:public|private|protected)?\s*(?:static\s+)?(?:final\s+)?(?:synchronized\s+)?[\w<>[\]]+\s+(\w+)\s*\([^)]*\)'
    methods = re.findall(method_pattern, content)
    return methods


def extract_spring_components(content: str) -> List[str]:
    """Extract Spring framework components and annotations"""
    spring_annotations = [
        'Controller', 'RestController', 'Service', 'Repository', 'Component',
        'Configuration', 'Bean', 'Autowired', 'RequestMapping', 'GetMapping',
        'PostMapping', 'PutMapping', 'DeleteMapping', 'PathVariable',
        'RequestParam', 'RequestBody', 'ResponseBody', 'CrossOrigin'
    ]
    
    found_components = []
    for annotation in spring_annotations:
        pattern = f'@{annotation}'
        if pattern in content:
            found_components.append(annotation)
    
    return found_components


def extract_dependencies_from_build_file(content: str, filename: str) -> List[Dict[str, str]]:
    """Extract dependencies from build files"""
    dependencies = []
    
    if filename.endswith('pom.xml'):
        # Maven dependencies
        dep_pattern = r'<dependency>.*?<groupId>(.*?)</groupId>.*?<artifactId>(.*?)</artifactId>(?:.*?<version>(.*?)</version>)?.*?</dependency>'
        matches = re.findall(dep_pattern, content, re.DOTALL)
        for match in matches:
            dep = {
                'type': 'maven',
                'groupId': match[0],
                'artifactId': match[1],
                'version': match[2] if len(match) > 2 and match[2] else 'not specified'
            }
            dependencies.append(dep)
    
    elif filename.endswith('build.gradle'):
        # Gradle dependencies
        # Simple implementation for common patterns
        gradle_patterns = [
            r"implementation\s+['\"]([^'\"]+)['\"]",
            r"compile\s+['\"]([^'\"]+)['\"]",
            r"testImplementation\s+['\"]([^'\"]+)['\"]"
        ]
        
        for pattern in gradle_patterns:
            matches = re.findall(pattern, content)
            for match in matches:
                parts = match.split(':')
                if len(parts) >= 2:
                    dep = {
                        'type': 'gradle',
                        'groupId': parts[0],
                        'artifactId': parts[1],
                        'version': parts[2] if len(parts) > 2 else 'not specified'
                    }
                    dependencies.append(dep)
    
    return dependencies


def calculate_timeline_from_tasks(task_breakdown: Dict[str, Any]) -> str:
    """Calculate timeline based on task complexity"""
    if not task_breakdown or 'phases' not in task_breakdown:
        return "2-4 weeks"
    
    phases = task_breakdown.get('phases', [])
    total_weeks = 0
    
    for phase in phases:
        if isinstance(phase, dict):
            duration = phase.get('duration', '1 week')
            if 'week' in duration:
                weeks = int(re.findall(r'\d+', duration)[0]) if re.findall(r'\d+', duration) else 1
                total_weeks += weeks
    
    return f"{total_weeks} weeks" if total_weeks > 0 else "2-4 weeks"


def calculate_timeline_from_phases(strategy_results: Dict[str, Any]) -> str:
    """Calculate timeline based on migration phases and project complexity"""
    if not strategy_results:
        return "3-6 weeks"
    
    # Base timeline on project size and complexity
    project_complexity = strategy_results.get('project_complexity', 'medium')
    
    if project_complexity == 'low':
        return "2-3 weeks"
    elif project_complexity == 'medium':
        return "4-6 weeks"
    elif project_complexity == 'high':
        return "6-10 weeks"
    else:
        return "4-8 weeks"


def validate_java_file_consistency(file_content: str, expected_filename: str, expected_package: str = None) -> Dict[str, Any]:
    """
    Validate that Java file content is consistent with filename and package structure
    
    Args:
        file_content: Content of the Java file
        expected_filename: Expected filename without .java extension
        expected_package: Expected package name (optional)
        
    Returns:
        Dictionary with validation results and extracted metadata
    """
    result = {
        'valid': True,
        'issues': [],
        'extracted_package': None,
        'extracted_class_name': None,
        'suggested_filename': None,
        'suggested_package': None
    }
    
    # Extract package name
    package_match = re.search(r'package\s+([\w\.]+)\s*;', file_content)
    if package_match:
        result['extracted_package'] = package_match.group(1)
    else:
        result['issues'].append('No package declaration found')
        result['valid'] = False
    
    # Extract public class name
    class_match = re.search(r'public\s+class\s+(\w+)', file_content)
    if class_match:
        result['extracted_class_name'] = class_match.group(1)
    else:
        # Try without public modifier
        class_match = re.search(r'class\s+(\w+)', file_content)
        if class_match:
            result['extracted_class_name'] = class_match.group(1)
            result['issues'].append('Class is not public')
        else:
            result['issues'].append('No class declaration found')
            result['valid'] = False
    
    # Validate class name matches filename
    if result['extracted_class_name'] and result['extracted_class_name'] != expected_filename:
        result['issues'].append(
            f"Class name '{result['extracted_class_name']}' does not match filename '{expected_filename}'"
        )
        result['suggested_filename'] = result['extracted_class_name']
        result['valid'] = False
    
    # Validate package if provided
    if expected_package and result['extracted_package']:
        if result['extracted_package'] != expected_package:
            result['issues'].append(
                f"Package '{result['extracted_package']}' does not match expected '{expected_package}'"
            )
            result['suggested_package'] = expected_package
            result['valid'] = False
    
    return result


def correct_java_file_naming(file_content: str, original_filename: str, original_package: str) -> Dict[str, Any]:
    """
    Correct Java file naming issues by adjusting class name or suggesting file rename
    
    Args:
        file_content: Content of the Java file
        original_filename: Original filename without .java extension
        original_package: Original package name
        
    Returns:
        Dictionary with corrected content and metadata
    """
    result = {
        'corrected_content': file_content,
        'new_filename': original_filename,
        'package_corrected': False,
        'class_name_corrected': False,
        'file_renamed': False,
        'corrections_applied': []
    }
    
    validation = validate_java_file_consistency(file_content, original_filename, original_package)
    
    if validation['valid']:
        return result
    
    corrected_content = file_content
    
    # Correct package declaration if wrong
    if validation['extracted_package'] and validation['extracted_package'] != original_package:
        corrected_content = re.sub(
            r'package\s+[\w\.]+\s*;',
            f'package {original_package};',
            corrected_content
        )
        result['package_corrected'] = True
        result['corrections_applied'].append(f"Package corrected to '{original_package}'")
    
    # Handle class name mismatch - suggest file rename if it's a semantic rename (e.g., Action -> Controller)
    if validation['extracted_class_name'] and validation['extracted_class_name'] != original_filename:
        extracted_class = validation['extracted_class_name']
        
        # Check if this is a semantic modernization (Action -> Controller, etc.)
        is_semantic_rename = (
            (original_filename.endswith('Action') and extracted_class.endswith('Controller')) or
            (original_filename.endswith('Service') and extracted_class.endswith('ServiceImpl')) or
            (original_filename.endswith('Dao') and extracted_class.endswith('Repository')) or
            (original_filename.endswith('Bean') and extracted_class.endswith('Entity'))
        )
        
        if is_semantic_rename:
            # This is a valid modernization - keep the new class name and rename file
            result['new_filename'] = extracted_class
            result['file_renamed'] = True
            result['corrections_applied'].append(
                f"File renamed from '{original_filename}.java' to '{extracted_class}.java' (semantic modernization)"
            )
        else:
            # This is an error - correct the class name to match filename
            corrected_content = re.sub(
                r'(public\s+)?class\s+\w+',
                f'public class {original_filename}',
                corrected_content,
                count=1
            )
            result['class_name_corrected'] = True
            result['corrections_applied'].append(f"Class name corrected to '{original_filename}'")
    
    result['corrected_content'] = corrected_content
    return result


def extract_original_metadata(file_path: str, file_content: str) -> Dict[str, str]:
    """
    Extract original metadata from Java file
    
    Args:
        file_path: Full path to the Java file
        file_content: Content of the file
        
    Returns:
        Dictionary with original metadata
    """
    import os
    
    metadata = {
        'filename': os.path.basename(file_path).replace('.java', ''),
        'package': extract_package_name(file_content),
        'class_names': extract_class_names(file_content),
        'primary_class': None
    }
    
    # Identify primary class (usually matches filename)
    if metadata['class_names']:
        filename_without_ext = metadata['filename']
        if filename_without_ext in metadata['class_names']:
            metadata['primary_class'] = filename_without_ext
        else:
            # Use first public class or first class
            metadata['primary_class'] = metadata['class_names'][0]
    
    return metadata