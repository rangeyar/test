"""
Test script for Java file validation and correction utilities
Run this to verify the validation logic works correctly
"""

from src.utils.java_utils import (
    validate_java_file_consistency,
    correct_java_file_naming,
    extract_original_metadata
)

def test_case_1_filename_class_mismatch():
    """Test: File named ListCountryAction but class is ListCountryController"""
    print("\n" + "="*70)
    print("TEST 1: Semantic Rename - Action to Controller")
    print("="*70)
    
    code = """package com.empresa.struts.actions;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ListCountryController {
    public String execute(HttpServletRequest request) {
        return "success";
    }
}
"""
    
    original_filename = "ListCountryAction"
    original_package = "com.empresa.struts.actions"
    
    print(f"Original Filename: {original_filename}.java")
    print(f"Expected Package: {original_package}")
    print(f"Generated Code contains: class ListCountryController")
    
    # Validate
    validation = validate_java_file_consistency(code, original_filename, original_package)
    print(f"\n✓ Validation Result: {'VALID' if validation['valid'] else 'INVALID'}")
    print(f"  - Extracted Package: {validation['extracted_package']}")
    print(f"  - Extracted Class: {validation['extracted_class_name']}")
    if validation['issues']:
        print(f"  - Issues Found: {len(validation['issues'])}")
        for issue in validation['issues']:
            print(f"    • {issue}")
    
    # Correct
    correction = correct_java_file_naming(code, original_filename, original_package)
    print(f"\n✓ Correction Result:")
    print(f"  - New Filename: {correction['new_filename']}.java")
    print(f"  - File Renamed: {correction['file_renamed']}")
    print(f"  - Package Corrected: {correction['package_corrected']}")
    print(f"  - Class Name Corrected: {correction['class_name_corrected']}")
    if correction['corrections_applied']:
        print(f"  - Corrections Applied:")
        for corr in correction['corrections_applied']:
            print(f"    • {corr}")
    
    assert correction['file_renamed'] == True, "Should rename file for semantic modernization"
    assert correction['new_filename'] == "ListCountryController", "Should rename to ListCountryController"
    print("\n✅ TEST 1 PASSED")


def test_case_2_wrong_package():
    """Test: Wrong package declaration"""
    print("\n" + "="*70)
    print("TEST 2: Wrong Package Declaration")
    print("="*70)
    
    code = """package com.empresa.controller;

import jakarta.servlet.http.HttpServletRequest;

public class ListCountryAction {
    public String execute(HttpServletRequest request) {
        return "success";
    }
}
"""
    
    original_filename = "ListCountryAction"
    original_package = "com.empresa.struts.actions"
    
    print(f"Original Filename: {original_filename}.java")
    print(f"Expected Package: {original_package}")
    print(f"Generated Code has: package com.empresa.controller;")
    
    # Validate
    validation = validate_java_file_consistency(code, original_filename, original_package)
    print(f"\n✓ Validation Result: {'VALID' if validation['valid'] else 'INVALID'}")
    if validation['issues']:
        print(f"  - Issues Found:")
        for issue in validation['issues']:
            print(f"    • {issue}")
    
    # Correct
    correction = correct_java_file_naming(code, original_filename, original_package)
    print(f"\n✓ Correction Result:")
    print(f"  - Package Corrected: {correction['package_corrected']}")
    if correction['corrections_applied']:
        print(f"  - Corrections Applied:")
        for corr in correction['corrections_applied']:
            print(f"    • {corr}")
    
    # Verify package was corrected in content
    assert original_package in correction['corrected_content'], "Package should be corrected"
    assert correction['package_corrected'] == True, "Package correction flag should be True"
    print("\n✅ TEST 2 PASSED")


def test_case_3_all_correct():
    """Test: Everything is correct"""
    print("\n" + "="*70)
    print("TEST 3: Valid Code - No Corrections Needed")
    print("="*70)
    
    code = """package com.empresa.struts.actions;

import jakarta.servlet.http.HttpServletRequest;

public class ListCountryAction {
    public String execute(HttpServletRequest request) {
        return "success";
    }
}
"""
    
    original_filename = "ListCountryAction"
    original_package = "com.empresa.struts.actions"
    
    print(f"Original Filename: {original_filename}.java")
    print(f"Expected Package: {original_package}")
    print(f"Generated Code: All correct!")
    
    # Validate
    validation = validate_java_file_consistency(code, original_filename, original_package)
    print(f"\n✓ Validation Result: {'VALID' if validation['valid'] else 'INVALID'}")
    
    # Correct
    correction = correct_java_file_naming(code, original_filename, original_package)
    print(f"\n✓ Correction Result:")
    print(f"  - Corrections Applied: {len(correction['corrections_applied'])}")
    
    assert validation['valid'] == True, "Should be valid"
    assert len(correction['corrections_applied']) == 0, "Should have no corrections"
    print("\n✅ TEST 3 PASSED")


def test_case_4_multiple_issues():
    """Test: Multiple issues - wrong package and wrong class name"""
    print("\n" + "="*70)
    print("TEST 4: Multiple Issues - Package + Class Name")
    print("="*70)
    
    code = """package com.wrong.package;

import jakarta.servlet.http.HttpServletRequest;

public class WrongClassName {
    public String execute(HttpServletRequest request) {
        return "success";
    }
}
"""
    
    original_filename = "ListCountryAction"
    original_package = "com.empresa.struts.actions"
    
    print(f"Original Filename: {original_filename}.java")
    print(f"Expected Package: {original_package}")
    print(f"Generated Code: Wrong package AND wrong class name")
    
    # Validate
    validation = validate_java_file_consistency(code, original_filename, original_package)
    print(f"\n✓ Validation Result: {'VALID' if validation['valid'] else 'INVALID'}")
    if validation['issues']:
        print(f"  - Issues Found:")
        for issue in validation['issues']:
            print(f"    • {issue}")
    
    # Correct
    correction = correct_java_file_naming(code, original_filename, original_package)
    print(f"\n✓ Correction Result:")
    if correction['corrections_applied']:
        print(f"  - Corrections Applied:")
        for corr in correction['corrections_applied']:
            print(f"    • {corr}")
    
    assert correction['package_corrected'] == True, "Package should be corrected"
    assert correction['class_name_corrected'] == True, "Class name should be corrected"
    assert original_package in correction['corrected_content'], "Package should be in corrected content"
    assert f"class {original_filename}" in correction['corrected_content'], "Class name should be corrected"
    print("\n✅ TEST 4 PASSED")


def run_all_tests():
    """Run all test cases"""
    print("\n" + "="*70)
    print("JAVA FILE VALIDATION & CORRECTION - TEST SUITE")
    print("="*70)
    
    try:
        test_case_1_filename_class_mismatch()
        test_case_2_wrong_package()
        test_case_3_all_correct()
        test_case_4_multiple_issues()
        
        print("\n" + "="*70)
        print("🎉 ALL TESTS PASSED!")
        print("="*70)
        print("\nThe validation and correction utilities are working correctly.")
        print("Your SmartUpgrade system will now:")
        print("  ✓ Validate all LLM-generated code")
        print("  ✓ Automatically fix package declarations")
        print("  ✓ Handle semantic renames (Action→Controller)")
        print("  ✓ Ensure filename and class name consistency")
        print("  ✓ Generate buildable Java projects")
        
    except AssertionError as e:
        print(f"\n❌ TEST FAILED: {e}")
        return False
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True


if __name__ == "__main__":
    success = run_all_tests()
    exit(0 if success else 1)
