"""
Authentication Service Module
Handles secure communication with the parent UI system and orchestrates token validation workflows.
"""

import streamlit as st
from msgpassing import listen_for_parameters
import requests
from src.utils.saml_validator import validate_token_and_get_role


def is_server_running(url):
    """
    Checks if a server is running by sending a GET request to the specified URL.
    
    This function attempts to make an HTTP GET request to the provided URL with a 
    timeout limit of 3 seconds. If the server responds with a status code of 200, 
    it is considered running. In case of a connection issue, timeout, or any 
    request-related error, the function will return False.
    
    Args:
        url (str): The URL of the server to check.
    
    Returns:
        bool: True if the server is running and returns a status code of 200, 
              False otherwise.
    """
    try:
        response = requests.get(url, timeout=3)
        return response.status_code == 200
    except requests.exceptions.RequestException:
        return False


def check_auth(web_url=None, env="local"):
    """
    Checks the authentication of a user by verifying the token and role data 
    provided by an external server or a locally configured endpoint.
    
    Summary:
        This function performs authentication by contacting an external server or 
        a local endpoint to retrieve authentication parameters and validate the user's 
        token. It adapts the server endpoint based on the provided environment and 
        ensures the server is accessible before proceeding. The function checks the 
        integrity and validity of the token and provides detailed feedback on the 
        authentication status, ensuring that the user is properly informed in case 
        of any failures.
    
    Arguments:
        web_url (str, optional): The URL of the authentication server. Defaults to 
                                None, and if not provided, a suitable URL will be 
                                derived based on the environment.
        env (str): The environment context in which the server is running. 
                  Defaults to "local". Valid options are "local", "dev", and "prod".
    
    Returns:
        bool: True if the authentication is successful; False otherwise.
    """
    if web_url is None:
        # Configure environment-specific authentication endpoints
        if env == "local":
            web_url = "http://localhost:8000"
        elif env == "dev":
            web_url = "http://dev.orchestrateai.tech"
        elif env == "prod":
            web_url = "http://internal.orchestrateai.tech"
        else:
            web_url = "http://localhost:8000"  # Default fallback configuration
    
    if not is_server_running(web_url):
        st.error(f"Authentication server unavailable: {web_url}")
        st.error("Authentication failed. Please verify server connectivity.")
        return False
    
    data = listen_for_parameters(web_url=web_url)
    
    if data is None:
        st.error("Failed to retrieve authentication parameters from server.")
        st.error("Authentication failed. Please verify your credentials.")
        return False
    
    response = validate_token_and_get_role(data.get("token"))
    
    if response.get("isValid") is not True:
        print("Authentication failed: Invalid or expired token")
        
        if response.get("isTampered"):
            st.error("Security Alert: Token integrity violation detected")
        
        # Display standardized access denial interface
        st.markdown("""
        <div style="text-align: center; margin-top: 50px;">
            <h1 style="color: #d32f2f;">Access Denied</h1>
            <p style="font-size: 18px;">You do not have permission to access this application.</p>
            <p>Please contact your system administrator for assistance.</p>
        </div>
        """, unsafe_allow_html=True)
        
        return False
    
    return True
