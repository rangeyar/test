# SmartUpgrade Build Script (Windows PowerShell)
# Python equivalent to Maven with license-maven-plugin

param(
    [string]$Goal = "all",
    [switch]$Help
)

function Write-Phase {
    param([string]$Message)
    Write-Host "`n🔄 $Message" -ForegroundColor Cyan
    Write-Host ("=" * 50) -ForegroundColor Cyan
}

function Write-Success {
    param([string]$Message)
    Write-Host "✅ $Message" -ForegroundColor Green
}

function Write-Error {
    param([string]$Message)
    Write-Host "❌ $Message" -ForegroundColor Red
}

function Write-Warning {
    param([string]$Message)
    Write-Host "⚠️ $Message" -ForegroundColor Yellow
}

function Invoke-LicenseDownload {
    Write-Phase "License Download (download-licenses goal)"
    
    try {
        $result = & python license_maven_plugin.py download-licenses
        if ($LASTEXITCODE -eq 0) {
            Write-Success "License download completed"
            return $true
        } else {
            Write-Error "License download failed"
            return $false
        }
    } catch {
        Write-Error "Error executing license download: $_"
        return $false
    }
}

function Invoke-LicenseCheck {
    Write-Phase "License Validation (check-licenses goal)"
    
    try {
        $result = & python license_maven_plugin.py check-licenses
        if ($LASTEXITCODE -eq 0) {
            Write-Success "License validation passed"
            return $true
        } else {
            Write-Error "License validation failed"
            return $false
        }
    } catch {
        Write-Error "Error executing license check: $_"
        return $false
    }
}

function Invoke-ValidatePhase {
    Write-Phase "VALIDATE PHASE"
    
    # Install required tools
    Write-Host "📦 Installing license tools..."
    try {
        & python -m pip install pip-licenses toml --quiet
        Write-Success "License tools installed"
    } catch {
        Write-Warning "Could not install license tools: $_"
    }
    
    # Execute license plugin goals
    $downloadSuccess = Invoke-LicenseDownload
    $checkSuccess = Invoke-LicenseCheck
    
    return ($downloadSuccess -and $checkSuccess)
}

function Invoke-CompilePhase {
    Write-Phase "COMPILE PHASE"
    
    $pythonFiles = @("app.py", "license_maven_plugin.py", "build.py")
    
    foreach ($file in $pythonFiles) {
        if (Test-Path $file) {
            try {
                & python -m py_compile $file
                Write-Success "Compiled: $file"
            } catch {
                Write-Error "Compilation failed: $file"
                return $false
            }
        }
    }
    
    Write-Success "All Python files compiled successfully"
    return $true
}

function Invoke-TestPhase {
    Write-Phase "TEST PHASE"
    
    try {
        & python -m pytest --tb=short
        if ($LASTEXITCODE -eq 0) {
            Write-Success "All tests passed"
        } else {
            Write-Warning "Some tests failed or no tests found"
        }
    } catch {
        Write-Warning "pytest not available or no tests found"
    }
    
    return $true
}

function Invoke-PackagePhase {
    Write-Phase "PACKAGE PHASE"
    
    if (Test-Path "setup.py") {
        try {
            & python setup.py sdist bdist_wheel
            Write-Success "Distribution packages created"
        } catch {
            Write-Error "Package creation failed: $_"
            return $false
        }
    } else {
        Write-Warning "No setup.py found, skipping package creation"
    }
    
    return $true
}

function Invoke-CleanPhase {
    Write-Phase "CLEAN PHASE"
    
    $cleanDirs = @("target", "build", "dist", "__pycache__", ".pytest_cache")
    
    foreach ($dir in $cleanDirs) {
        if (Test-Path $dir) {
            Remove-Item $dir -Recurse -Force -ErrorAction SilentlyContinue
            Write-Success "Removed: $dir"
        }
    }
    
    # Clean .pyc files
    Get-ChildItem -Path . -Recurse -Filter "*.pyc" | Remove-Item -Force
    
    # Clean .egg-info directories
    Get-ChildItem -Path . -Recurse -Filter "*.egg-info" | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
    
    Write-Success "Clean completed"
    return $true
}

function Invoke-FullBuild {
    Write-Host "🚀 SmartUpgrade Build Pipeline" -ForegroundColor Magenta
    Write-Host ("=" * 60) -ForegroundColor Magenta
    Write-Host "Equivalent to: mvn clean validate compile test package"
    Write-Host "With license-maven-plugin execution`n"
    
    $phases = @(
        @{ Name = "clean"; Function = { Invoke-CleanPhase } },
        @{ Name = "validate"; Function = { Invoke-ValidatePhase } },
        @{ Name = "compile"; Function = { Invoke-CompilePhase } },
        @{ Name = "test"; Function = { Invoke-TestPhase } },
        @{ Name = "package"; Function = { Invoke-PackagePhase } }
    )
    
    foreach ($phase in $phases) {
        try {
            $success = & $phase.Function
            if (-not $success) {
                Write-Error "Build failed at $($phase.Name) phase"
                return $false
            }
        } catch {
            Write-Error "Build error at $($phase.Name) phase: $_"
            return $false
        }
    }
    
    Write-Host "`n🎉 BUILD SUCCESS" -ForegroundColor Green
    Write-Host ("=" * 60) -ForegroundColor Green
    Write-Host "All phases completed successfully!"
    Write-Host "License compliance verified ✅"
    
    return $true
}

function Show-Help {
    Write-Host "SmartUpgrade Build System (Maven equivalent)" -ForegroundColor Cyan
    Write-Host ("=" * 50) -ForegroundColor Cyan
    Write-Host ""
    Write-Host "License Plugin Goals (like Maven license-maven-plugin):" -ForegroundColor Yellow
    Write-Host "  download-licenses      Download license texts"
    Write-Host "  check-licenses         Validate license compliance"
    Write-Host "  license-report         Generate license reports"
    Write-Host ""
    Write-Host "Maven Lifecycle Phases:" -ForegroundColor Yellow
    Write-Host "  validate              Run validation (includes license check)"
    Write-Host "  compile               Compile Python sources"
    Write-Host "  test                  Run tests"
    Write-Host "  package               Create distribution packages"
    Write-Host "  clean                 Clean build artifacts"
    Write-Host "  all                   Full build pipeline (default)"
    Write-Host ""
    Write-Host "Usage Examples:" -ForegroundColor Yellow
    Write-Host "  .\build.ps1                    # Full build with license checking"
    Write-Host "  .\build.ps1 -Goal validate     # Just validation phase"
    Write-Host "  .\build.ps1 -Goal clean        # Clean build artifacts"
    Write-Host "  .\build.ps1 -Help              # Show this help"
}

# Main execution
if ($Help) {
    Show-Help
    exit 0
}

switch ($Goal.ToLower()) {
    "download-licenses" { 
        $success = Invoke-LicenseDownload
        exit $(if ($success) { 0 } else { 1 })
    }
    "check-licenses" { 
        $success = Invoke-LicenseCheck
        exit $(if ($success) { 0 } else { 1 })
    }
    "validate" { 
        $success = Invoke-ValidatePhase
        exit $(if ($success) { 0 } else { 1 })
    }
    "compile" { 
        $success = Invoke-CompilePhase
        exit $(if ($success) { 0 } else { 1 })
    }
    "test" { 
        $success = Invoke-TestPhase
        exit $(if ($success) { 0 } else { 1 })
    }
    "package" { 
        $success = Invoke-PackagePhase
        exit $(if ($success) { 0 } else { 1 })
    }
    "clean" { 
        $success = Invoke-CleanPhase
        exit $(if ($success) { 0 } else { 1 })
    }
    "all" { 
        $success = Invoke-FullBuild
        exit $(if ($success) { 0 } else { 1 })
    }
    "help" {
        Show-Help
        exit 0
    }
    default {
        Write-Error "Unknown goal: $Goal"
        Write-Host "Use -Help to see available goals"
        exit 1
    }
}