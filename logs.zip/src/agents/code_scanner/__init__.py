"""
CodeScanner Agent Module
Marcus - Project structure analysis specialist
"""

from .scanner_agent import CodeScannerAgent

__all__ = ['CodeScannerAgent']