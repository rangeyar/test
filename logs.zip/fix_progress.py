#!/usr/bin/env python
# Quick fix script to add time.sleep calls

filepath = r'c:\code-refactor\21-Nov\SmartUpgrade_V11\src\agents\migration_planner\planning_functions.py'

with open(filepath, 'r', encoding='utf-8') as f:
    content = f.read()

# Fix the literal \r\n that got inserted
content = content.replace('...\")`r`n        time.sleep', '...\")\n        time.sleep')

with open(filepath, 'w', encoding='utf-8') as f:
    f.write(content)

print("Fixed literal newline characters")
