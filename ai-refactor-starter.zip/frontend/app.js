const API_BASE = 'http://localhost:8008';

let jobId = null;

function setEnabled(id, enabled) {
  const el = document.getElementById(id);
  el.disabled = !enabled;
  if (id === 'downloadLink') {
    if (enabled) {
      el.classList.remove('disabled');
    } else {
      el.classList.add('disabled');
    }
  }
}

document.getElementById('btnUpload').addEventListener('click', async () => {
  const f = document.getElementById('zipFile').files[0];
  const msg = document.getElementById('uploadMsg');
  msg.textContent = '';
  if (!f) {
    msg.textContent = 'Please choose a .zip file.';
    return;
  }
  const fd = new FormData();
  fd.append('file', f);
  const res = await fetch(`${API_BASE}/upload`, { method: 'POST', body: fd });
  const data = await res.json();
  if (data.jobId) {
    jobId = data.jobId;
    msg.textContent = `Uploaded. jobId=${jobId}`;
    setEnabled('btnUpgrade', true);
  } else {
    msg.textContent = 'Upload failed.';
  }
});

document.getElementById('btnUpgrade').addEventListener('click', async () => {
  const out = document.getElementById('upgradeOut');
  out.textContent = 'Running upgrade...';
  const fd = new FormData();
  fd.append('jobId', jobId);
  const tv = document.getElementById('targetVersion').value.trim();
  const autod = document.getElementById('autoDiscover').checked;
  if (tv) fd.append('targetVersion', tv);
  fd.append('autoDiscover', autod ? 'true' : 'false');
  const res = await fetch(`${API_BASE}/agent/upgrade`, { method: 'POST', body: fd });
  const data = await res.json();
  out.textContent = JSON.stringify(data, null, 2);
  if (data.jobId) {
    setEnabled('btnBuild', true);
    const a = document.getElementById('downloadLink');
    a.href = `${API_BASE}${data.download}`;
    setEnabled('downloadLink', true);
  }
});

document.getElementById('btnBuild').addEventListener('click', async () => {
  const out = document.getElementById('buildOut');
  out.textContent = 'Building (this may take a while)...';
  const fd = new FormData();
  fd.append('jobId', jobId);
  const res = await fetch(`${API_BASE}/agent/build`, { method: 'POST', body: fd });
  const data = await res.json();
  out.textContent = JSON.stringify(data, null, 2);
  setEnabled('btnReview', true);
});

document.getElementById('btnReview').addEventListener('click', async () => {
  const out = document.getElementById('reviewOut');
  out.textContent = 'Reviewing...';
  const fd = new FormData();
  fd.append('jobId', jobId);
  const res = await fetch(`${API_BASE}/agent/review`, { method: 'POST', body: fd });
  const data = await res.json();
  out.textContent = JSON.stringify(data, null, 2);
});
