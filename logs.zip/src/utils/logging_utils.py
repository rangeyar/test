"""
Logging utilities for SmartUpgrade
Handles agent logging and UI feedback
"""

import streamlit as st
from typing import Dict, Any
import logging
from datetime import datetime

# Global agent logs storage
if 'agent_logs' not in st.session_state:
    st.session_state.agent_logs = []

def add_agent_log(agent_name: str, message: str, level: str = "info"):
    """
    Add agent log message to session state for UI display
    
    Args:
        agent_name: Name of the agent
        message: Log message
        level: Log level (info, warning, error, success)
    """
    log_entry = {
        'timestamp': datetime.now().strftime('%H:%M:%S'),
        'agent': agent_name,
        'message': message,
        'level': level
    }
    
    # Add to session state for UI display
    if 'agent_logs' not in st.session_state:
        st.session_state.agent_logs = []
    
    st.session_state.agent_logs.append(log_entry)
    
    # Keep only last 100 entries to prevent memory issues
    if len(st.session_state.agent_logs) > 100:
        st.session_state.agent_logs = st.session_state.agent_logs[-100:]

def clear_agent_logs():
    """Clear all agent logs"""
    st.session_state.agent_logs = []

def get_agent_logs() -> list:
    """Get all agent logs"""
    return st.session_state.get('agent_logs', [])

def get_recent_logs(count: int = 10) -> list:
    """Get recent agent logs"""
    logs = st.session_state.get('agent_logs', [])
    return logs[-count:] if logs else []