import os, re, json

def _gather_files(root, exts=(".java", ".kt", ".xml", ".properties", ".yml", ".yaml")):
    for dirpath, _, filenames in os.walk(root):
        # skip target/ and build/ dirs
        parts = set(p.lower() for p in dirpath.split(os.sep))
        if "target" in parts or "build" in parts or ".git" in parts:
            continue
        for fn in filenames:
            if fn.lower().endswith(exts):
                yield os.path.join(dirpath, fn)

def _count_todos(path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            txt = f.read()
        return len(re.findall(r"\bTODO\b", txt, flags=re.IGNORECASE))
    except Exception:
        return 0

def _file_size_kb(path): 
    try:
        return os.path.getsize(path) / 1024.0
    except Exception:
        return 0.0

def _java_version_hints(project_root):
    hints = []
    # Scan pom.xml for maven-compiler-plugin source/target
    for dirpath, _, filenames in os.walk(project_root):
        for fn in filenames:
            if fn == "pom.xml":
                p = os.path.join(dirpath, fn)
                try:
                    with open(p, "r", encoding="utf-8", errors="ignore") as f:
                        txt = f.read()
                    if "<maven-compiler-plugin" in txt:
                        if "<source>1.8</source>" in txt or "<target>1.8</target>" in txt:
                            hints.append({"file": os.path.relpath(p, project_root),
                                          "suggestion": "Consider upgrading Java to 17+ for Spring Boot 3.x."})
                except Exception:
                    pass
    return hints

def review_project(project_root: str):
    summary = {
        "todoCounts": [],
        "largeFilesKB": [],
        "javaVersionHints": [],
        "generalSuggestions": [
            "After upgrading Spring Boot, run the app once to surface deprecations.",
            "Check Jakarta namespace changes if you're migrating from pre-3.x code (javax.* → jakarta.*).",
            "Verify plugin versions (compiler, surefire, failsafe) are compatible with the new Boot version.",
        ]
    }
    for f in _gather_files(project_root):
        todos = _count_todos(f)
        if todos:
            summary["todoCounts"].append({"file": os.path.relpath(f, project_root), "count": todos})
        size_kb = _file_size_kb(f)
        if size_kb > 300:  # arbitrary "large" threshold
            summary["largeFilesKB"].append({"file": os.path.relpath(f, project_root), "kb": round(size_kb, 1)})
    summary["javaVersionHints"] = _java_version_hints(project_root)
    return summary
