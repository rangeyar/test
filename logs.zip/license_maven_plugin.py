#!/usr/bin/env python3
"""
Python License Maven Plugin Equivalent
Mimics the functionality of org.codehaus.mojo:license-maven-plugin

Usage:
    python license_maven_plugin.py download-licenses
    python license_maven_plugin.py check-licenses  
    python license_maven_plugin.py aggregate-download-licenses
"""

import json
import os
import subprocess
import sys
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Set
import xml.etree.ElementTree as ET
import toml

class LicenseMavenPlugin:
    """Python equivalent of Maven license-maven-plugin"""
    
    def __init__(self, config_file="license-plugin.toml"):
        """Initialize plugin with configuration"""
        self.config_file = config_file
        self.config = self.load_configuration()
        self.licenses_data = {}
        
    def load_configuration(self) -> Dict:
        """Load plugin configuration from TOML file"""
        try:
            with open(self.config_file, 'r') as f:
                return toml.load(f)
        except FileNotFoundError:
            print(f"⚠️ Configuration file {self.config_file} not found, using defaults")
            return self.get_default_config()
    
    def get_default_config(self) -> Dict:
        """Default configuration if no config file exists"""
        return {
            'tool': {
                'license-plugin': {
                    'configuration': {
                        'license-file-directory': 'target/licenses/texts',
                        'licenses-output-directory': 'target/licenses',
                        'licenses-output-file': 'licenses.xml',
                        'included-scopes': ['compile', 'runtime'],
                        'include-transitive-dependencies': True
                    },
                    'approved-licenses': {
                        'licenses': ['MIT', 'Apache-2.0', 'BSD-2-Clause', 'BSD-3-Clause', 'ISC']
                    },
                    'blacklisted-licenses': {
                        'licenses': ['GPL-2.0', 'GPL-3.0', 'AGPL-3.0']
                    }
                }
            }
        }
    
    def install_dependencies(self):
        """Install required dependencies"""
        try:
            import pip_licenses
            import license_expression
        except ImportError:
            print("📦 Installing required dependencies...")
            subprocess.check_call([
                sys.executable, '-m', 'pip', 'install', 
                'pip-licenses>=4.0.0', 'license-expression>=30.0.0'
            ])
    
    def download_licenses_goal(self):
        """
        Equivalent to <goal>download-licenses</goal>
        Downloads license texts for all dependencies
        """
        print("🔍 Executing download-licenses goal...")
        
        # Install dependencies if needed
        self.install_dependencies()
        
        # Create output directories
        config = self.config.get('tool', {}).get('license-plugin', {}).get('configuration', {})
        license_dir = Path(config.get('license-file-directory', 'target/licenses/texts'))
        output_dir = Path(config.get('licenses-output-directory', 'target/licenses'))
        
        license_dir.mkdir(parents=True, exist_ok=True)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Get dependency information
        print("📊 Analyzing dependencies...")
        result = subprocess.run([
            sys.executable, '-m', 'pip_licenses', '--format=json'
        ], capture_output=True, text=True)
        
        if result.returncode != 0:
            print(f"❌ Error getting dependency info: {result.stderr}")
            return False
        
        dependencies = json.loads(result.stdout)
        self.licenses_data = dependencies
        
        # Download license texts
        print(f"⬇️ Downloading license texts for {len(dependencies)} dependencies...")
        downloaded_count = 0
        
        for dep in dependencies:
            name = dep.get('Name', 'unknown')
            license_name = dep.get('License', 'Unknown')
            
            if self.download_license_text(name, license_name, license_dir):
                downloaded_count += 1
        
        print(f"✅ Downloaded {downloaded_count} license texts")
        
        # Generate licenses.xml (Maven format)
        self.generate_licenses_xml(dependencies, output_dir / 'licenses.xml')
        
        # Generate summary reports
        self.generate_summary_reports(dependencies, output_dir)
        
        return True
    
    def download_license_text(self, package_name: str, license_name: str, output_dir: Path) -> bool:
        """Download license text for a package"""
        try:
            # Common license URLs
            license_urls = {
                'MIT': 'https://raw.githubusercontent.com/licenses/license-templates/master/templates/mit.txt',
                'Apache-2.0': 'https://raw.githubusercontent.com/licenses/license-templates/master/templates/apache-2.0.txt',
                'BSD-2-Clause': 'https://raw.githubusercontent.com/licenses/license-templates/master/templates/bsd-2-clause.txt',
                'BSD-3-Clause': 'https://raw.githubusercontent.com/licenses/license-templates/master/templates/bsd-3-clause.txt',
                'ISC': 'https://raw.githubusercontent.com/licenses/license-templates/master/templates/isc.txt'
            }
            
            # Normalize license name
            normalized_license = self.normalize_license_name(license_name)
            
            if normalized_license in license_urls:
                license_file = output_dir / f"{package_name}_{normalized_license}.txt"
                
                if not license_file.exists():
                    urllib.request.urlretrieve(license_urls[normalized_license], license_file)
                    return True
            else:
                # Create placeholder file
                license_file = output_dir / f"{package_name}_{normalized_license}.txt"
                with open(license_file, 'w') as f:
                    f.write(f"License: {license_name}\n")
                    f.write(f"Package: {package_name}\n")
                    f.write(f"License text not automatically downloadable.\n")
                    f.write(f"Please review manually at package homepage.\n")
        
        except Exception as e:
            print(f"⚠️ Could not download license for {package_name}: {e}")
            return False
        
        return True
    
    def normalize_license_name(self, license_name: str) -> str:
        """Normalize license names using mappings"""
        mappings = self.config.get('tool', {}).get('license-plugin', {}).get('license-mappings', {})
        
        for pattern, normalized in mappings.items():
            if pattern.lower() in license_name.lower():
                return normalized
        
        # Default normalization
        if 'mit' in license_name.lower():
            return 'MIT'
        elif 'apache' in license_name.lower():
            return 'Apache-2.0'
        elif 'bsd' in license_name.lower():
            if '2-clause' in license_name.lower() or '2 clause' in license_name.lower():
                return 'BSD-2-Clause'
            else:
                return 'BSD-3-Clause'
        elif 'isc' in license_name.lower():
            return 'ISC'
        
        return license_name.replace(' ', '-').replace('/', '-')
    
    def generate_licenses_xml(self, dependencies: List[Dict], output_file: Path):
        """Generate licenses.xml file in Maven format"""
        print("📝 Generating licenses.xml...")
        
        root = ET.Element("licenseSummary")
        
        # Add dependencies
        deps_element = ET.SubElement(root, "dependencies")
        
        for dep in dependencies:
            dep_element = ET.SubElement(deps_element, "dependency")
            
            # Add basic info
            ET.SubElement(dep_element, "groupId").text = "python"
            ET.SubElement(dep_element, "artifactId").text = dep.get('Name', 'unknown')
            ET.SubElement(dep_element, "version").text = dep.get('Version', 'unknown')
            
            # Add licenses
            licenses_element = ET.SubElement(dep_element, "licenses")
            license_element = ET.SubElement(licenses_element, "license")
            ET.SubElement(license_element, "name").text = dep.get('License', 'Unknown')
            ET.SubElement(license_element, "url").text = dep.get('LicenseFile', 'Not Available')
        
        # Write XML file
        tree = ET.ElementTree(root)
        ET.indent(tree, space="  ", level=0)
        tree.write(output_file, encoding='utf-8', xml_declaration=True)
        
        print(f"✅ Generated {output_file}")
    
    def generate_summary_reports(self, dependencies: List[Dict], output_dir: Path):
        """Generate various summary reports"""
        
        # Generate THIRD-PARTY.txt (Maven style)
        third_party_file = output_dir / "THIRD-PARTY.txt"
        with open(third_party_file, 'w') as f:
            f.write("Lists of third-party dependencies.\n\n")
            f.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            # Group by license
            by_license = {}
            for dep in dependencies:
                license_name = dep.get('License', 'Unknown')
                if license_name not in by_license:
                    by_license[license_name] = []
                by_license[license_name].append(f"{dep.get('Name', 'unknown')} v{dep.get('Version', 'unknown')}")
            
            for license_name, packages in sorted(by_license.items()):
                f.write(f"\n{license_name}:\n")
                for package in sorted(packages):
                    f.write(f"  * {package}\n")
        
        print(f"✅ Generated {third_party_file}")
        
        # Generate CSV report
        csv_file = output_dir / "dependency-licenses.csv"
        subprocess.run([
            sys.executable, '-m', 'pip_licenses', 
            '--format=csv', f'--output-file={csv_file}'
        ])
        
        print(f"✅ Generated {csv_file}")
    
    def check_licenses_goal(self):
        """
        Equivalent to <goal>check-licenses</goal>
        Validates licenses against approved/blacklisted licenses
        """
        print("🔍 Executing check-licenses goal...")
        
        if not self.licenses_data:
            # Get dependency information
            result = subprocess.run([
                sys.executable, '-m', 'pip_licenses', '--format=json'
            ], capture_output=True, text=True)
            
            if result.returncode != 0:
                print(f"❌ Error getting dependency info: {result.stderr}")
                return False
            
            self.licenses_data = json.loads(result.stdout)
        
        # Get license lists from config
        approved = set(self.config.get('tool', {}).get('license-plugin', {}).get('approved-licenses', {}).get('licenses', []))
        blacklisted = set(self.config.get('tool', {}).get('license-plugin', {}).get('blacklisted-licenses', {}).get('licenses', []))
        
        violations = []
        warnings = []
        
        print(f"📊 Checking {len(self.licenses_data)} dependencies against license policies...")
        
        for dep in self.licenses_data:
            name = dep.get('Name', 'unknown')
            license_name = dep.get('License', 'Unknown')
            normalized_license = self.normalize_license_name(license_name)
            
            # Check blacklisted licenses
            if any(bl in normalized_license for bl in blacklisted):
                violations.append(f"{name}: {license_name} (BLACKLISTED)")
            
            # Check if approved
            elif not any(ap in normalized_license for ap in approved):
                if normalized_license != 'Unknown':
                    warnings.append(f"{name}: {license_name} (NOT IN APPROVED LIST)")
                else:
                    warnings.append(f"{name}: Unknown license")
        
        # Report results
        if violations:
            print(f"\n❌ LICENSE VIOLATIONS FOUND ({len(violations)}):")
            for violation in violations:
                print(f"  🚫 {violation}")
            
            fail_on_blacklist = self.config.get('tool', {}).get('license-plugin', {}).get('executions', {}).get('check-licenses', {}).get('fail-on-blacklist', True)
            if fail_on_blacklist:
                return False
        
        if warnings:
            print(f"\n⚠️ LICENSE WARNINGS ({len(warnings)}):")
            for warning in warnings:
                print(f"  ⚠️ {warning}")
        
        if not violations and not warnings:
            print("✅ All licenses are compliant!")
        
        return len(violations) == 0
    
    def aggregate_download_licenses_goal(self):
        """
        Equivalent to <goal>aggregate-download-licenses</goal>
        Aggregates license information across multi-module projects
        """
        print("🔍 Executing aggregate-download-licenses goal...")
        
        # For single module project, this is the same as download-licenses
        return self.download_licenses_goal()
    
    def run_goal(self, goal: str) -> bool:
        """Execute a specific goal"""
        goals = {
            'download-licenses': self.download_licenses_goal,
            'check-licenses': self.check_licenses_goal,
            'aggregate-download-licenses': self.aggregate_download_licenses_goal
        }
        
        if goal not in goals:
            print(f"❌ Unknown goal: {goal}")
            print(f"Available goals: {', '.join(goals.keys())}")
            return False
        
        return goals[goal]()

def main():
    """Main entry point"""
    if len(sys.argv) < 2:
        print("Usage: python license_maven_plugin.py <goal>")
        print("Goals: download-licenses, check-licenses, aggregate-download-licenses")
        return 1
    
    goal = sys.argv[1]
    
    print("🚀 Python License Maven Plugin")
    print("=" * 50)
    
    plugin = LicenseMavenPlugin()
    success = plugin.run_goal(goal)
    
    if success:
        print(f"\n✅ Goal '{goal}' completed successfully!")
        return 0
    else:
        print(f"\n❌ Goal '{goal}' failed!")
        return 1

if __name__ == "__main__":
    sys.exit(main())