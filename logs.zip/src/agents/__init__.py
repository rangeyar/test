"""
SmartUpgrade Agents Module
Multi-agent system for Java modernization
"""

from .base_agent import BaseAgent
from .code_scanner.scanner_agent import CodeScannerAgent
from .tech_detective.detective_agent import TechDetectiveAgent
from .quality_inspector.inspector_agent import QualityInspectorAgent
from .migration_planner.planner_agent import MigrationPlannerAgent

__all__ = [
    'BaseAgent',
    'CodeScannerAgent', 
    'TechDetectiveAgent',
    'QualityInspectorAgent',
    'MigrationPlannerAgent'
]