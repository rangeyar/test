"""
API Provider Factory and Abstraction Layer
Handles multiple AI providers (Azure, OpenAI, Anthropic, Custom)
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List, AsyncGenerator
import logging
import json
import requests
import openai
from openai import AzureOpenAI, OpenAI
import anthropic
from dataclasses import dataclass
from src.config import ProviderConfig, config_manager

logger = logging.getLogger(__name__)

@dataclass
class AIResponse:
    """Standardized AI response format"""
    content: str
    model: str
    usage: Dict[str, Any]
    finish_reason: str
    provider: str

class AIProvider(ABC):
    """Abstract base class for AI providers"""
    
    def __init__(self, config: ProviderConfig):
        self.config = config
        self.provider_name = config.provider_type
    
    @abstractmethod
    def generate_completion(self, messages: List[Dict[str, str]], **kwargs) -> AIResponse:
        """Generate completion from messages"""
        pass
    
    @abstractmethod
    def validate_connection(self) -> bool:
        """Test provider connectivity"""
        pass

class AzureOpenAIProvider(AIProvider):
    """Azure OpenAI provider implementation"""
    
    def __init__(self, config: ProviderConfig):
        super().__init__(config)
        # Create HTTP client with proper resource management
        import httpx
        self.http_client = httpx.Client(verify=False, timeout=60.0)
        
        self.client = AzureOpenAI(
            api_key=config.api_key,
            api_version=config.api_version,
            azure_endpoint=config.endpoint,
            http_client=self.http_client
        )
    
    def __del__(self):
        """Ensure HTTP client is properly closed"""
        try:
            if hasattr(self, 'http_client') and self.http_client:
                self.http_client.close()
        except Exception:
            pass  # Ignore errors during cleanup
    
    def close(self):
        """Explicitly close HTTP client resources"""
        if hasattr(self, 'http_client') and self.http_client:
            self.http_client.close()
    
    def generate_completion(self, messages: List[Dict[str, str]], **kwargs) -> AIResponse:
        """Generate completion using Azure OpenAI"""
        if not messages or not isinstance(messages, list):
            raise ValueError("Messages must be a non-empty list")
        
        # Validate message format
        for msg in messages:
            if not isinstance(msg, dict) or 'role' not in msg or 'content' not in msg:
                raise ValueError("Each message must be a dict with 'role' and 'content' keys")
        
        try:
            response = self.client.chat.completions.create(
                model=self.config.deployment,
                messages=messages,
                temperature=kwargs.get('temperature', self.config.temperature),
                max_tokens=kwargs.get('max_tokens', self.config.max_tokens),
                timeout=self.config.timeout
            )
            
            if not response.choices or not response.choices[0].message:
                raise ValueError("Invalid response format from Azure OpenAI")
            
            return AIResponse(
                content=response.choices[0].message.content or "",
                model=self.config.deployment,
                usage=response.usage.model_dump() if response.usage else {},
                finish_reason=response.choices[0].finish_reason or "unknown",
                provider="azure"
            )
        
        except openai.APIError as e:
            logger.error(f"Azure OpenAI API error: {e}")
            raise RuntimeError(f"Azure OpenAI API error: {e}") from e
        except openai.APIConnectionError as e:
            logger.error(f"Azure OpenAI connection error: {e}")
            raise ConnectionError(f"Failed to connect to Azure OpenAI: {e}") from e
        except openai.RateLimitError as e:
            logger.error(f"Azure OpenAI rate limit exceeded: {e}")
            raise RuntimeError(f"Azure OpenAI rate limit exceeded: {e}") from e
        except Exception as e:
            logger.error(f"Unexpected error in Azure OpenAI completion: {e}")
            raise RuntimeError(f"Azure OpenAI completion failed: {e}") from e
    
    def validate_connection(self) -> bool:
        """Test Azure OpenAI connectivity"""
        try:
            test_messages = [{"role": "user", "content": "Hello"}]
            response = self.generate_completion(test_messages)
            return bool(response and response.content)
        except (ConnectionError, RuntimeError, ValueError) as e:
            logger.warning(f"Azure OpenAI connection validation failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error during Azure OpenAI validation: {e}")
            return False

class OpenAIProvider(AIProvider):
    """OpenAI provider implementation"""
    
    def __init__(self, config: ProviderConfig):
        super().__init__(config)
        # Create HTTP client with proper resource management
        import httpx
        self.http_client = httpx.Client(verify=False, timeout=60.0)
        
        self.client = OpenAI(
            api_key=config.api_key,
            http_client=self.http_client
        )
    
    def __del__(self):
        """Ensure HTTP client is properly closed"""
        try:
            if hasattr(self, 'http_client') and self.http_client:
                self.http_client.close()
        except Exception:
            pass  # Ignore errors during cleanup
    
    def close(self):
        """Explicitly close HTTP client resources"""
        if hasattr(self, 'http_client') and self.http_client:
            self.http_client.close()
    
    def generate_completion(self, messages: List[Dict[str, str]], **kwargs) -> AIResponse:
        """Generate completion using OpenAI"""
        if not messages or not isinstance(messages, list):
            raise ValueError("Messages must be a non-empty list")
        
        # Validate message format
        for msg in messages:
            if not isinstance(msg, dict) or 'role' not in msg or 'content' not in msg:
                raise ValueError("Each message must be a dict with 'role' and 'content' keys")
        
        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=kwargs.get('temperature', self.config.temperature),
                max_tokens=kwargs.get('max_tokens', self.config.max_tokens),
                timeout=self.config.timeout
            )
            
            if not response.choices or not response.choices[0].message:
                raise ValueError("Invalid response format from OpenAI")
            
            return AIResponse(
                content=response.choices[0].message.content or "",
                model=self.config.model,
                usage=response.usage.model_dump() if response.usage else {},
                finish_reason=response.choices[0].finish_reason or "unknown",
                provider="openai"
            )
        
        except openai.APIError as e:
            logger.error(f"OpenAI API error: {e}")
            raise RuntimeError(f"OpenAI API error: {e}") from e
        except openai.APIConnectionError as e:
            logger.error(f"OpenAI connection error: {e}")
            raise ConnectionError(f"Failed to connect to OpenAI: {e}") from e
        except openai.RateLimitError as e:
            logger.error(f"OpenAI rate limit exceeded: {e}")
            raise RuntimeError(f"OpenAI rate limit exceeded: {e}") from e
        except Exception as e:
            logger.error(f"Unexpected error in OpenAI completion: {e}")
            raise RuntimeError(f"OpenAI completion failed: {e}") from e
    
    def validate_connection(self) -> bool:
        """Test OpenAI connectivity"""
        try:
            models = self.client.models.list()
            return bool(models and models.data and len(models.data) > 0)
        except openai.AuthenticationError as e:
            logger.warning(f"OpenAI authentication failed: {e}")
            return False
        except openai.APIConnectionError as e:
            logger.warning(f"OpenAI connection failed: {e}")
            return False
        except (ConnectionError, RuntimeError, ValueError) as e:
            logger.warning(f"OpenAI connection validation failed: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error during OpenAI validation: {e}")
            return False

class AnthropicProvider(AIProvider):
    """Anthropic provider implementation"""
    
    def __init__(self, config: ProviderConfig):
        super().__init__(config)
        self.client = anthropic.Anthropic(api_key=config.api_key)
    
    def generate_completion(self, messages: List[Dict[str, str]], **kwargs) -> AIResponse:
        """Generate completion using Anthropic"""
        try:
            # Convert OpenAI format to Anthropic format
            system_message = ""
            claude_messages = []
            
            for msg in messages:
                if msg["role"] == "system":
                    system_message = msg["content"]
                else:
                    claude_messages.append({
                        "role": msg["role"],
                        "content": msg["content"]
                    })
            
            response = self.client.messages.create(
                model=self.config.model,
                max_tokens=kwargs.get('max_tokens', self.config.max_tokens),
                messages=claude_messages,
                system=system_message if system_message else None,
                temperature=kwargs.get('temperature', self.config.temperature)
            )
            
            return AIResponse(
                content=response.content[0].text,
                model=self.config.model,
                usage={"input_tokens": response.usage.input_tokens, "output_tokens": response.usage.output_tokens},
                finish_reason=response.stop_reason,
                provider="anthropic"
            )
        
        except Exception as e:
            logger.error(f"Anthropic completion failed: {e}")
            raise
    
    def validate_connection(self) -> bool:
        """Test Anthropic connectivity"""
        try:
            test_messages = [{"role": "user", "content": "Hello"}]
            response = self.generate_completion(test_messages)
            return bool(response.content)
        except Exception as e:
            logger.error(f"Anthropic connection validation failed: {e}")
            return False

class CustomAPIProvider(AIProvider):
    """Custom API provider implementation (e.g., AVA-API)"""
    
    def __init__(self, config: ProviderConfig):
        super().__init__(config)
        self.session = requests.Session()
        
        # Configure SSL if needed
        ssl_context = config_manager.get_ssl_context()
        if ssl_context:
            self.session.verify = config_manager.ssl_config.ca_bundle_path
    
    def __del__(self):
        """Ensure session is properly closed"""
        try:
            if hasattr(self, 'session') and self.session:
                self.session.close()
        except Exception:
            pass  # Ignore errors during cleanup
    
    def close(self):
        """Explicitly close session resources"""
        if hasattr(self, 'session') and self.session:
            self.session.close()
    
    def generate_completion(self, messages: List[Dict[str, str]], **kwargs) -> AIResponse:
        """Generate completion using custom API"""
        try:
            headers = {
                "Authorization": f"Bearer {self.config.api_key}",
                "Content-Type": "application/json"
            }
            
            payload = {
                "model": self.config.model,
                "messages": messages,
                "temperature": kwargs.get('temperature', self.config.temperature),
                "max_tokens": kwargs.get('max_tokens', self.config.max_tokens),
                "stream": False
            }
            
            response = self.session.post(
                f"{self.config.endpoint.rstrip('/')}/chat/completions",
                headers=headers,
                json=payload,
                timeout=self.config.timeout
            )
            
            response.raise_for_status()
            result = response.json()
            
            return AIResponse(
                content=result["choices"][0]["message"]["content"],
                model=self.config.model,
                usage=result.get("usage", {}),
                finish_reason=result["choices"][0]["finish_reason"],
                provider="custom"
            )
        
        except Exception as e:
            logger.error(f"Custom API completion failed: {e}")
            raise
    
    def validate_connection(self) -> bool:
        """Test custom API connectivity"""
        try:
            headers = {"Authorization": f"Bearer {self.config.api_key}"}
            response = self.session.get(
                f"{self.config.endpoint.rstrip('/')}/models",
                headers=headers,
                timeout=10
            )
            return response.status_code in [200, 401]  # 401 means auth required but endpoint exists
        except Exception as e:
            logger.error(f"Custom API connection validation failed: {e}")
            return False

class APIProviderFactory:
    """Factory for creating AI providers"""
    
    PROVIDERS = {
        'azure': AzureOpenAIProvider,
        'openai': OpenAIProvider,
        'anthropic': AnthropicProvider,
        'custom': CustomAPIProvider
    }
    
    @classmethod
    def create_provider(cls, provider_type: str, config: ProviderConfig) -> AIProvider:
        """Create provider instance"""
        if provider_type not in cls.PROVIDERS:
            raise ValueError(f"Unsupported provider type: {provider_type}")
        
        provider_class = cls.PROVIDERS[provider_type]
        return provider_class(config)
    
    @classmethod
    def get_available_providers(cls) -> List[str]:
        """Get list of configured providers"""
        return list(config_manager.provider_configs.keys())
    
    @classmethod
    def validate_all_providers(cls) -> Dict[str, bool]:
        """Validate all configured providers"""
        results = {}
        
        for provider_name, config in config_manager.provider_configs.items():
            try:
                provider = cls.create_provider(provider_name, config)
                results[provider_name] = provider.validate_connection()
            except Exception as e:
                logger.error(f"Failed to validate provider {provider_name}: {e}")
                results[provider_name] = False
        
        return results

class AIProviderManager:
    """Manages AI provider instances and routing"""
    
    def __init__(self):
        self.providers: Dict[str, AIProvider] = {}
        self.active_provider = config_manager.get_active_provider()
        self._initialize_providers()
    
    def __del__(self):
        """Ensure all providers are properly cleaned up"""
        try:
            self.cleanup()
        except Exception:
            pass  # Ignore errors during cleanup
    
    def cleanup(self):
        """Explicitly cleanup all provider resources"""
        for provider in self.providers.values():
            try:
                if hasattr(provider, 'close'):
                    provider.close()
            except Exception as e:
                logger.error(f"Error closing provider: {e}")
        self.providers.clear()
    
    def _initialize_providers(self):
        """Initialize all configured providers"""
        for name, config in config_manager.provider_configs.items():
            try:
                self.providers[name] = APIProviderFactory.create_provider(name, config)
                logger.info(f"Initialized provider: {name}")
            except Exception as e:
                logger.error(f"Failed to initialize provider {name}: {e}")
    
    def get_provider(self, provider_name: Optional[str] = None) -> AIProvider:
        """Get provider instance"""
        name = provider_name or self.active_provider
        
        if name not in self.providers:
            raise ValueError(f"Provider {name} not available")
        
        return self.providers[name]
    
    def switch_provider(self, provider_name: str):
        """Switch active provider"""
        if provider_name not in self.providers:
            raise ValueError(f"Provider {provider_name} not available")
        
        self.active_provider = provider_name
        logger.info(f"Switched to provider: {provider_name}")
    
    def generate_completion(self, messages: List[Dict[str, str]], 
                          provider_name: Optional[str] = None, **kwargs) -> AIResponse:
        """Generate completion using specified or active provider"""
        provider = self.get_provider(provider_name)
        return provider.generate_completion(messages, **kwargs)
    
    def health_check(self) -> Dict[str, bool]:
        """Check health of all providers"""
        results = {}
        for name, provider in self.providers.items():
            results[name] = provider.validate_connection()
        return results

# Global provider manager instance
provider_manager = AIProviderManager()