from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import JSONResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
import shutil, os, zipfile, uuid, subprocess, sys, json, pathlib, asyncio, tempfile
from typing import Optional

from agents.pom_upgrader import upgrade_project_poms
from agents.builder import build_project
from agents.reviewer import review_project

app = FastAPI(title="AI Refactor Starter", version="0.1.0")

# CORS for local dev (frontend on file:// or http://localhost:*)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

WORKDIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "work"))
os.makedirs(WORKDIR, exist_ok=True)

def _job_dir(job_id: str):
    d = os.path.join(WORKDIR, job_id)
    os.makedirs(d, exist_ok=True)
    return d

def _extract_zip_to(zip_path: str, dest_dir: str):
    with zipfile.ZipFile(zip_path, 'r') as z:
        z.extractall(dest_dir)

@app.post("/upload")
async def upload_zip(file: UploadFile = File(...)):
    job_id = str(uuid.uuid4())[:8]
    jd = _job_dir(job_id)
    in_zip = os.path.join(jd, "input.zip")
    with open(in_zip, "wb") as f:
        shutil.copyfileobj(file.file, f)
    src_dir = os.path.join(jd, "src")
    os.makedirs(src_dir, exist_ok=True)
    _extract_zip_to(in_zip, src_dir)
    return {"jobId": job_id, "message": "Upload successful", "srcDir": src_dir}

@app.post("/agent/upgrade")
async def agent_upgrade(jobId: str = Form(...), targetVersion: Optional[str] = Form(None), autoDiscover: bool = Form(True)):
    jd = _job_dir(jobId)
    src_dir = os.path.join(jd, "src")
    if not os.path.isdir(src_dir):
        return JSONResponse({"error": "Invalid job or missing src"}, status_code=400)
    result = upgrade_project_poms(src_dir, target_version=targetVersion, autodiscover=autoDiscover)
    # zip updated src for convenience
    out_zip = os.path.join(jd, "updated.zip")
    shutil.make_archive(out_zip[:-4], 'zip', src_dir)
    return {"jobId": jobId, "result": result, "download": f"/download?jobId={jobId}"}

@app.post("/agent/build")
async def agent_build(jobId: str = Form(...), timeoutSec: int = Form(600)):
    jd = _job_dir(jobId)
    src_dir = os.path.join(jd, "src")
    if not os.path.isdir(src_dir):
        return JSONResponse({"error": "Invalid job or missing src"}, status_code=400)
    status, log_path = build_project(src_dir, timeout=timeoutSec)
    return {"jobId": jobId, "status": status, "logPath": log_path}

@app.post("/agent/review")
async def agent_review(jobId: str = Form(...)):
    jd = _job_dir(jobId)
    src_dir = os.path.join(jd, "src")
    if not os.path.isdir(src_dir):
        return JSONResponse({"error": "Invalid job or missing src"}, status_code=400)
    report = review_project(src_dir)
    report_path = os.path.join(jd, "review.json")
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    return {"jobId": jobId, "report": report, "reportPath": report_path}

@app.get("/download")
async def download(jobId: str):
    jd = _job_dir(jobId)
    zip_path = os.path.join(jd, "updated.zip")
    if not os.path.exists(zip_path):
        # fallback: zip current src
        src_dir = os.path.join(jd, "src")
        if not os.path.isdir(src_dir):
            return JSONResponse({"error": "Nothing to download"}, status_code=400)
        shutil.make_archive(zip_path[:-4], 'zip', src_dir)
    return FileResponse(zip_path, filename=f"refactored-{jobId}.zip")
