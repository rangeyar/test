"""
MigrationPlanner Agent for SmartUpgrade
Sarah - The strategic planner who creates comprehensive modernization roadmaps
"""

from typing import Dict, Any, List, Set
from datetime import datetime, timedelta
from ..base_agent import BaseAgent

class MigrationPlannerAgent(BaseAgent):
    """
    MigrationPlanner Agent (Sarah) - Strategic migration planning
    
    Role: Creates comprehensive migration plans based on analysis results,
          provides roadmaps, timelines, and strategic recommendations
    """
    
    def __init__(self):
        super().__init__(
            name="Sarah",
            role="Migration Strategy Planner", 
            emoji="👩‍💼"
        )
    
    def process(self, data: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        """
        Create comprehensive migration plan
        
        Args:
            data: Must contain analysis results from other agents
            **kwargs: Additional parameters including 'use_llm'
            
        Returns:
            Complete migration plan and roadmap
        """
        try:
            if not self.validate_input(data):
                return self.handle_error(
                    ValueError("Invalid input data"), 
                    "input validation"
                )
            
            analysis_results = data.get('analysis_results', {})
            use_llm = kwargs.get('use_llm', True)
            
            self.log_message("📋 Starting strategic migration planning...")
            
            # Create migration plan using both analysis and LLM
            if use_llm:
                migration_plan = self._create_migration_plan_with_llm(analysis_results)
            else:
                migration_plan = self._create_migration_plan_heuristic(analysis_results)
            
            # Ensure comprehensive coverage
            migration_plan = self._ensure_complete_file_coverage(
                migration_plan, 
                analysis_results
            )
            
            # Add strategic roadmap
            roadmap = self._create_strategic_roadmap(migration_plan, analysis_results)
            migration_plan['strategic_roadmap'] = roadmap
            
            self.log_message(
                f"📊 Migration plan complete: {migration_plan.get('total_files_affected', 0)} files, "
                f"{len(migration_plan.get('dependencies_to_update', []))} dependencies",
                "success"
            )
            
            return self.format_output(migration_plan)
            
        except Exception as e:
            return self.handle_error(e, "migration planning")
    
    def _create_migration_plan_with_llm(self, analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """Create migration plan using LLM analysis"""
        try:
            # Extract key information from analysis results
            tech_analysis = analysis_results.get('technology_analysis', {})
            quality_analysis = analysis_results.get('quality_analysis', {})
            project_structure = analysis_results.get('project_structure', {})
            
            # Create comprehensive prompt for migration planning
            prompt = self._get_migration_planning_prompt(
                tech_analysis, quality_analysis, project_structure
            )
            
            # Try LLM analysis if available
            try:
                from ...api_providers.provider_factory import provider_manager
                
                # Token management
                MAX_TOKENS = 15000
                estimated_tokens = len(prompt) // 4
                
                if estimated_tokens > MAX_TOKENS:
                    self.log_message("⚠️ Truncating migration planning prompt", "warning")
                    prompt = prompt[:MAX_TOKENS * 3] + "\\n\\n[Content truncated - create comprehensive plan]"
                
                provider = provider_manager.get_provider()
                if provider:
                    self.log_message("🤖 AI creating comprehensive migration strategy...")
                    ai_response = provider_manager.generate_completion([{"role": "user", "content": prompt}])
                    response = ai_response.content
                    
                    # Parse LLM response
                    from ...utils.json_utils import robust_json_parse
                    migration_data = robust_json_parse(response, "MigrationPlanner")
                    
                    # Check if parsing succeeded
                    if not migration_data.get('fallback') and not migration_data.get('error'):
                        self.log_message("✅ LLM migration plan created successfully", "success")
                        return migration_data
                
            except Exception as llm_error:
                self.log_message(f"⚠️ LLM planning failed: {str(llm_error)}, using heuristic planning", "warning")
            
            # Fallback to heuristic planning
            return self._create_migration_plan_heuristic(analysis_results)
            
        except Exception as e:
            self.log_message(f"❌ Migration planning failed: {str(e)}", "error")
            return self._create_migration_plan_heuristic(analysis_results)
    
    def _create_migration_plan_heuristic(self, analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """Create migration plan using heuristic analysis"""
        tech_analysis = analysis_results.get('technology_analysis', {})
        quality_analysis = analysis_results.get('quality_analysis', {})
        project_structure = analysis_results.get('project_structure', {})
        
        # Extract key information
        frameworks = tech_analysis.get('frameworks', [])
        legacy_indicators = tech_analysis.get('legacy_indicators', [])
        security_risks = quality_analysis.get('security_risks', [])
        java_files = project_structure.get('java_file_count', 0)
        
        # Create migration plan structure
        migration_plan = {
            "file_modifications": {
                "java_files": {},
                "build_files": {}
            },
            "project_wide_changes": {
                "total_files_affected": java_files,
                "comprehensive_coverage": True,
                "package_restructuring": [],
                "global_imports_updates": [],
                "security_improvements": [],
                "performance_optimizations": []
            },
            "dependencies_to_update": [],
            "migration_phases": [],
            "estimated_timeline": "6-12 weeks",
            "risk_assessment": "Medium",
            "success_criteria": []
        }
        
        # Analyze frameworks for migration needs
        for framework in frameworks:
            if 'struts' in framework.lower():
                migration_plan["dependencies_to_update"].append({
                    "artifact": "struts-framework",
                    "from_version": "legacy",
                    "to_version": "spring-boot-3.x",
                    "breaking_changes": ["Complete framework replacement required"],
                    "migration_notes": "Critical security migration from Struts to Spring Boot",
                    "priority": "CRITICAL"
                })
                migration_plan["risk_assessment"] = "High"
                
            elif 'spring boot 2' in framework.lower():
                migration_plan["dependencies_to_update"].append({
                    "artifact": "spring-boot",
                    "from_version": "2.x",
                    "to_version": "3.x",
                    "breaking_changes": ["Jakarta EE migration", "Configuration changes"],
                    "migration_notes": "Spring Boot 3 upgrade with Jakarta EE",
                    "priority": "HIGH"
                })
                
            elif 'junit 4' in framework.lower():
                migration_plan["dependencies_to_update"].append({
                    "artifact": "junit",
                    "from_version": "4.x",
                    "to_version": "5.x",
                    "breaking_changes": ["Annotation changes", "API updates"],
                    "migration_notes": "JUnit 5 migration for modern testing",
                    "priority": "MEDIUM"
                })
        
        # Add javax to jakarta migration if needed
        if any('javax' in indicator for indicator in legacy_indicators):
            migration_plan["project_wide_changes"]["global_imports_updates"].extend([
                "Migrate javax.servlet to jakarta.servlet",
                "Update javax.persistence to jakarta.persistence",
                "Replace javax.validation with jakarta.validation"
            ])
        
        # Add security improvements based on risks
        if security_risks:
            migration_plan["project_wide_changes"]["security_improvements"].extend([
                "Implement input validation and sanitization",
                "Add proper authentication and authorization",
                "Update cryptographic implementations",
                "Implement secure session management"
            ])
        
        # Add performance optimizations
        migration_plan["project_wide_changes"]["performance_optimizations"].extend([
            "Optimize database queries and connections",
            "Implement caching strategies",
            "Update to modern Java patterns",
            "Add monitoring and observability"
        ])
        
        # Create migration phases
        migration_plan["migration_phases"] = [
            {
                "phase": 1,
                "name": "Foundation & Security",
                "duration": "2-3 weeks",
                "tasks": [
                    "Update build system and dependencies",
                    "Implement critical security fixes",
                    "Set up modern development environment"
                ],
                "deliverables": ["Updated build configuration", "Security vulnerability fixes"]
            },
            {
                "phase": 2,
                "name": "Framework Migration", 
                "duration": "3-4 weeks",
                "tasks": [
                    "Migrate to modern frameworks",
                    "Update application configuration",
                    "Refactor legacy patterns"
                ],
                "deliverables": ["Modernized framework", "Updated application architecture"]
            },
            {
                "phase": 3,
                "name": "Optimization & Testing",
                "duration": "2-3 weeks", 
                "tasks": [
                    "Performance optimization",
                    "Comprehensive testing",
                    "Documentation updates"
                ],
                "deliverables": ["Performance improvements", "Full test coverage", "Updated documentation"]
            }
        ]
        
        # Success criteria
        migration_plan["success_criteria"] = [
            "All security vulnerabilities resolved",
            "Modern framework successfully integrated",
            "Performance meets or exceeds current benchmarks",
            "Full test coverage maintained",
            "Documentation updated and complete"
        ]
        
        return migration_plan
    
    def _ensure_complete_file_coverage(self, migration_data: Dict[str, Any], analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Ensure ALL files from analysis are covered in the migration plan
        """
        try:
            # Get file information from analysis results
            project_structure = analysis_results.get('project_structure', {})
            java_file_count = project_structure.get('java_file_count', 0)
            
            # Update coverage information
            file_mods = migration_data.setdefault('file_modifications', {})
            java_mods = file_mods.setdefault('java_files', {})
            
            # If no specific file modifications, add comprehensive coverage
            if not java_mods and java_file_count > 0:
                java_mods["COMPREHENSIVE_MODERNIZATION"] = {
                    "applies_to_files": f"All {java_file_count} Java files",
                    "modifications": [
                        {
                            "type": "COMPREHENSIVE_MODERNIZATION",
                            "description": "Standard modernization patterns for all Java files",
                            "pattern": "Legacy code patterns requiring modernization",
                            "target_pattern": "Modern Java patterns with updated dependencies and security fixes",
                            "reason": "Ensure comprehensive project modernization coverage",
                            "affected_files_count": java_file_count
                        }
                    ],
                    "priority": "HIGH"
                }
            
            # Update project-wide metrics
            project_wide = migration_data.setdefault('project_wide_changes', {})
            project_wide['total_files_affected'] = java_file_count
            project_wide['comprehensive_coverage'] = True
            project_wide['coverage_method'] = "Strategic Planning Analysis"
            
            self.log_message(f"📊 Final coverage: {java_file_count} Java files covered", "success")
            
            return migration_data
            
        except Exception as e:
            self.log_message(f"❌ Error ensuring file coverage: {str(e)}", "error")
            return migration_data
    
    def _create_strategic_roadmap(self, migration_plan: Dict[str, Any], analysis_results: Dict[str, Any]) -> Dict[str, Any]:
        """Create strategic roadmap with timelines and milestones"""
        
        # Calculate timeline based on project complexity
        java_files = analysis_results.get('project_structure', {}).get('java_file_count', 0)
        dependencies_count = len(migration_plan.get('dependencies_to_update', []))
        security_issues = analysis_results.get('quality_analysis', {}).get('security_issues_count', 0)
        
        # Base timeline calculation
        base_weeks = 6
        complexity_factor = min(2.0, (java_files / 50) + (dependencies_count / 5) + (security_issues / 10))
        estimated_weeks = int(base_weeks * complexity_factor)
        
        # Create roadmap
        roadmap = {
            "total_duration": f"{estimated_weeks} weeks",
            "phases": migration_plan.get('migration_phases', []),
            "milestones": [
                {
                    "milestone": "Security Assessment Complete",
                    "week": 1,
                    "criteria": ["All vulnerabilities identified", "Risk assessment complete"]
                },
                {
                    "milestone": "Framework Migration Started", 
                    "week": 3,
                    "criteria": ["Dependencies updated", "Build system modernized"]
                },
                {
                    "milestone": "Core Migration Complete",
                    "week": estimated_weeks - 2,
                    "criteria": ["All critical components migrated", "Basic functionality verified"]
                },
                {
                    "milestone": "Project Complete",
                    "week": estimated_weeks,
                    "criteria": ["All testing complete", "Performance validated", "Documentation updated"]
                }
            ],
            "risk_mitigation": [
                "Incremental migration approach to minimize disruption",
                "Comprehensive testing at each phase", 
                "Rollback procedures for critical issues",
                "Regular stakeholder communication and approval gates"
            ],
            "success_metrics": [
                "Zero security vulnerabilities",
                "Performance improvement of 20%+",
                "Code maintainability score >8/10",
                "100% test coverage maintained"
            ]
        }
        
        return roadmap
    
    def _get_migration_planning_prompt(self, tech_analysis: Dict[str, Any], 
                                     quality_analysis: Dict[str, Any], 
                                     project_structure: Dict[str, Any]) -> str:
        """Get LLM prompt for migration planning"""
        
        frameworks = tech_analysis.get('frameworks', [])
        security_risks = quality_analysis.get('security_risks', [])
        java_files = project_structure.get('java_file_count', 0)
        
        return f"""
You are Sarah, a Senior Migration Strategy Architect with 20+ years of experience in Java modernization.
Create a comprehensive migration plan for this Java project.

PROJECT ANALYSIS:
- Frameworks: {frameworks}
- Java Files: {java_files}
- Security Risks: {len(security_risks)} identified
- Quality Score: {quality_analysis.get('code_quality_score', 'N/A')}

TECHNOLOGY ANALYSIS:
{tech_analysis}

QUALITY ANALYSIS:
{quality_analysis}

CREATE COMPREHENSIVE MIGRATION PLAN:

1. FILE MODIFICATIONS:
   - Specific changes needed for each file type
   - Pattern-based modifications for similar files
   - Priority levels for each modification

2. PROJECT-WIDE CHANGES:
   - Package restructuring requirements
   - Global import updates (javax -> jakarta)
   - Security improvements needed
   - Performance optimizations

3. DEPENDENCY UPDATES:
   - Framework upgrades with exact versions
   - Breaking changes and migration notes
   - Priority and timeline for each update

4. MIGRATION PHASES:
   - Logical phases with specific tasks
   - Duration and deliverables for each phase
   - Dependencies between phases

RETURN DETAILED JSON:
{{
  "file_modifications": {{
    "java_files": {{
      "UserController.java": {{
        "modifications": [
          {{
            "type": "FRAMEWORK_UPGRADE", 
            "description": "Update to Spring Boot 3.x annotations",
            "from": "@RequestMapping",
            "to": "@GetMapping/@PostMapping",
            "reason": "Modern Spring Boot practices"
          }}
        ],
        "priority": "HIGH"
      }}
    }},
    "build_files": {{
      "pom.xml": {{
        "modifications": [
          {{
            "type": "DEPENDENCY_UPDATE",
            "description": "Update Spring Boot version",
            "from": "2.7.x",
            "to": "3.1.x", 
            "reason": "Latest stable version with Jakarta EE"
          }}
        ]
      }}
    }}
  }},
  "project_wide_changes": {{
    "total_files_affected": {java_files},
    "package_restructuring": ["Reorganize packages for modern architecture"],
    "global_imports_updates": ["javax.servlet -> jakarta.servlet"],
    "security_improvements": ["Add input validation", "Implement CSRF protection"],
    "performance_optimizations": ["Optimize database queries", "Add caching"]
  }},
  "dependencies_to_update": [
    {{
      "artifact": "spring-boot",
      "from_version": "2.7.x",
      "to_version": "3.1.x",
      "breaking_changes": ["Jakarta EE namespace", "Configuration changes"],
      "migration_notes": "Comprehensive Spring Boot 3 upgrade",
      "files_affected": ["All Spring components"]
    }}
  ],
  "migration_phases": [
    {{
      "phase": 1,
      "name": "Foundation Setup",
      "duration": "2 weeks",
      "tasks": ["Update build system", "Resolve dependencies"],
      "deliverables": ["Modern build configuration"]
    }}
  ],
  "estimated_timeline": "8-10 weeks",
  "risk_assessment": "Medium",
  "success_criteria": ["All tests passing", "Performance improved", "Security vulnerabilities resolved"]
}}

Be extremely detailed and practical in your migration plan.
        """
    
    def get_prompt_template(self) -> str:
        """Get LLM prompt template for MigrationPlanner"""
        return """
        You are Sarah, the MigrationPlanner Agent - an expert in Java modernization strategy.
        
        Your role is to:
        1. Create comprehensive migration plans based on analysis
        2. Define strategic roadmaps with clear phases and timelines
        3. Identify risks and mitigation strategies
        4. Ensure complete project coverage in migration
        5. Provide practical, actionable recommendations
        
        Focus on:
        - Complete file and dependency coverage
        - Risk-based prioritization
        - Phased migration approach
        - Clear success criteria and metrics
        - Practical timeline and resource estimates
        
        Always ensure migration plans are comprehensive, practical, and achievable.
        """
    
    def validate_input(self, data: Dict[str, Any]) -> bool:
        """Validate MigrationPlanner input"""
        if not super().validate_input(data):
            return False
        
        analysis_results = data.get('analysis_results', {})
        
        # Validate analysis_results parameter
        if not isinstance(analysis_results, dict):
            self.log_message("analysis_results must be a dictionary", "error")
            return False
        
        if len(analysis_results) == 0:
            self.log_message("analysis_results cannot be empty", "error")
            return False
        
        # Validate required fields in analysis_results
        required_fields = ['technologies', 'frameworks']  # Basic required fields
        for field in required_fields:
            if field not in analysis_results:
                self.log_message(f"Missing required field in analysis_results: {field}", "warning")
        
        return True