"""
Base Agent Class for SmartUpgrade Multi-Agent System
Provides common functionality for all agents in the system
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
import logging
from datetime import datetime

class BaseAgent(ABC):
    """
    Abstract base class for all SmartUpgrade agents
    Provides common functionality and interface definitions
    """
    
    def __init__(self, name: str, role: str, emoji: str = "🤖"):
        self.name = name
        self.role = role
        self.emoji = emoji
        self.logger = logging.getLogger(f"SmartUpgrade.{self.__class__.__name__}")
        
    def log_message(self, message: str, level: str = "info"):
        """Log agent messages with proper formatting"""
        formatted_message = f"{self.emoji} {self.name}: {message}"
        
        # Import here to avoid circular imports
        from ..utils.logging_utils import add_agent_log
        add_agent_log(f"{self.emoji} {self.name} ({self.role})", message, level)
        
        # Also log to system logger
        if level == "error":
            self.logger.error(formatted_message)
        elif level == "warning":
            self.logger.warning(formatted_message)
        elif level == "success":
            self.logger.info(f"✅ {formatted_message}")
        else:
            self.logger.info(formatted_message)
    
    @abstractmethod
    def process(self, data: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        """
        Main processing method - must be implemented by each agent
        
        Args:
            data: Input data for processing
            **kwargs: Additional parameters
            
        Returns:
            Dict containing processed results
        """
        pass
    
    @abstractmethod
    def get_prompt_template(self) -> str:
        """
        Get the LLM prompt template for this agent
        
        Returns:
            String containing the prompt template
        """
        pass
    
    def validate_input(self, data: Dict[str, Any]) -> bool:
        """
        Validate input data before processing
        
        Args:
            data: Input data to validate
            
        Returns:
            True if input is valid, False otherwise
        """
        if not isinstance(data, dict):
            self.log_message("Input data must be a dictionary", "error")
            return False
        
        # Basic validation - can be overridden in subclasses
        if not data:
            self.log_message("Input data cannot be empty", "error")
            return False
            
        return True
    
    def format_output(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format output data with standard fields
        
        Args:
            result: Raw processing result
            
        Returns:
            Formatted result with metadata
        """
        return {
            **result,
            "agent_name": self.name,
            "agent_role": self.role,
            "timestamp": datetime.now().isoformat(),
            "status": "completed"
        }
    
    def handle_error(self, error: Exception, context: str = "") -> Dict[str, Any]:
        """
        Handle errors consistently across agents
        
        Args:
            error: The exception that occurred
            context: Additional context about when the error occurred
            
        Returns:
            Error result dictionary
        """
        # Sanitize error message to prevent information leakage
        if isinstance(error, (ValueError, TypeError)):
            error_message = f"Input validation error in {context}: {str(error)}"
        elif isinstance(error, (ConnectionError, TimeoutError)):
            error_message = f"Connection error in {context}: Service unavailable"
        elif isinstance(error, PermissionError):
            error_message = f"Permission error in {context}: Access denied"
        elif isinstance(error, FileNotFoundError):
            error_message = f"File error in {context}: Resource not found"
        else:
            # Generic error message for security
            error_message = f"Processing error in {context}: Operation failed"
        
        self.log_message(error_message, "error")
        
        # Log the full error details for debugging (internal only)
        self.logger.debug(f"Full error details - {context}: {repr(error)}")
        
        return {
            "error": True,
            "error_message": error_message,
            "error_type": error.__class__.__name__,
            "agent_name": self.name,
            "timestamp": datetime.now().isoformat(),
            "status": "failed"
        }