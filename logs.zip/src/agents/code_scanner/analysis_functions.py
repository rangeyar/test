"""
Project analysis functions for SmartUpgrade
Handles comprehensive project structure analysis and technology detection
"""

import os
import logging
from typing import Dict, Any, List
from pathlib import Path
from ...utils.logging_utils import add_agent_log

logger = logging.getLogger(__name__)


def analyze_complete_project_structure(project_path: str) -> Dict[str, Any]:
    """Analyze complete project structure and categorize all files"""
    # CWE-20: Parameter validation
    if not project_path or not isinstance(project_path, str):
        raise ValueError("project_path must be a non-empty string")
    if not os.path.exists(project_path):
        raise FileNotFoundError(f"Project path does not exist: {project_path}")
    
    add_agent_log("ProjectAnalyzer", f"🔍 Starting comprehensive analysis of: {project_path}", "info")
    
    analysis_result = {
        'project_structure': {},
        'file_categories': {
            'java_files': [],
            'config_files': [],
            'build_files': [],
            'test_files': [],
            'resource_files': [],
            'documentation_files': [],
            #//TODORAGJSP STARTS
            'jsp_files': [],  # Add JSP files category for view layer migration
            #//TODORAGJSP ENDS
        },
        'total_files': 0,
        'total_directories': 0,
        'java_loc': 0,
        'file_types': {},  # Add file_types tracking for pie chart
        'project_metrics': {}
    }
    
    try:
        for root, dirs, files in os.walk(project_path):
            # Count directories
            analysis_result['total_directories'] += len(dirs)
            
            relative_root = os.path.relpath(root, project_path)
            
            for file in files:
                file_path = os.path.join(root, file)
                relative_path = os.path.join(relative_root, file) if relative_root != '.' else file
                
                # Categorize files comprehensively
                file_extension = os.path.splitext(file)[1].lower()
                
                if file_extension == '.java':
                    # Count lines of code
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            lines = sum(1 for line in f if line.strip() and not line.strip().startswith('//'))
                            analysis_result['java_loc'] += lines
                    except Exception as e:
                        # CWE-703: Proper error handling with logging
                        logger.warning(f"Could not read Java file {file_path}: {str(e)}")
                    
                    analysis_result['file_categories']['java_files'].append({
                        'path': relative_path,
                        'full_path': file_path,
                        'size': os.path.getsize(file_path)
                    })
                
                elif file_extension in ['.xml', '.properties', '.yml', '.yaml', '.json']:
                    analysis_result['file_categories']['config_files'].append({
                        'path': relative_path,
                        'type': file_extension,
                        'full_path': file_path
                    })
                
                elif file in ['pom.xml', 'build.gradle', 'build.xml', 'gradle.properties']:
                    analysis_result['file_categories']['build_files'].append({
                        'path': relative_path,
                        'type': file_extension,
                        'full_path': file_path
                    })
                
                elif 'test' in file.lower() or file_extension in ['.test']:
                    analysis_result['file_categories']['test_files'].append({
                        'path': relative_path,
                        'full_path': file_path
                    })
                
                elif file_extension in ['.md', '.txt', '.rst', '.doc']:
                    analysis_result['file_categories']['documentation_files'].append({
                        'path': relative_path,
                        'full_path': file_path
                    })
                
                #//TODORAGJSP STARTS
                elif file_extension in ['.jsp', '.jspx', '.jspf']:
                    # Categorize JSP files separately for view layer migration
                    analysis_result['file_categories']['jsp_files'].append({
                        'path': relative_path,
                        'full_path': file_path,
                        'size': os.path.getsize(file_path),
                        'type': file_extension
                    })
                #//TODORAGJSP ENDS
                
                else:
                    analysis_result['file_categories']['resource_files'].append({
                        'path': relative_path,
                        'full_path': file_path
                    })
                
                # Track file types for pie chart
                analysis_result['file_types'][file_extension] = analysis_result['file_types'].get(file_extension, 0) + 1
                analysis_result['total_files'] += 1
        
        analysis_result['project_metrics'] = {
            'java_files_count': len(analysis_result['file_categories']['java_files']),
            'config_files_count': len(analysis_result['file_categories']['config_files']),
            #//TODORAGJSP STARTS
            'jsp_files_count': len(analysis_result['file_categories']['jsp_files']),
            #//TODORAGJSP ENDS
            'total_lines_of_code': analysis_result['java_loc'],
            'project_size': 'small' if analysis_result['java_loc'] < 1000 else 'medium' if analysis_result['java_loc'] < 5000 else 'large'
        }
        
        # Include file_types in project_structure for pie chart
        analysis_result['project_structure']['file_types'] = analysis_result['file_types']
        analysis_result['project_structure']['total_files'] = analysis_result['total_files']
        analysis_result['project_structure']['total_directories'] = analysis_result['total_directories']
        
        add_agent_log("ProjectAnalyzer", f"✅ Analysis complete: {analysis_result['total_files']} files, {analysis_result['java_loc']} Java LOC", "success")
        return analysis_result
        
    except Exception as e:
        add_agent_log("ProjectAnalyzer", f"❌ Analysis failed: {str(e)}", "error")
        raise


def generate_complete_project_tree(project_path: str) -> str:
    """Generate a complete project tree visualization"""
    # CWE-20: Parameter validation
    if not project_path or not isinstance(project_path, str):
        raise ValueError("project_path must be a non-empty string")
    if not os.path.exists(project_path):
        raise FileNotFoundError(f"Project path does not exist: {project_path}")
    
    tree_lines = []
    
    def add_tree_node(path: str, prefix: str = "", is_last: bool = True, depth: int = 0):
        if depth > 10:  # Prevent infinite recursion
            return
        
        try:
            name = os.path.basename(path)
            if os.path.isdir(path):
                # Directory with file count
                try:
                    file_count = len([f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))])
                    tree_lines.append(f"{prefix}{'└── ' if is_last else '├── '}{name}/ ({file_count} files)")
                except PermissionError:
                    # CWE-703: Proper error handling
                    tree_lines.append(f"{prefix}{'└── ' if is_last else '├── '}{name}/ (permission denied)")
                    return
                
                # Get subdirectories and files
                try:
                    items = sorted(os.listdir(path))
                    dirs = [item for item in items if os.path.isdir(os.path.join(path, item))]
                    files = [item for item in items if os.path.isfile(os.path.join(path, item))]
                    
                    # Recurse with depth limit
                    all_items = dirs + files[:5]  # Limit files shown per directory
                    for i, item in enumerate(all_items):
                        is_item_last = (i == len(all_items) - 1)
                        item_path = os.path.join(path, item)
                        new_prefix = prefix + ("    " if is_last else "│   ")
                        add_tree_node(item_path, new_prefix, is_item_last, depth + 1)
                except PermissionError:
                    pass
            else:
                # File with size and type analysis
                try:
                    size = os.path.getsize(path)
                    size_str = f"{size} bytes" if size < 1024 else f"{size//1024} KB"
                    
                    # Detailed file categorization
                    file_ext = os.path.splitext(name)[1].lower()
                    file_types = {
                        '.java': '☕',
                        '.xml': '📄',
                        '.properties': '⚙️',
                        '.yml': '📝',
                        '.yaml': '📝',
                        '.json': '📋',
                        '.md': '📖',
                        '.txt': '📄',
                        '.gradle': '🔧',
                        '.maven': '🔧'
                    }
                    
                    icon = file_types.get(file_ext, '📄')
                    tree_lines.append(f"{prefix}{'└── ' if is_last else '├── '}{icon} {name} ({size_str})")
                except OSError:
                    tree_lines.append(f"{prefix}{'└── ' if is_last else '├── '}📄 {name} (size unknown)")
                    
        except Exception as e:
            tree_lines.append(f"{prefix}{'└── ' if is_last else '├── '}❌ {name} (error: {str(e)})")
    
    add_tree_node(project_path)
    return '\n'.join(tree_lines)


def perform_enhanced_directory_analysis(file_paths: List[str], files_count: int) -> Dict[str, Any]:
    """Perform enhanced directory structure analysis"""
    
    packages = set()
    directories = {}
    file_distribution = {
        'java_files': 0,
        'test_files': 0,
        'config_files': 0,
        'build_files': 0,
        'resource_files': 0
    }
    
    for file_path in file_paths:
        # Extract directory structure
        dir_parts = os.path.dirname(file_path).split(os.sep)
        for part in dir_parts:
            if part and part not in ['.', '..']:
                directories[part] = directories.get(part, 0) + 1
        
        # Categorize files
        if file_path.endswith('.java'):
            file_distribution['java_files'] += 1
            # Extract package structure
            try:
                dir_path = os.path.dirname(file_path)
                if 'src' in dir_path:
                    package_path = dir_path.split('src')[-1].strip(os.sep)
                    if package_path:
                        packages.add(package_path.replace(os.sep, '.'))
            except:
                pass
        elif file_path.endswith(('.xml', '.properties', '.yml', '.yaml')):
            file_distribution['config_files'] += 1
        elif 'test' in file_path.lower():
            file_distribution['test_files'] += 1
        elif file_path.endswith(('.gradle', 'pom.xml', 'build.xml')):
            file_distribution['build_files'] += 1
        else:
            file_distribution['resource_files'] += 1
    
    return {
        'packages': sorted(list(packages)),
        'directory_structure': directories,
        'file_distribution': file_distribution,
        'total_directories': len(directories),
        'package_count': len(packages),
        'analysis_summary': f"Found {len(packages)} packages in {len(directories)} directories"
    }