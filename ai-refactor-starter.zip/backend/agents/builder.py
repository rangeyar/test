import os, subprocess, shutil, time

def _which(cmd):
    from shutil import which
    return which(cmd)

def build_project(project_root: str, timeout: int = 600):
    """Attempt to build the project using mvnw or mvn with -DskipTests.
    Returns tuple(status:str, log_path:str).
    """
    log_path = os.path.join(project_root, "build.log")
    cmds = []
    mvnw = os.path.join(project_root, "mvnw")
    mvnw_cmd = None
    if os.path.exists(mvnw):
        mvnw_cmd = mvnw
        # Ensure executable bit
        try:
            os.chmod(mvnw, 0o755)
        except Exception:
            pass
    if mvnw_cmd:
        cmds.append([mvnw_cmd, "-q", "-DskipTests", "package"])
    if _which("mvn"):
        cmds.append(["mvn", "-q", "-DskipTests", "package"])

    if not cmds:
        with open(log_path, "w", encoding="utf-8") as f:
            f.write("No mvnw or mvn found on PATH. Cannot build.\n")
        return ("no-maven", log_path)

    # Try commands in order
    for cmd in cmds:
        try:
            with open(log_path, "w", encoding="utf-8") as f:
                f.write(f"Running: {' '.join(cmd)}\n")
                f.flush()
                proc = subprocess.Popen(cmd, cwd=project_root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
                start = time.time()
                for line in proc.stdout:
                    f.write(line)
                    if time.time() - start > timeout:
                        proc.kill()
                        f.write("\nBuild timed out.\n")
                        return ("timeout", log_path)
                rc = proc.wait()
                if rc == 0:
                    f.write("\nBuild finished successfully.\n")
                    return ("success", log_path)
                else:
                    f.write(f"\nBuild failed with return code {rc}.\n")
        except Exception as e:
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(f"\nError running {' '.join(cmd)}: {e}\n")

    return ("failed", log_path)
