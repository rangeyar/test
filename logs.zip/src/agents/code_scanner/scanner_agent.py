"""
CodeScanner Agent for SmartUpgrade
Marcus - The project structure expert who catalogs and analyzes all project files
"""

import os
from typing import Dict, Any, List
from ..base_agent import BaseAgent

class CodeScannerAgent(BaseAgent):
    """
    CodeScanner Agent (Marcus) - Comprehensive project structure analysis
    
    Role: Catalogs ALL project files, analyzes structure, and provides 
          comprehensive file mapping for other agents
    """
    
    def __init__(self):
        super().__init__(
            name="Marcus",
            role="Code Structure Analyst", 
            emoji="👨‍💻"
        )
    
    def process(self, data: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        """
        Analyze complete project structure
        
        Args:
            data: Must contain 'project_path' key
            **kwargs: Additional parameters
            
        Returns:
            Complete project structure analysis
        """
        try:
            if not self.validate_input(data):
                return self.handle_error(
                    ValueError("Invalid input data"), 
                    "input validation"
                )
            
            project_path = data.get('project_path')
            if not project_path or not os.path.exists(project_path):
                return self.handle_error(
                    ValueError("Invalid or missing project path"),
                    "project path validation"
                )
            
            self.log_message("🔍 Starting comprehensive code structure discovery...")
            
            # Analyze project structure
            structure = self._analyze_complete_project_structure(project_path)
            
            # Generate project tree
            tree = self._generate_complete_project_tree(project_path)
            
            self.log_message(
                f"📊 Complete structure mapped: {structure['total_files']} files "
                f"across {structure['total_directories']} directories",
                "success"
            )
            
            self.log_message(
                f"☕ Java files: {len(structure['java_files'])}, "
                f"📄 Config files: {len(structure['config_files'])}, "
                f"📝 Other files: {len(structure['other_files'])}"
            )
            
            result = {
                'project_structure': structure,
                'complete_file_tree': tree,
                'analysis_summary': {
                    'files_analyzed': structure['total_files'],
                    'java_files_count': len(structure['java_files']),
                    'config_files_count': len(structure['config_files']),
                    'lines_of_code': structure['lines_of_code'],
                }
            }
            
            return self.format_output(result)
            
        except Exception as e:
            return self.handle_error(e, "project structure analysis")
    
    def _analyze_complete_project_structure(self, project_path: str) -> Dict[str, Any]:
        """Comprehensive project structure analysis"""
        structure = {
            'java_files': [],
            'config_files': [],
            'test_files': [],
            'resource_files': [],
            'build_files': [],
            'other_files': [],
            'all_files': [],
            'directories': [],
            'total_files': 0,
            'total_directories': 0,
            'file_types': {},
            'lines_of_code': 0
        }
        
        try:
            for root, dirs, files in os.walk(project_path):
                # Count directories
                structure['directories'].extend([os.path.join(root, d) for d in dirs])
                
                for file in files:
                    file_path = os.path.join(root, file)
                    rel_path = os.path.relpath(file_path, project_path)
                    structure['all_files'].append(file_path)
                    
                    # Categorize files comprehensively
                    if file.endswith('.java'):
                        structure['java_files'].append(file_path)
                        # Count lines of code
                        try:
                            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                                structure['lines_of_code'] += len(f.readlines())
                        except:
                            pass
                    elif file.endswith('Test.java') or 'test' in file.lower():
                        structure['test_files'].append(file_path)
                    elif file in ['pom.xml', 'build.gradle', 'build.xml', 'gradle.properties']:
                        structure['build_files'].append(file_path)
                    elif file in ['application.properties', 'application.yml', 'application.yaml', 'web.xml', 'spring.xml']:
                        structure['config_files'].append(file_path)
                    elif file.endswith(('.properties', '.yml', '.yaml', '.xml', '.json')):
                        structure['resource_files'].append(file_path)
                    else:
                        structure['other_files'].append(file_path)
                    
                    # Track file types
                    ext = os.path.splitext(file)[1].lower()
                    structure['file_types'][ext] = structure['file_types'].get(ext, 0) + 1
            
            structure['total_files'] = len(structure['all_files'])
            structure['total_directories'] = len(set(structure['directories']))
            
            return structure
            
        except Exception as e:
            self.log_message(f"❌ Error analyzing project structure: {str(e)}", "error")
            return structure
    
    def _generate_complete_project_tree(self, project_path: str) -> str:
        """Generate comprehensive project tree showing all files and directories"""
        try:
            tree_lines = []
            project_name = os.path.basename(project_path)
            
            def add_comprehensive_tree(dir_path: str, prefix: str = "", max_depth: int = 10):
                if max_depth <= 0:
                    return
                    
                items = []
                if os.path.exists(dir_path):
                    try:
                        items = sorted(os.listdir(dir_path))
                    except PermissionError:
                        return
                
                for i, item in enumerate(items):
                    item_path = os.path.join(dir_path, item)
                    is_last_item = i == len(items) - 1
                    
                    if os.path.isdir(item_path):
                        # Directory with file count
                        try:
                            file_count = len([f for f in os.listdir(item_path) if os.path.isfile(os.path.join(item_path, f))])
                            dir_info = f" ({file_count} files)" if file_count > 0 else ""
                        except:
                            dir_info = ""
                        
                        connector = "└── " if is_last_item else "├── "
                        tree_lines.append(f"{prefix}{connector}📁 {item}/{dir_info}")
                        
                        # Recurse with depth limit
                        extension = "    " if is_last_item else "│   "
                        add_comprehensive_tree(item_path, prefix + extension, max_depth - 1)
                            
                    else:
                        # File with size and type analysis
                        try:
                            size = os.path.getsize(item_path)
                            size_info = f" ({size} bytes)" if size < 1024 else f" ({size//1024}KB)"
                        except:
                            size_info = ""
                        
                        connector = "└── " if is_last_item else "├── "
                        
                        # File type emoji
                        if item.endswith('.java'):
                            emoji = "☕"
                        elif item.endswith(('.xml', '.pom')):
                            emoji = "📄"
                        elif item.endswith(('.properties', '.yml', '.yaml')):
                            emoji = "⚙️"
                        elif item.endswith(('.md', '.txt', '.rst')):
                            emoji = "📝"
                        elif item.endswith(('.jar', '.war', '.ear')):
                            emoji = "📦"
                        else:
                            emoji = "📄"
                        
                        tree_lines.append(f"{prefix}{connector}{emoji} {item}{size_info}")
            
            tree_lines.append(f"📁 {project_name}/")
            add_comprehensive_tree(project_path)
            
            return "\n".join(tree_lines)
            
        except Exception as e:
            return f"📁 {os.path.basename(project_path)}/\n└── ❌ Error generating tree: {str(e)}"
    
    def get_prompt_template(self) -> str:
        """Get LLM prompt template for CodeScanner"""
        return """
        You are Marcus, the CodeScanner Agent - an expert in analyzing Java project structures.
        
        Your role is to:
        1. Catalog ALL files in the project comprehensively
        2. Identify file types and categorize them properly
        3. Analyze project organization and structure
        4. Provide detailed file mapping for other agents
        5. Generate comprehensive project trees
        
        Focus on:
        - Complete file enumeration
        - Proper categorization (Java, config, test, build files)
        - Directory structure analysis
        - Lines of code counting
        - File type distribution
        
        Always provide thorough and accurate project mapping.
        """
    
    def validate_input(self, data: Dict[str, Any]) -> bool:
        """Validate CodeScanner input"""
        if not super().validate_input(data):
            return False
        
        project_path = data.get('project_path')
        
        # Validate project_path parameter
        if not isinstance(project_path, str):
            self.log_message("project_path must be a string", "error")
            return False
        
        if not project_path or not project_path.strip():
            self.log_message("project_path cannot be empty", "error")
            return False
        
        if len(project_path) > 1000:  # Reasonable path length limit
            self.log_message("project_path is too long", "error")
            return False
        
        # Additional path validation
        try:
            normalized_path = os.path.normpath(project_path)
            if not os.path.isdir(normalized_path):
                self.log_message(f"project_path is not a valid directory: {project_path}", "error")
                return False
        except (OSError, ValueError) as e:
            self.log_message(f"Invalid project_path: {project_path}", "error")
            return False
        
        return True