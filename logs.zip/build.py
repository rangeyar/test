#!/usr/bin/env python3
"""
Build Script with License Plugin Integration
Equivalent to Maven build with license-maven-plugin execution

Usage:
    python build.py              # Full build with license check
    python build.py validate     # Just license validation
    python build.py clean        # Clean build artifacts
"""

import os
import subprocess
import sys
from pathlib import Path

def run_command(command, description):
    """Run a command and report results"""
    print(f"🔄 {description}...")
    result = subprocess.run(command, shell=True, capture_output=True, text=True)
    
    if result.returncode == 0:
        print(f"✅ {description} completed successfully")
        if result.stdout.strip():
            print(f"📝 Output: {result.stdout.strip()}")
        return True
    else:
        print(f"❌ {description} failed")
        if result.stderr.strip():
            print(f"🚨 Error: {result.stderr.strip()}")
        return False

def validate_phase():
    """Maven validate phase - includes license checking"""
    print("\n📋 VALIDATE PHASE")
    print("=" * 40)
    
    # Equivalent to license-maven-plugin execution
    success = True
    
    # Install license tools if needed
    print("📦 Installing license checking tools...")
    install_cmd = f"{sys.executable} -m pip install pip-licenses toml --quiet"
    if not run_command(install_cmd, "Installing dependencies"):
        print("⚠️ Warning: Could not install license tools, continuing...")
    
    # Download licenses (equivalent to download-licenses goal)
    license_cmd = f"{sys.executable} license_maven_plugin.py download-licenses"
    if not run_command(license_cmd, "Downloading license information"):
        success = False
    
    # Check licenses (equivalent to check-licenses goal)  
    check_cmd = f"{sys.executable} license_maven_plugin.py check-licenses"
    if not run_command(check_cmd, "Validating license compliance"):
        success = False
    
    return success

def compile_phase():
    """Maven compile phase"""
    print("\n🔨 COMPILE PHASE") 
    print("=" * 40)
    
    # Python syntax check (equivalent to compilation)
    files_to_check = [
        "app.py",
        "src/**/*.py",
        "*.py"
    ]
    
    for pattern in files_to_check:
        if pattern.endswith('.py') and os.path.exists(pattern):
            check_cmd = f"{sys.executable} -m py_compile {pattern}"
            if not run_command(check_cmd, f"Syntax check: {pattern}"):
                return False
    
    print("✅ All Python files compiled successfully")
    return True

def test_phase():
    """Maven test phase"""
    print("\n🧪 TEST PHASE")
    print("=" * 40)
    
    # Run pytest if available
    test_cmd = f"{sys.executable} -m pytest --tb=short"
    if not run_command(test_cmd, "Running tests"):
        print("⚠️ No tests found or pytest not available")
    
    return True

def package_phase():
    """Maven package phase"""  
    print("\n📦 PACKAGE PHASE")
    print("=" * 40)
    
    # Create distribution package
    if os.path.exists("setup.py"):
        package_cmd = f"{sys.executable} setup.py sdist bdist_wheel"
        return run_command(package_cmd, "Creating distribution packages")
    else:
        print("ℹ️ No setup.py found, skipping package creation")
        return True

def clean_phase():
    """Maven clean phase"""
    print("\n🧹 CLEAN PHASE")
    print("=" * 40)
    
    # Clean build artifacts
    clean_dirs = [
        "target/",
        "build/", 
        "dist/",
        "__pycache__/",
        "*.egg-info/",
        ".pytest_cache/"
    ]
    
    for clean_dir in clean_dirs:
        if os.path.exists(clean_dir):
            if clean_dir.endswith('/'):
                import shutil
                shutil.rmtree(clean_dir, ignore_errors=True)
                print(f"🗑️ Removed directory: {clean_dir}")
            else:
                import glob
                for file_path in glob.glob(clean_dir):
                    if os.path.isdir(file_path):
                        import shutil
                        shutil.rmtree(file_path, ignore_errors=True)
                    else:
                        os.remove(file_path)
                    print(f"🗑️ Removed: {file_path}")
    
    print("✅ Clean completed")
    return True

def install_phase():
    """Maven install phase"""
    print("\n💾 INSTALL PHASE")
    print("=" * 40)
    
    # Install in development mode
    install_cmd = f"{sys.executable} -m pip install -e ."
    if not run_command(install_cmd, "Installing in development mode"):
        print("⚠️ Install failed, continuing...")
    
    return True

def full_build():
    """Full Maven-style build lifecycle"""
    print("🚀 SmartUpgrade Build Pipeline")
    print("=" * 50)
    print("Equivalent to: mvn clean validate compile test package install")
    print("With license-maven-plugin execution")
    
    phases = [
        ("clean", clean_phase),
        ("validate", validate_phase),
        ("compile", compile_phase), 
        ("test", test_phase),
        ("package", package_phase),
        ("install", install_phase)
    ]
    
    for phase_name, phase_func in phases:
        try:
            success = phase_func()
            if not success:
                print(f"\n❌ Build failed at {phase_name} phase")
                return False
        except KeyboardInterrupt:
            print(f"\n⏹️ Build interrupted at {phase_name} phase")
            return False
        except Exception as e:
            print(f"\n💥 Build error at {phase_name} phase: {e}")
            return False
    
    print("\n🎉 BUILD SUCCESS")
    print("=" * 50)
    print("All phases completed successfully!")
    print("License compliance verified ✅")
    return True

def main():
    """Main build entry point"""
    if len(sys.argv) > 1:
        phase = sys.argv[1].lower()
        
        if phase == "clean":
            return 0 if clean_phase() else 1
        elif phase == "validate":
            return 0 if validate_phase() else 1
        elif phase == "compile":
            return 0 if compile_phase() else 1
        elif phase == "test":
            return 0 if test_phase() else 1
        elif phase == "package":
            return 0 if package_phase() else 1
        elif phase == "install": 
            return 0 if install_phase() else 1
        elif phase == "help":
            print("Available phases: clean, validate, compile, test, package, install")
            print("Or run without arguments for full build pipeline")
            return 0
        else:
            print(f"Unknown phase: {phase}")
            print("Available phases: clean, validate, compile, test, package, install")
            return 1
    else:
        # Full build pipeline
        return 0 if full_build() else 1

if __name__ == "__main__":
    sys.exit(main())