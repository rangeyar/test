"""
TechDetective Agent Module
Sophia - Technology stack analysis specialist
"""

from .detective_agent import TechDetectiveAgent

__all__ = ['TechDetectiveAgent']