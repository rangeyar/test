#//TODORAGJSP STARTS
"""
JSP Migration Agent
Handles JSP → JSTL/Spring Tag modernization for Spring MVC projects
"""

from .jsp_migration_agent import modernize_jsp_files

__all__ = ['modernize_jsp_files']
#//TODORAGJSP ENDS
