"""
Configuration Management Module for SmartUpgrade
Handles all configuration loading, validation, and provider management
"""

import os
import logging
from typing import Dict, Any, Optional
from dataclasses import dataclass, field
from pathlib import Path
import yaml
from dotenv import load_dotenv
import requests
import ssl
from urllib3.util.ssl_ import create_urllib3_context

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)

@dataclass
class AzureOpenAIConfig:
    endpoint: str
    api_key: str
    deployment: str
    api_version: str

@dataclass
class OpenAIConfig:
    api_key: str
    base_url: str
    model: str

@dataclass
class AnthropicConfig:
    api_key: str
    base_url: str
    model: str


@dataclass
class ProviderConfig:
    """Configuration for AI providers"""
    provider_type: str
    api_key: str
    endpoint: Optional[str] = None
    model: str = "gpt-3.5-turbo"
    api_version: Optional[str] = None
    deployment: Optional[str] = None
    temperature: float = 0.7
    max_tokens: int = 4000
    timeout: int = 300

@dataclass
class SSLConfig:
    """SSL Configuration"""
    ca_bundle_path: Optional[str] = None
    verify: bool = True
    custom_certs: Dict[str, str] = field(default_factory=dict)

@dataclass
class AppConfig:
    """Main application configuration"""
    app_name: str = "SmartUpgrade"
    version: str = "1.0.0"
    debug: bool = False
    log_level: str = "INFO"
    
    # File handling
    max_file_size_mb: int = 50
    supported_file_types: list = field(default_factory=lambda: [".zip", ".jar", ".war"])
    temp_dir: str = "./temp"
    output_dir: str = "./output"
    
    # Performance
    max_concurrent_agents: int = 5
    analysis_timeout: int = 1800
    transformation_timeout: int = 3600
    memory_limit_mb: int = 2048
    
    # UI Features
    show_group_chat_tab: bool = True
    enable_real_time_logs: bool = True
    
    # Platform defaults
    default_java_version: str = "17"
    default_boot_version: str = "3.3.4"

class ConfigurationManager:
    """Central configuration manager"""
    
    def __init__(self):
        self.app_config = self._load_app_config()
        self.provider_configs = self._load_provider_configs()
        self.ssl_config = self._load_ssl_config()
        self.custom_rules = self._load_custom_rules()
        self._setup_logging()
        self._create_directories()
    
    def _load_app_config(self) -> AppConfig:
        """Load main application configuration"""
        return AppConfig(
            app_name=os.getenv("APP_NAME", "SmartUpgrade"),
            version=os.getenv("APP_VERSION", "1.0.0"),
            debug=os.getenv("ENABLE_DEBUG_MODE", "false").lower() == "true",
            log_level=os.getenv("LOG_LEVEL", "INFO"),
            max_file_size_mb=int(os.getenv("MAX_FILE_SIZE_MB", "50")),
            temp_dir=os.getenv("TEMP_DIR", "./temp"),
            output_dir=os.getenv("OUTPUT_DIR", "./output"),
            max_concurrent_agents=int(os.getenv("MAX_CONCURRENT_AGENTS", "5")),
            analysis_timeout=int(os.getenv("ANALYSIS_TIMEOUT", "1800")),
            transformation_timeout=int(os.getenv("TRANSFORMATION_TIMEOUT", "3600")),
            memory_limit_mb=int(os.getenv("MEMORY_LIMIT_MB", "2048")),
            show_group_chat_tab=os.getenv("SHOW_GROUP_CHAT_TAB", "true").lower() == "true",
            enable_real_time_logs=os.getenv("ENABLE_REAL_TIME_LOGS", "true").lower() == "true",
            default_java_version=os.getenv("DEFAULT_JAVA_VERSION", "17"),
            default_boot_version=os.getenv("DEFAULT_BOOT_VERSION", "3.3.4")
        )
    
    def _load_provider_configs(self, cfg_path :str |None = None) -> Dict[str, ProviderConfig]:
        """Load all AI provider configurations"""
        configs = {}
        #TODORAG
        # Default path for production deployment on EC2/Linux
        default_config_path = "/opt/app-config/provider-azure.yaml" if os.name != 'nt' else "config/provider-azure.yaml"
        self.cfg_path = cfg_path or os.getenv("CONFIG_PATH", default_config_path)
        
        if not os.path.exists(self.cfg_path):
            # Try relative path from current working directory (for development)
            self.cfg_path = os.path.join(os.getcwd(), "config", "provider-azure.yaml")
        
        if not os.path.exists(self.cfg_path):
            # Try to detect any provider config file in the directory
            config_dir = "/opt/app-config" if os.name != 'nt' else "config"
            if os.path.exists(config_dir):
                for filename in os.listdir(config_dir):
                    if filename.startswith("provider-") and filename.endswith(".yaml"):
                        self.cfg_path = os.path.join(config_dir, filename)
                        logger.info(f"Auto-detected provider config: {self.cfg_path}")
                        break
        
        if not os.path.exists(self.cfg_path):
            raise FileNotFoundError(f"Config file not found: {self.cfg_path}. Searched paths: {default_config_path}, {os.path.join(os.getcwd(), 'config', 'provider-azure.yaml')}, {config_dir}/")

        with open(self.cfg_path, "r", encoding="utf-8") as f:
            cfg = yaml.safe_load(f) or {}

        filename = os.path.basename(self.cfg_path).lower()
        print("filename",filename)
        if "azure" in filename:
            provider = "azure_openai"
        elif "anthropic" in filename:
            provider = "anthropic"
        elif "openai" in filename:
            provider = "openai"
        else:
            raise ValueError(f"Unable to detect provider from filename: {filename}")

        cfg = {k.lower(): v for k, v in cfg.items()}
        print('cfg',cfg)
        # Azure OpenAI
        if provider == "azure_openai":
            #azure_cfg = cfg.get("models", cfg)
            models_list = cfg.get("models", [])
            azure_cfg = models_list[0]
            print("azure_cfg",azure_cfg)
            configs["azure"] = ProviderConfig(
                provider_type="azure",
                api_key=azure_cfg["apiKey"],
                endpoint=azure_cfg["apibase"],
                api_version=azure_cfg["version"],
                deployment=azure_cfg["deployment"],
                model=azure_cfg["model"],
                timeout=int(os.getenv("REQUEST_TIMEOUT", "300"))
            )
        
        # OpenAI
        if provider == "openai":
            models_list = cfg.get("models", [])
            openai_cfg = models_list[0]
            configs["openai"] = ProviderConfig(
                provider_type="openai",
                api_key=openai_cfg["apiKey"],
                endpoint=openai_cfg["apibase"],
                api_version=openai_cfg["version"],
                deployment=openai_cfg["deployment"],
                model=openai_cfg["model"],
                timeout=int(os.getenv("REQUEST_TIMEOUT", "300"))
            )
        
        # Anthropic
        if provider == "anthropic":
            models_list = cfg.get("models", [])
            anthropic_cfg = models_list[0]
            configs["anthropic"] = ProviderConfig(
                provider_type="anthropic",
                api_key=anthropic_cfg["apiKey"],
                endpoint=anthropic_cfg["apibase"],
                api_version=anthropic_cfg["version"],
                deployment=anthropic_cfg["deployment"],
                model=anthropic_cfg["model"],
                timeout=int(os.getenv("REQUEST_TIMEOUT", "300"))
            )
        
        # Custom API
        if os.getenv("CUSTOM_API_KEY"):
            configs["custom"] = ProviderConfig(
                provider_type="custom",
                api_key=os.getenv("CUSTOM_API_KEY"),
                endpoint=os.getenv("CUSTOM_API_ENDPOINT"),
                model=os.getenv("CUSTOM_MODEL", "claude-4-sonnet"),
                api_version=os.getenv("CUSTOM_API_VERSION", "v1"),
                timeout=int(os.getenv("REQUEST_TIMEOUT", "300"))
            )
        
        return configs
    
    def _load_ssl_config(self) -> SSLConfig:
        """Load SSL configuration"""
        custom_certs = {}
        
        ca_bundle = os.getenv("CA_BUNDLE_PATH")
        amfam_bundle = os.getenv("AMFAM_BUNDLE_PATH")
        
        if ca_bundle and Path(ca_bundle).exists():
            custom_certs["ca_bundle"] = ca_bundle
        
        if amfam_bundle and Path(amfam_bundle).exists():
            custom_certs["amfam_bundle"] = amfam_bundle
        
        return SSLConfig(
            ca_bundle_path=ca_bundle,
            verify=os.getenv("SSL_VERIFY", "true").lower() == "true",
            custom_certs=custom_certs
        )
    
    def _load_custom_rules(self) -> Dict[str, Any]:
        """Load custom analysis and transformation rules"""
        rules = {}
        
        # Load from configs directory if it exists
        configs_dir = Path("configs")
        if configs_dir.exists():
            for rule_file in configs_dir.glob("**/*.yaml"):
                try:
                    with open(rule_file, 'r') as f:
                        file_rules = yaml.safe_load(f)
                        rules[rule_file.stem] = file_rules
                except Exception as e:
                    logger.warning(f"Failed to load rules from {rule_file}: {e}")
        
        return rules
    
    def _setup_logging(self):
        """Setup logging configuration"""
        log_level = getattr(logging, self.app_config.log_level.upper())
        
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler('smartupgrade.log')
            ]
        )
    
    def _create_directories(self):
        """Create necessary directories"""
        Path(self.app_config.temp_dir).mkdir(parents=True, exist_ok=True)
        Path(self.app_config.output_dir).mkdir(parents=True, exist_ok=True)
        Path("logs").mkdir(exist_ok=True)
    
    def get_provider_config(self, provider_name: str) -> Optional[ProviderConfig]:
        """Get configuration for specific provider"""
        return self.provider_configs.get(provider_name)
    
    def get_active_provider(self) -> str:
        """Get the currently active provider"""
        return os.getenv("PROVIDER", "azure")
    
    def validate_provider_connectivity(self, provider_name: str) -> bool:
        """Validate that a provider is accessible"""
        # Input validation
        print("provider_name yyyy",provider_name) #TODORAG
        if not provider_name or not isinstance(provider_name, str):
            logger.error("Provider name must be a non-empty string")
            return False
        
        config = self.get_provider_config(provider_name)
        print("provider_name yyconfig 1111",config) #TODORAG
        if not config:
            logger.warning(f"No configuration found for provider: {provider_name}")
            return False
        
        # Validate config has required fields
        if not config.api_key:
            logger.warning(f"No API key configured for provider: {provider_name}")
            return False
        
        try:
            # Test connectivity based on provider type with proper error handling
            if provider_name == "azure" and config.endpoint:
                if not config.endpoint.startswith(('http://', 'https://')):
                    print("Invalid Azure endpoint URL 2222:", config.endpoint) #TODORAG
                    logger.error(f"Invalid Azure endpoint URL: {config.endpoint}")
                    return False
                    
                response = requests.get(
                    f"{config.endpoint.rstrip('/')}/openai/deployments",
                    headers={"api-key": config.api_key},
                    timeout=10,
                    verify=self.ssl_config.verify
                )
                print("response.status_code 3333",response.status_code) #TODORAG
                return response.status_code in [200, 401]  # 401 means auth issue but endpoint exists
            
            elif provider_name == "openai":
                response = requests.get(
                    "https://api.openai.com/v1/models",
                    headers={"Authorization": f"Bearer {config.api_key}"},
                    timeout=10,
                    verify=self.ssl_config.verify
                )
                return response.status_code in [200, 401]
            
            elif provider_name == "custom" and config.endpoint:
                if not config.endpoint.startswith(('http://', 'https://')):
                    logger.error(f"Invalid custom endpoint URL: {config.endpoint}")
                    return False
                    
                response = requests.get(
                    config.endpoint,
                    headers={"Authorization": f"Bearer {config.api_key}"},
                    timeout=10,
                    verify=self.ssl_config.verify
                )
                return response.status_code in [200, 401]  # 401 means endpoint exists
            
            return True
            
        except requests.exceptions.RequestException as e:
            logger.warning(f"Network error testing {provider_name}: Connection failed")
            return False
        except requests.exceptions.Timeout as e:
            logger.warning(f"Timeout testing {provider_name}: Request timed out")
            return False
        except ValueError as e:
            logger.error(f"Invalid configuration for {provider_name}: {e}")
            return False
        except Exception as e:
            logger.error(f"Unexpected error testing {provider_name}: Operation failed")
            return False
    
    def update_agent_config(self, agent_name: str, config: Dict[str, Any]):
        """Update agent configuration at runtime"""
        if agent_name not in self.custom_rules:
            self.custom_rules[agent_name] = {}
        
        self.custom_rules[agent_name].update(config)
        logger.info(f"Updated configuration for agent: {agent_name}")
    
    def get_ssl_context(self) -> Optional[ssl.SSLContext]:
        """Create SSL context with custom certificates if configured"""
        if not self.ssl_config.verify:
            return None
        
        context = create_urllib3_context()
        
        if self.ssl_config.ca_bundle_path and Path(self.ssl_config.ca_bundle_path).exists():
            context.load_verify_locations(cafile=self.ssl_config.ca_bundle_path)
        
        return context

# Global configuration instance
config_manager = ConfigurationManager()

# Global variables for easy access across modules
ACTIVE_PROVIDER = config_manager.get_active_provider()
PROVIDER_CONFIG = config_manager.get_provider_config(ACTIVE_PROVIDER)

# AutoGen config list for migration agents (pre-built for performance)
AUTOGEN_CONFIG_LIST = []

def _build_autogen_config():
    """Build AutoGen configuration list from provider config"""
    global AUTOGEN_CONFIG_LIST
    
    if not PROVIDER_CONFIG:
        logger.warning("No provider configuration available for AutoGen")
        return
    
    try:
        if PROVIDER_CONFIG.provider_type == "azure" or ACTIVE_PROVIDER == "azure":
            AUTOGEN_CONFIG_LIST = [{
                "model": PROVIDER_CONFIG.deployment or PROVIDER_CONFIG.model,
                "api_key": PROVIDER_CONFIG.api_key,
                "base_url": PROVIDER_CONFIG.endpoint,
                "api_type": "azure",
                "api_version": PROVIDER_CONFIG.api_version,
                "timeout": PROVIDER_CONFIG.timeout
            }]
            
        elif PROVIDER_CONFIG.provider_type == "openai" or ACTIVE_PROVIDER == "openai":
            AUTOGEN_CONFIG_LIST = [{
                "model": PROVIDER_CONFIG.model,
                "api_key": PROVIDER_CONFIG.api_key,
                "base_url": PROVIDER_CONFIG.endpoint or "https://api.openai.com/v1",
                "api_type": "openai",
                "timeout": PROVIDER_CONFIG.timeout
            }]
            
        elif PROVIDER_CONFIG.provider_type == "anthropic" or ACTIVE_PROVIDER == "anthropic":
            AUTOGEN_CONFIG_LIST = [{
                "model": PROVIDER_CONFIG.model,
                "api_key": PROVIDER_CONFIG.api_key,
                "base_url": PROVIDER_CONFIG.endpoint or "https://api.anthropic.com",
                "api_type": "anthropic",
                "timeout": PROVIDER_CONFIG.timeout
            }]
            
        elif PROVIDER_CONFIG.provider_type == "custom" or ACTIVE_PROVIDER == "custom":
            AUTOGEN_CONFIG_LIST = [{
                "model": PROVIDER_CONFIG.model,
                "api_key": PROVIDER_CONFIG.api_key,
                "base_url": PROVIDER_CONFIG.endpoint,
                "api_type": "custom",
                "api_version": PROVIDER_CONFIG.api_version,
                "timeout": PROVIDER_CONFIG.timeout
            }]
        
        logger.info(f"AutoGen config list built successfully for {ACTIVE_PROVIDER}")
        
    except Exception as e:
        logger.error(f"Error building AutoGen config: {str(e)}")
        AUTOGEN_CONFIG_LIST = []

# Build the AutoGen config on module load
_build_autogen_config()

# Export commonly used values as module-level variables
API_KEY = PROVIDER_CONFIG.api_key if PROVIDER_CONFIG else None
ENDPOINT = PROVIDER_CONFIG.endpoint if PROVIDER_CONFIG else None
MODEL_NAME = (PROVIDER_CONFIG.model or PROVIDER_CONFIG.deployment) if PROVIDER_CONFIG else None
API_VERSION = PROVIDER_CONFIG.api_version if PROVIDER_CONFIG else None
PROVIDER_TYPE = PROVIDER_CONFIG.provider_type if PROVIDER_CONFIG else None
TIMEOUT = PROVIDER_CONFIG.timeout if PROVIDER_CONFIG else 300

def refresh_global_config():
    """Refresh global configuration variables (useful for runtime updates)"""
    global ACTIVE_PROVIDER, PROVIDER_CONFIG, AUTOGEN_CONFIG_LIST
    global API_KEY, ENDPOINT, MODEL_NAME, API_VERSION, PROVIDER_TYPE, TIMEOUT
    
    ACTIVE_PROVIDER = config_manager.get_active_provider()
    PROVIDER_CONFIG = config_manager.get_provider_config(ACTIVE_PROVIDER)
    
    # Update module-level variables
    API_KEY = PROVIDER_CONFIG.api_key if PROVIDER_CONFIG else None
    ENDPOINT = PROVIDER_CONFIG.endpoint if PROVIDER_CONFIG else None
    MODEL_NAME = (PROVIDER_CONFIG.model or PROVIDER_CONFIG.deployment) if PROVIDER_CONFIG else None
    API_VERSION = PROVIDER_CONFIG.api_version if PROVIDER_CONFIG else None
    PROVIDER_TYPE = PROVIDER_CONFIG.provider_type if PROVIDER_CONFIG else None
    TIMEOUT = PROVIDER_CONFIG.timeout if PROVIDER_CONFIG else 300
    
    # Rebuild AutoGen config
    _build_autogen_config()
    
    logger.info(f"Global configuration refreshed for provider: {ACTIVE_PROVIDER}")