"""
QualityInspector Agent Module
David - Code quality and security analysis specialist
"""

from .inspector_agent import QualityInspectorAgent

__all__ = ['QualityInspectorAgent']