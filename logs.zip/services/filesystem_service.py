"""
Filesystem Service Module
Handles all filesystem operations for SmartUpgrade including:
- ZIP file extraction and validation
- Directory scanning and traversal
- File reading (Java, XML, config files)
- File writing and output generation
- Directory tree generation
- Temporary folder cleanup
- Project structure analysis
"""

import os
import zipfile
import tempfile
import shutil
import io
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
import logging

logger = logging.getLogger(__name__)


class FilesystemService:
    """Service class for all filesystem operations"""
    
    def __init__(self):
        """Initialize filesystem service"""
        self.temp_dirs = []  # Track temporary directories for cleanup
    
    def extract_zip_file(self, uploaded_file, validate_java=True) -> Tuple[Optional[str], Optional[str], str]:
        """
        Extract ZIP file to temporary directory
        
        Args:
            uploaded_file: Streamlit uploaded file object
            validate_java: Whether to validate ZIP contains Java files
            
        Returns:
            Tuple of (project_path, project_name, error_message)
        """
        try:
            if not uploaded_file.name.endswith('.zip'):
                return None, None, f"Invalid file type: {uploaded_file.name}. Only ZIP files are supported."
            
            # Create temporary directory
            temp_dir = tempfile.mkdtemp(prefix="smartupgrade_")
            self.temp_dirs.append(temp_dir)
            
            zip_path = os.path.join(temp_dir, uploaded_file.name)
            
            # Write uploaded file to disk
            with open(zip_path, "wb") as f:
                f.write(uploaded_file.getvalue())
            
            # Validate ZIP file
            if validate_java:
                try:
                    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                        file_list = zip_ref.namelist()
                        has_java_files = any(f.endswith('.java') for f in file_list)
                        
                        if not has_java_files:
                            return None, None, "ZIP validation failed: No .java files found in the archive."
                except zipfile.BadZipFile:
                    return None, None, "Invalid ZIP file format."
            
            # Extract files
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
            
            # Determine project root
            project_path = temp_dir
            project_name = uploaded_file.name.replace('.zip', '')
            
            # Check if files are in a subdirectory
            items = os.listdir(temp_dir)
            non_zip_items = [item for item in items if not item.endswith('.zip')]
            if len(non_zip_items) == 1 and os.path.isdir(os.path.join(temp_dir, non_zip_items[0])):
                project_path = os.path.join(temp_dir, non_zip_items[0])
                project_name = non_zip_items[0]
            
            return project_path, project_name, ""
            
        except Exception as e:
            logger.error(f"Error extracting ZIP file: {str(e)}")
            return None, None, f"Error extracting ZIP file: {str(e)}"
    
    def validate_zip_contents(self, zip_path: str) -> Dict[str, Any]:
        """
        Validate and analyze ZIP file contents
        
        Args:
            zip_path: Path to ZIP file
            
        Returns:
            Dictionary with validation results
        """
        try:
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                file_list = zip_ref.namelist()
                
                # Count file types
                java_files = [f for f in file_list if f.endswith('.java')]
                xml_files = [f for f in file_list if f.endswith('.xml')]
                properties_files = [f for f in file_list if f.endswith(('.properties', '.yml', '.yaml'))]
                build_files = [f for f in file_list if 'pom.xml' in f or 'build.gradle' in f]
                
                return {
                    'valid': len(java_files) > 0,
                    'total_files': len([f for f in file_list if not f.endswith('/')]),
                    'java_files_count': len(java_files),
                    'xml_files_count': len(xml_files),
                    'config_files_count': len(properties_files),
                    'build_files_count': len(build_files),
                    'has_build_files': len(build_files) > 0,
                    'has_source_structure': any('src/' in f for f in file_list),
                    'file_list': file_list
                }
        except zipfile.BadZipFile:
            return {'valid': False, 'error': 'Invalid ZIP file format'}
        except Exception as e:
            return {'valid': False, 'error': str(e)}
    
    def scan_directory_structure(self, project_path: str) -> Dict[str, Any]:
        """
        Scan project directory and categorize files
        
        Args:
            project_path: Root path of the project
            
        Returns:
            Dictionary containing file categories and metrics
        """
        try:
            java_files = []
            config_files = []
            build_files = []
            all_files = []
            java_packages = set()
            
            total_lines = 0
            
            for root, dirs, files in os.walk(project_path):
                for file in files:
                    file_path = os.path.join(root, file)
                    relative_path = os.path.relpath(file_path, project_path)
                    all_files.append(relative_path)
                    
                    # Categorize files
                    if file.endswith('.java'):
                        java_files.append(file_path)
                        # Track packages
                        rel_path = os.path.relpath(root, project_path)
                        if 'src' in rel_path:
                            java_packages.add(rel_path)
                        
                        # Count lines
                        try:
                            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                                total_lines += len(f.readlines())
                        except:
                            pass
                    
                    elif file in ['pom.xml', 'build.gradle', 'build.xml', 'gradle.properties']:
                        build_files.append(file_path)
                    
                    elif file.endswith(('.properties', '.yml', '.yaml', '.xml', '.json')):
                        config_files.append(file_path)
            
            return {
                'java_files': java_files,
                'config_files': config_files,
                'build_files': build_files,
                'all_files': all_files,
                'java_packages': list(java_packages),
                'total_files': len(all_files),
                'java_count': len(java_files),
                'config_count': len(config_files),
                'build_count': len(build_files),
                'total_lines_of_code': total_lines,
                'directory_count': sum(1 for _, dirs, _ in os.walk(project_path) for _ in dirs)
            }
            
        except Exception as e:
            logger.error(f"Error scanning directory: {str(e)}")
            return {
                'error': str(e),
                'java_files': [],
                'config_files': [],
                'build_files': [],
                'all_files': []
            }
    
    def read_file_content(self, file_path: str, max_size: Optional[int] = None, encoding: str = 'utf-8') -> Tuple[Optional[str], str]:
        """
        Read file content safely
        
        Args:
            file_path: Path to file
            max_size: Maximum size to read (in characters)
            encoding: File encoding
            
        Returns:
            Tuple of (content, error_message)
        """
        try:
            if not os.path.exists(file_path):
                return None, f"File not found: {file_path}"
            
            file_size = os.path.getsize(file_path)
            
            # Warn about large files
            if file_size > 5 * 1024 * 1024:  # 5MB
                logger.warning(f"Large file detected: {file_path} ({file_size // 1024}KB)")
            
            with open(file_path, 'r', encoding=encoding, errors='ignore') as f:
                content = f.read(max_size) if max_size else f.read()
                return content, ""
                
        except Exception as e:
            logger.error(f"Error reading file {file_path}: {str(e)}")
            return None, f"Error reading file: {str(e)}"
    
    def read_multiple_files(self, file_paths: List[str], max_files: Optional[int] = None, 
                           max_size_per_file: Optional[int] = None) -> Dict[str, Any]:
        """
        Read multiple files efficiently
        
        Args:
            file_paths: List of file paths to read
            max_files: Maximum number of files to read
            max_size_per_file: Maximum size per file
            
        Returns:
            Dictionary mapping file paths to their content
        """
        results = {}
        files_to_read = file_paths[:max_files] if max_files else file_paths
        
        for file_path in files_to_read:
            content, error = self.read_file_content(file_path, max_size_per_file)
            if content:
                results[file_path] = {
                    'content': content,
                    'size': len(content),
                    'lines': len(content.split('\n')),
                    'error': None
                }
            else:
                results[file_path] = {
                    'content': None,
                    'error': error
                }
        
        return results
    
    def write_file(self, file_path: str, content: str, create_dirs: bool = True) -> Tuple[bool, str]:
        """
        Write content to file
        
        Args:
            file_path: Path where file should be written
            content: Content to write
            create_dirs: Whether to create parent directories
            
        Returns:
            Tuple of (success, error_message)
        """
        try:
            if create_dirs:
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            return True, ""
            
        except Exception as e:
            logger.error(f"Error writing file {file_path}: {str(e)}")
            return False, f"Error writing file: {str(e)}"
    
    def generate_directory_tree(self, project_path: str, project_name: str, max_depth: int = 5) -> str:
        """
        Generate visual directory tree representation
        
        Args:
            project_path: Root path of the project
            project_name: Name of the project
            max_depth: Maximum depth to traverse
            
        Returns:
            String representation of directory tree
        """
        try:
            tree_lines = [f"```", f"📁 {project_name}/"]
            
            def add_directory_tree(dir_path: str, prefix: str = "", depth: int = 0, is_last: bool = True):
                if depth >= max_depth:
                    return
                
                items = []
                if os.path.exists(dir_path):
                    try:
                        items = sorted(os.listdir(dir_path))
                    except PermissionError:
                        return
                
                for i, item in enumerate(items):
                    item_path = os.path.join(dir_path, item)
                    is_last_item = i == len(items) - 1
                    
                    if os.path.isdir(item_path):
                        # Directory
                        connector = "└── " if is_last_item else "├── "
                        tree_lines.append(f"{prefix}{connector}📁 {item}/")
                        
                        extension = "    " if is_last_item else "│   "
                        add_directory_tree(item_path, prefix + extension, depth + 1, is_last_item)
                    else:
                        # File
                        connector = "└── " if is_last_item else "├── "
                        
                        # Add appropriate emoji for file type
                        emoji = self._get_file_emoji(item)
                        tree_lines.append(f"{prefix}{connector}{emoji} {item}")
            
            add_directory_tree(project_path)
            tree_lines.append("```")
            
            return "\n".join(tree_lines)
            
        except Exception as e:
            logger.error(f"Error generating directory tree: {str(e)}")
            return f"```\n📁 {project_name}/\n└── ❌ Error reading file structure: {str(e)}\n```"
    
    def _get_file_emoji(self, filename: str) -> str:
        """Get appropriate emoji for file type"""
        if filename.endswith('.java'):
            return "☕"
        elif filename.endswith('.xml'):
            return "📄"
        elif filename.endswith(('.properties', '.yml', '.yaml')):
            return "⚙️"
        elif filename.endswith('.md'):
            return "📝"
        elif filename.endswith('.txt'):
            return "📄"
        elif filename.endswith(('.class', '.jar')):
            return "📦"
        elif filename.endswith(('.js', '.css', '.html')):
            return "🌐"
        else:
            return "📄"
    
    def create_output_directory(self, base_path: str, dir_name: str = "output") -> Tuple[Optional[str], str]:
        """
        Create output directory for migrated files
        
        Args:
            base_path: Base path where output directory should be created
            dir_name: Name of output directory
            
        Returns:
            Tuple of (output_path, error_message)
        """
        try:
            output_path = os.path.join(base_path, dir_name)
            os.makedirs(output_path, exist_ok=True)
            return output_path, ""
        except Exception as e:
            logger.error(f"Error creating output directory: {str(e)}")
            return None, f"Error creating output directory: {str(e)}"
    
    def write_migrated_files(self, output_path: str, files_data: Dict[str, str]) -> Dict[str, Any]:
        """
        Write multiple migrated files to output directory
        
        Args:
            output_path: Base output directory
            files_data: Dictionary mapping relative file paths to their content
            
        Returns:
            Dictionary with write results
        """
        results = {
            'success_count': 0,
            'error_count': 0,
            'written_files': [],
            'errors': []
        }
        
        for relative_path, content in files_data.items():
            file_path = os.path.join(output_path, relative_path)
            success, error = self.write_file(file_path, content, create_dirs=True)
            
            if success:
                results['success_count'] += 1
                results['written_files'].append(relative_path)
            else:
                results['error_count'] += 1
                results['errors'].append({'file': relative_path, 'error': error})
        
        return results
    
    def create_zip_for_download(self, source_path: str, output_name: str = "modernized_project.zip") -> Tuple[Optional[bytes], str]:
        """
        Create ZIP file from directory for download
        
        Args:
            source_path: Path to directory to zip
            output_name: Name for the ZIP file
            
        Returns:
            Tuple of (zip_bytes, error_message)
        """
        try:
            zip_buffer = io.BytesIO()
            
            with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                for root, dirs, files in os.walk(source_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        arcname = os.path.relpath(file_path, source_path)
                        zip_file.write(file_path, arcname)
            
            zip_buffer.seek(0)
            return zip_buffer.getvalue(), ""
            
        except Exception as e:
            logger.error(f"Error creating ZIP file: {str(e)}")
            return None, f"Error creating ZIP file: {str(e)}"
    
    def cleanup_temp_directories(self):
        """Clean up all temporary directories created during session"""
        for temp_dir in self.temp_dirs:
            try:
                if os.path.exists(temp_dir):
                    shutil.rmtree(temp_dir)
                    logger.info(f"Cleaned up temporary directory: {temp_dir}")
            except Exception as e:
                logger.error(f"Error cleaning up {temp_dir}: {str(e)}")
        
        self.temp_dirs.clear()
    
    def get_file_statistics(self, file_path: str) -> Dict[str, Any]:
        """
        Get statistics for a file
        
        Args:
            file_path: Path to file
            
        Returns:
            Dictionary with file statistics
        """
        try:
            stats = os.stat(file_path)
            content, _ = self.read_file_content(file_path)
            
            return {
                'size_bytes': stats.st_size,
                'size_kb': stats.st_size / 1024,
                'size_mb': stats.st_size / (1024 * 1024),
                'lines': len(content.split('\n')) if content else 0,
                'modified_time': stats.st_mtime,
                'exists': True
            }
        except Exception as e:
            return {'exists': False, 'error': str(e)}
    
    def copy_directory(self, source: str, destination: str) -> Tuple[bool, str]:
        """
        Copy entire directory tree
        
        Args:
            source: Source directory path
            destination: Destination directory path
            
        Returns:
            Tuple of (success, error_message)
        """
        try:
            if os.path.exists(destination):
                shutil.rmtree(destination)
            shutil.copytree(source, destination)
            return True, ""
        except Exception as e:
            logger.error(f"Error copying directory: {str(e)}")
            return False, f"Error copying directory: {str(e)}"
    
    def get_project_metrics(self, project_path: str) -> Dict[str, Any]:
        """
        Calculate comprehensive project metrics
        
        Args:
            project_path: Root path of project
            
        Returns:
            Dictionary with various metrics
        """
        scan_results = self.scan_directory_structure(project_path)
        
        # Calculate file type distribution
        file_types = {}
        for file_path in scan_results.get('all_files', []):
            ext = os.path.splitext(file_path)[1]
            file_types[ext] = file_types.get(ext, 0) + 1
        
        return {
            'total_files': scan_results.get('total_files', 0),
            'total_lines_of_code': scan_results.get('total_lines_of_code', 0),
            'java_file_count': scan_results.get('java_count', 0),
            'config_file_count': scan_results.get('config_count', 0),
            'build_file_count': scan_results.get('build_count', 0),
            'directory_count': scan_results.get('directory_count', 0),
            'file_type_distribution': file_types,
            'java_packages': scan_results.get('java_packages', [])
        }


# Singleton instance
_filesystem_service = FilesystemService()


def get_filesystem_service() -> FilesystemService:
    """Get the singleton filesystem service instance"""
    return _filesystem_service


# Convenience functions for backward compatibility
def extract_zip_file(uploaded_file, validate_java=True):
    """Extract ZIP file to temporary directory"""
    return get_filesystem_service().extract_zip_file(uploaded_file, validate_java)


def scan_directory_structure(project_path: str):
    """Scan project directory and categorize files"""
    return get_filesystem_service().scan_directory_structure(project_path)


def read_file_content(file_path: str, max_size=None):
    """Read file content safely"""
    return get_filesystem_service().read_file_content(file_path, max_size)


def generate_directory_tree(project_path: str, project_name: str):
    """Generate visual directory tree representation"""
    return get_filesystem_service().generate_directory_tree(project_path, project_name)


def create_zip_for_download(source_path: str, output_name: str = "modernized_project.zip"):
    """Create ZIP file from directory for download"""
    return get_filesystem_service().create_zip_for_download(source_path, output_name)


def cleanup_temp_directories():
    """Clean up all temporary directories"""
    return get_filesystem_service().cleanup_temp_directories()


def handle_file_upload_logic(uploaded_file):
    """
    Handle file upload logic - extract and validate silently
    
    Args:
        uploaded_file: Streamlit uploaded file object
        
    Returns:
        Tuple of (success, project_path, project_name, java_files_count)
    """
    fs_service = get_filesystem_service()
    
    try:
        if not uploaded_file or not uploaded_file.name.endswith('.zip'):
            return False, None, None, 0
        
        # Extract ZIP file
        project_path, project_name, error = fs_service.extract_zip_file(uploaded_file, validate_java=True)
        
        if error or not project_path:
            return False, None, None, 0
        
        # Count Java files
        scan_results = fs_service.scan_directory_structure(project_path)
        java_files_count = scan_results.get('java_count', 0)
        
        if java_files_count == 0:
            return False, None, None, 0
        
        return True, project_path, project_name, java_files_count
        
    except Exception as e:
        logger.error(f"Error in handle_file_upload_logic: {str(e)}")
        return False, None, None, 0


def extract_and_validate_project_with_logs(uploaded_file, project_path_input, add_log_func):
    """
    Extract and validate project with logging support
    
    Args:
        uploaded_file: Streamlit uploaded file object
        project_path_input: Optional local project path
        add_log_func: Function to call for logging (e.g., add_agent_log)
        
    Returns:
        Tuple of (success, project_path, project_name, java_files_count)
    """
    fs_service = get_filesystem_service()
    
    try:
        add_log_func("SmartUpgrade", "🚀 Starting project extraction and validation...", "info")
        
        project_path = None
        project_name = None
        
        if uploaded_file:
            add_log_func("SmartUpgrade", f"📦 Processing uploaded ZIP file: {uploaded_file.name}", "info")
            
            if uploaded_file.name.endswith('.zip'):
                # Validate ZIP
                add_log_func("FileExtractor", f"📦 Validating and extracting ZIP file: {uploaded_file.name} ({len(uploaded_file.getvalue())} bytes)", "info")
                
                # Use filesystem service to extract
                project_path, project_name, error = fs_service.extract_zip_file(uploaded_file, validate_java=True)
                
                if error:
                    add_log_func("FileExtractor", f"❌ {error}", "error")
                    return False, None, None, 0
                
                add_log_func("FileExtractor", f"✅ Successfully extracted ZIP file", "success")
            else:
                add_log_func("FileExtractor", f"❌ Unsupported file type: {uploaded_file.name}", "error")
                return False, None, None, 0
        
        elif project_path_input:
            add_log_func("SmartUpgrade", f"📂 Loading local project: {project_path_input}", "info")
            project_path = project_path_input
            project_name = os.path.basename(project_path_input)
        
        if not project_path or not os.path.exists(project_path):
            add_log_func("SmartUpgrade", "❌ Project validation failed - path does not exist", "error")
            return False, None, None, 0
        
        add_log_func("SmartUpgrade", "🔍 Scanning project structure for Java files...", "info")
        
        # Scan directory
        scan_results = fs_service.scan_directory_structure(project_path)
        java_files = scan_results.get('java_files', [])
        java_packages = scan_results.get('java_packages', [])
        
        if java_files:
            add_log_func("SmartUpgrade", f"✅ Successfully identified {len(java_files)} Java source files for analysis", "success")
            if java_packages:
                add_log_func("SmartUpgrade", f"📦 Identified {len(java_packages)} package directories", "info")
        
        add_log_func("SmartUpgrade", f"✅ Project '{project_name}' extracted and validated successfully!", "success")
        add_log_func("SmartUpgrade", f"🎯 {len(java_files)} Java files ready for analysis", "success")
        add_log_func("SmartUpgrade", "💡 Click 'Start Analysis' to begin comprehensive AI-powered analysis", "info")
        
        return True, project_path, project_name, len(java_files)
        
    except Exception as e:
        add_log_func("SmartUpgrade", f"❌ Error loading project: {str(e)}", "error")
        logger.error(f"Error in extract_and_validate_project_with_logs: {str(e)}")
        return False, None, None, 0


def generate_real_file_tree(project_path: str, project_name: str) -> str:
    """
    Generate real file tree from actual uploaded project
    This is a convenience wrapper around the service method
    """
    return get_filesystem_service().generate_directory_tree(project_path, project_name)
